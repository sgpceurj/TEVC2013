/*
 *  LR.h
 *  AGA
 *
 *  Created by Josu Ceberio Uribe on 1/9/12.
 *  Copyright 2012 University of the Basque Country. All rights reserved.
 *
 */
#include "Individual.h"
#include "PFSP.h"

/*
 * Constructive heuristic proposed by Liu and Reeves in 2001.
 * This heuristic considers the idle time of the machines and the artificial flow time to index the jobs to append.
 */
CIndividual * LRnm(int size, PFSP * fsp);

/*
 * Non deterministic version constructive heuristic proposed by Liu and Reeves in 2001.
 * Sample among the jobs to append proportinally to their index value.
 */
CIndividual * NonDeterministic_LRnm(int size, PFSP * fsp);

/*
 * Non deterministic version constructive heuristic proposed by Liu and Reeves in 2001.
 * Sample among the first 5 jobs the jobs to append proportinally to their index value.
 */
CIndividual * Mixed_NonDeterministic_LRnm(int size, PFSP * fsp);
int SamplePosition(int * indexValues, int size);

int IndexFunction(int * partialSequence, int k, int n, int i,int *U, PFSP * fsp);
int IdleTime(int * partialSequence, int job_i, int position_k, int n, PFSP * fsp);
int ArtificialTime(int * partialSequence, int position_k, int n, int job_i,int * U, PFSP * fsp);
