/*  ===============================================================================
 *  Program:        EDA (Estimation Distribution Algorithms)
 *  Module:         EDA.cpp : Defines the entry point for the console application.
 *  Date:           23-Dic-2011
 *  Author:         Josu Ceberio
 *  Description:    
 *      Calculates the optimum solution of a problem following an EDA approach. 
 *      All the problem specification is defined in Problem.cpp. The rest of the
 *        files should remain unaltered.
 *      Output is displayed only in the screen. The function WriteSolution can 
 *        be modified in order to generate the desired aoutput format.
 *
 *  History: 
 *
 *		23-Dic-2011 - Mallows probabilistic model for permutations EDA added by Josu Ceberio.
 *					  
 *  =============================================================================== 
 */ 


#include "EDA.h"
#include "Solution.h"
#include "Problem.h"
#include "LocalSearch.h"
#include "PermutationTools.h"
#include "Tools.h"
#include "Seed.h"
#include "Variables.h"
#include <stdlib.h>
#include <sys/time.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
using std::istream;
using std::ostream;
using namespace std;
#define itoa(a,b,c) sprintf(b, "%d",a)
#include "string.h"

// time calculation variables.
timeval start,stop;

// Number of generations carried out at the moment.
int GEN_NUM;

//The Theta upper value for the kendall distance.
double UPPER_THETA_KENDALL=0;

//The Theta upper value for the kendall distance.
double LOWER_THETA_KENDALL=0;

// Best fitness value found in the execution.
int BEST_FITNESS=0;

//Probability assigned to the consensus ranking.
double CR_PROBABILITY=0.1;

int MUL=1;

// The size of the population.
int POP_SIZE;

// The number of selected individuals.
int SEL_SIZE;

// The offspring size.
int OFFSPRING_SIZE;

// Number of restarts carried out during the evolutionary process.
int RESTARTS=0;

// Whether elitism is used or not.
int ELITISM=1;

// The individual size.
int IND_SIZE;

// The value of the optimal soluction when it's known.
double OPTIMAL;

// The number of states the genes can take.
int * STATES;

// Number of evaluations performed.
unsigned long long int EVALUATIONS = 0;

// Convergence evaluation of the best fitness.
unsigned long long int CONVERGENCE_EVALUATIONS = 0;

// Maximum number of evaluations allowed performed.
unsigned long long int MAX_EVALUATIONS = 0;

//Percentage of the evaluations assigned for the heuristic processes below.
float PERCENTAGE=0;

// Maximum number of generations (used by the stopping criterium).
// When MAX_GENERATIONS=0 -> no limit
int MAX_GENERATIONS=30;

// Maximum number of generations without improvement.
int MAX_GENERATIONS_NO_IMPROVEMENT=30;

//Maximum number of restarts without improvement.
int MAX_RESTARTS_NO_IMPROVEMENT=30;

// Number of iterations without improvement.
int NO_IMPROVEMENT_GENERATIONS=0;

// Best result convergente iteration.
int CONVERGENCE_ITERATION=0;

// Theta spread parameter for the mallows model.
double THETAS_AVERAGE=0;

// Average fitness value of the sampled solutions.
double AVERAGE_SAMPLED_FITNESS=0;

// Name of the file where the result will be stored.
char OUTPUTFILE[50];

// Name of the file where the log results will be stored (optional).
char LOGFILE[50];

char DATA_FILE_NAME[50];

// The seed asigned to the process
int SEED;

//the solution calculated by the EDA.
CIndividual * EDA_SOLUTION;

//Improvement rate of the EDA.
double EDA_IMPROVEMENT_RATE;

// Input file stream of the instance.
ifstream fdatafile;

// Output file stream of the result.
ofstream foutput;

// Output file stream of the log.
ofstream flog;

// Output file stream of the best log.
ofstream flog2;


CIndividual * BEST;

/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
	
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
	
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
		
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
			
            if (isalnum(chOpt) || ispunct(chOpt))
            {	
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
				
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
							
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
	
    iArg++;
	
    *ppszParam = pszParam;
    return (chOpt);
}

/*
 * Help command output.
 */
void usage(char *progname)
{
          cerr
	      << "Usage: " << progname << " -N pop_size -S sel_size  -a caching -i simulation_type" << endl
	      << "        -l learning_type -c score -f offspring_size -e elitism -g save_structures -o output_file -w data_filename" << endl
	      << endl
	      << "-N pop_size: number of individuals in the population. (def:2000)" << endl
	      << "-S sel_size: number of selected individuals. (def:1000)" << endl
	      << "-c score: type of score (only for EBNA): " << endl
	      << "       BIC (0) or K2 (1). (def:0)" << endl
	      << "-l learning: how the Bayesian network is learned:" << endl
	      << "       UMDA (0), EBNA with B algorithm (1), " << endl
	      << "       EBNA with local search (2), PBIL with alpha = 0.5 (3)," << endl
	      << " 	 BSC (4), TREE(5), MIMIC(6), EBNA K2 + penalization (7)," << endl
	      << "   EBNA PC (8) or EBNA with global search (9)," << endl
	      << "   Permutations Marginal Modelling (11), Mallows (12)." << endl
	      << "-b bias correction: (only for K-order marginals based EDA): [0-1]  (def:1)"<<endl
	      << "-f offspring_size: how many individuals are created in" << endl
	      << "       each generation. (def:1999)" << endl
	      << "-e elitism: how the next population is created: " << endl
	      << "       elitism (1) or no-elitism (0). (def:1)" << endl
	      << "-a caching: whether the values of the evaluated individuals.  (def:1)" << endl	      
          << "-i simulation: type of simulation: PLS (0), " << endl
		  << "       PLS forcing all values LTM (1) and ATM (2)," << endl
		  << "       correction after generation (3) and penalization (4).(def:0)" << endl	
	      << "-g save_structure: whether the structures of each generation " << endl	      
	      << "       have to be saved or not.  (def:0)" << endl
	      << "-P part_time: work in parts, execute only until generation 'part_time'  " << endl	      
	      << "       and store partial population in file 'pop.out'. (def:0,no output)" << endl
          << "-o output_file: name of output_file to store the results" << endl
	      << "       (optional parameter). (def:-)" << endl
		  << "-d log_file: name of log_file to store the log results" << endl
		  << "-t problem type: 'tsp','tsf','qap','fsp' or 'lop'"<< endl;
}

/*
 * Obtaint the execution parameters from the command line.
 */
bool GetParameters(int argc,char * argv[])
{
	char c;
    if(argc==1)
    {
    	usage(argv[0]);
        return false;
    }
    //#ifdef WIN32

	char** optarg;
	optarg = new char*[argc];
    while ((c = GetOption (argc, argv, "F:hN:S:f:e:o:p:x:d:t:w:",optarg)) != '\0')
    {
    	switch (c)
    	{
		
            case 'h' :  usage(argv[0]);
                        return false;
                        break;

            case 'N' :  POP_SIZE = atoi(*optarg);
					    break;

            case 'S' :	SEL_SIZE = atoi(*optarg);
                        break;

            case 'f' :  OFFSPRING_SIZE = atoi(*optarg);
                        break;

            case 'e' :  ELITISM = atoi(*optarg);
                        break;

            case 'x' :  SEED = atoi(*optarg);
						break;

            case 'p' :  MUL = atoi(*optarg);
						break;
				
			case 'u':	UPPER_THETA_KENDALL=atof(*optarg);
						break;
				
            case 'o' :  strcpy(OUTPUTFILE, *optarg);
                          //OUTPUTFILE=optarg;
                          // open the output file
                        if (OUTPUTFILE)
                        {
                        	foutput.open(OUTPUTFILE);
                            if (!foutput) {
                                cerr << "Could not open file " << OUTPUTFILE << ". Ignoring this file." << endl;
                                OUTPUTFILE[0]='\0';
                            }
                        }
                        break;
				
			case 'd' :  strcpy(LOGFILE, *optarg);
				//LOGFILE=optarg;
				// open the log file
				if (LOGFILE)
				{
					#ifdef THETA_SPEED
					flog.open(LOGFILE);
					if (!flog) {
						cerr << "Could not open file " << LOGFILE << ". Ignoring this file." << endl;
						LOGFILE[0]='\0';
					}
					flog.close();
					#endif
				}
				break;
				
			case 'w':  strcpy(DATA_FILE_NAME, *optarg);
				if (DATA_FILE_NAME){
					fdatafile.open(DATA_FILE_NAME);
					if (!fdatafile){
						cerr << "Could not open file " << DATA_FILE_NAME << ". Ignoring this file." << endl;
						DATA_FILE_NAME[0]='\0';
					}
					fdatafile.close();
				}
				break;

		}
     }

     delete [] optarg;


	if(!ELITISM && OFFSPRING_SIZE>POP_SIZE)
	{
		cerr
			<< "Warning: If no elitism is used when creating the new population" << endl
			<< "         offspring_size cannot be higher than pop_size. " << endl
			<< "         offspring_size truncated to " << POP_SIZE << "." << endl
			<< endl;

		OFFSPRING_SIZE = POP_SIZE;
	}

	if(SEL_SIZE>POP_SIZE)
	{
		cerr
			<< "Warning: If truncation selection is used, sel_size cannot be" << endl
			<< "        higher than pop_size. sel_size truncated to" << POP_SIZE << "." << endl
			<< endl;

		SEL_SIZE = POP_SIZE;
	}

	return true;
}

/*
 * This method returns the corresponding evaluations number to the parameters n (jobs) and m (machines).
 * The evaluations are calculated from one execution of the AGA algorithm for each type of instance with the
 * stopping criteria of n*m*0.4 seconds.
 */
int GetEvaluationsNumber(int n, int m)
{
	switch (n) 
	{
		case 20:
			if(m==5)
				return 182224100;
			else if (m==10)
				return 224784800;
			else 
				return 256896400;
			break;
			
		case 50:
			if(m==5)
				return 220712150;
			else if (m==10)
				return 256208100;
			else
				return 275954150;
			break;
			
		case 100:
			if(m==5) 
				return 235879800;
			else if(m==10)
				return 266211000;
			else
				return 283040000;
			break;
			
		case 200:
			if (m==10)	
				return 272515500;
			else
				return 287728850;
			break;
		/** RANDOM INSTANCES EVALUATIONS **/
							
		case 250:
			if (m==10)
				return 267779100;
			else
				return 284574350;
			break;
			
		case 300:
			if (m==10)
				return 273847500;
			else
				return 284672900;
			break;
			
		case 350:
			if (m==10)
				return 278369000;
			else
				return 286225300;
			break;	
			
		case 400:
			if (m==10)
				return 275491800;
			else
				return 283913500;
			break;
			
		case 450:
			if (m==10)
				return 277455350;
			else
				return 269271450;
			break;
			/** END RANDOM INSTANCES EVALUATIONS **/
		case 500:
				return 260316750;
			break;
			
		default:
				return n*1000000;
				break;
		}
}

/*
 * Prints in a given file 'length' integer elements of a given array.
 */
void PrintInFile(int* array, int length, string text, ofstream& file)
{
	file<<text;
	for (int i=0;i<length;i++){
		file<<array[i]<<" ";
	}
	file<<" "<<endl;
}

/*
 * Creates a set of random instances with the given number of jobs and machines.
 */
void CreateRandomInstance(int jobs, int machines, PFSP * fsp)
{
	for (int i=0;i<10;i++)
	{
		stringstream myString;
		myString << "cebe"<<jobs<<"_"<<machines<<"_"<<i<<".fsp";
		fsp->GenerateRandomInstance(jobs,machines,myString.str());
	}
}

/*
 * Main function.
 */
int main(int argc, char* argv[])
{
	//Initialize seed.
	seed();
	
	//Start timer.
	gettimeofday(&start,NULL);
		
	//Parse the parameters from the command line.
	if(!GetParameters(argc,argv)) return -1;
	
	//Read the problem instance to optimize.
	if (GetProblemInfo(DATA_FILE_NAME) < 0) return -2;
	
	//Flag to print the convergence of the average thetas. Opens the file for the log.
	#ifdef THETA_SPEED
		//open flogfile
		flog.open(LOGFILE);
	#endif

	//Initialize the population.
	cout<<"Initializing population...."<<endl;
	CSolution solution;
	
	BEST=solution.GetBestIndividual()->Clone();
	BEST_FITNESS=-solution.GetBestIndividual()->Value();
	PFSP * fsp=GetFlowshopProblem();
	int max_seconds=fsp->JOB_NUM*fsp->MACHINE_NUM*0.4;
	MAX_EVALUATIONS=GetEvaluationsNumber(fsp->JOB_NUM,fsp->MACHINE_NUM);
	MAX_EVALUATIONS=MAX_EVALUATIONS*MUL;
	int first_solution=0;
	
	//create new instances.
	//CreateRandomInstance(550,10,fsp);
	
	//Print execution parameters previous optimization.
	cout<<"Starting evolutionary algorithm..."<<endl;
	cout<<"Instance to optimize: "<<DATA_FILE_NAME<<endl;
	cout<<"Population size: "<<POP_SIZE<<endl;
	cout<<"Offspring size: "<<OFFSPRING_SIZE<<endl;
	cout<<"Selection size: "<<SEL_SIZE<<endl;
	cout<<"Max generations: "<<MAX_GENERATIONS<<endl;
	cout<<"Max generations non improvement: "<<MAX_GENERATIONS_NO_IMPROVEMENT<<endl;
	cout<<"Max restarts non improvement: "<<MAX_RESTARTS_NO_IMPROVEMENT<<endl;
	cout<<"Max evaluations: "<<MAX_EVALUATIONS<<endl;
	cout<<"Max execution seconds: "<<max_seconds<<endl;
	cout<<"Upper theta bound: "<<UPPER_THETA_KENDALL<<endl;
	cout<<"Execution seed: "<<SEED<<endl;

	
	//Evolutionary process starts.
	//If the hybrid approach is executed, the number of evolutions must be shared.
	#ifdef VNS_FINAL_EVALUATIONS //B algorithm
		int prov_evaluations=MAX_EVALUATIONS*VNS_FINAL_EVALUATIONS;
		for (;EVALUATIONS<prov_evaluations && RESTARTS!=MAX_RESTARTS_NO_IMPROVEMENT /*&& NO_IMPROVEMENT_GENERATIONS<MAX_GENERATIONS_NO_IMPROVEMENT*/;)
	#else 
		for (;EVALUATIONS<MAX_EVALUATIONS ;)
	#endif
	{	
		if ((GEN_NUM%1000)==0)
	            cout<<GEN_NUM<<";"<<EVALUATIONS<<";"<<-solution.GetBestIndividual()->Value()<<";"<<CONVERGENCE_ITERATION<<";"<<CONVERGENCE_EVALUATIONS<<","<<THETAS_AVERAGE<<endl;
		//Flag to print the convergence of the average thetas. Prints the generation number and the average theta in the file.
		#ifdef THETA_SPEED
		if ((GEN_NUM == 10) || ((GEN_NUM % 100) == 0))
			flog<<GEN_NUM<<","<<BEST->Value()<<","<<solution.GetBestIndividual()->Value()<<","<<THETAS_AVERAGE<<endl;
		#endif

		GEN_NUM = solution.GetGenerationNumber() + 1;
		if (GEN_NUM==1)
			first_solution=-solution.GetBestIndividual()->Value();

		//Saves the best solution if changed.
		if (solution.BestIndividualChanged() && GEN_NUM!=0)
		{			
			CONVERGENCE_ITERATION=GEN_NUM;
			CONVERGENCE_EVALUATIONS=EVALUATIONS;
			NO_IMPROVEMENT_GENERATIONS=0;
		}
		else
			NO_IMPROVEMENT_GENERATIONS++;

		solution.Improve(GEN_NUM);
	}

	if (solution.GetBestIndividual()->Value()<BEST->Value())
	{
		solution.GetBestIndividual()=BEST;
	}

	//Saves the solution calculated by the EDA.
	EDA_SOLUTION=solution.GetBestIndividual()->Clone();

	//Applies a VNS of 50 iterations and 10 shakes to the solution calculated by the EDA.
	#ifdef VNS_FINAL_ITERATIONS
		//Apply a hard VNS(50,10) to the best individual.
		CIndividual * best_ind=solution.GetBestIndividual();
		best_ind=VNS(GetFlowshopProblem(),best_ind,50,10);
		solution.GetBestIndividual()=best_ind;
	#endif

	//Applies a non stop VNS until MAX_EVALUATIONS are consumed.
	#ifdef VNS_FINAL_EVALUATIONS
		double upper=first_solution+EDA_SOLUTION->Value();
		CIndividual * best_ind=solution.GetBestIndividual();
		best_ind=VNS(GetFlowshopProblem(),best_ind,10);
		solution.GetBestIndividual()=best_ind;
		double lower= first_solution+best_ind->Value();
		EDA_IMPROVEMENT_RATE=upper/lower;
	#endif

	//Flag to print the convergence of the average thetas. Closes the file of the log.
	#ifdef THETA_SPEED
		//close flogfile
		flog.close();
	#endif

	//Write solution in the output file.
	solution.WriteSolution();
	int best=solution.GetBestIndividual()->Value();

	RemoveProblemInfo();
	gettimeofday(&stop,NULL);
	return -best;
}


