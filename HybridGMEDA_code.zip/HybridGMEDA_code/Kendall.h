/*
 *  Kendall_Distance.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/17/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#ifndef _KENDALL_
#define _KENDALL_
#define MAXIT 1000
#include "Population.h"

class Kendall_Model
{
public:

	/*
	 * Problem size.
	 */
	int ProblemSize;
	
	/*
	 * Vj probabilities matrix.
	 */
	double** VProbs;
	
	/*
	 * Spread parameters vector.
	 */
	double* ThetaParameters;
			
	/*
	 * Spread parameters vector bounds
	 */
	double * ThetaBounds;
	
	/*
	 * Psi normalization constant.
	 */
	double* Psis;
	
	/*
	 * Indicates the rank of the job when the corresponding theta achieve the upper bound value for it.
	 */
	int * ThetaConvergenceRanking;

	/*
	 * The constructor.
	 */
	Kendall_Model(int n, int m);
	
	/*
	 * The destructor. It frees the memory allocated at the construction of the kendall model.
	 */
	virtual ~Kendall_Model();
	
	/*
	 * Learns a Mallows model based on the Kendall distance and the individuals in the model.
	 */
	void Learn(int * consensusRanking, int **&cases, int sel_total, double upper_bound);
	
	/*
	 * Learns a Mallows model based on the Kendall distance and Qjl adjacency matrix learnt previously.
	 */
	void Learn(int * consensusRanking, double ** Qjl, double upper_bound);

	/*
	 * Learns a Mallows model based on the Kendall distance and Qjl adjacency matrix learnt previously.
	 * Theta parameters are already assigned.
	 */
	void Learn(int * consensusRanking, double ** Qjl, double upper_bound, double * thetas);
	
	/*
	 * Given the consensus ranking, it samples a new individual.
	 */
	void Sample(int * permutation, int * consensusRanking);
	
	/*
	 * Returns the theta parameters estimated.
	 */
	double * GetThetaParameters();
	
	/*
	 * Creates a population with the consensus ranking and theta paramater assigned.
	 */
	void CreatePopulation(double * thetaParameters, CPopulation * population, int * consensusRanking);
	
private:
	
	/*
	 * Calculates the spread theta parameters from the ConsensusRanking and the individuals in the population.
	 */
	void CalculateThetaParameters(int*consensus, int**&cases, double cases_num, double * thetas, double upper_bound);	
	
	/*
	 * Calculates the spread theta parameters from the ConsensusRanking and the Qjl adjacency matrix learnt previously.
	 */
	void CalculateThetaParameters(int*consensus, double ** Qjl, double * thetas, double upper_bound);	
	
	/*
	 * Calculates the total Psi normalization constant from the ThetaParameters and psi-s vector.
	 */
	void CalculatePsiConstants(double* thetas, double* psi);
	
	/*
	 * Generates a permutation from a v vector.
	 */
	void GeneratePermuFromV(int * v, int * permu, int n);
		
	/*
	 * Calculates the needed theta (upper bound) to assign the given probability to the consensus ranking.
	 */
	double CalculateThetaUpperBound(double CR_Probability);
	
	/*******************************  NEWTON-RAPSHON ALGORITHM for UPPER THETA ESTIMATION ********************************/
	
	/*
	 * Estimates theta parameters by means of running newton iterative algorithm.
	 */
	double NewtonRaphsonMethod(double initialGuess, double CR_Probability);
	
	/*
	 * Theta parameter estimation function.
	 */
	float f(double theta, int n, double CR_Probability);
	
	/*
	 * Theta parameter estimation function derivation.
	 */
	float fdev(double theta, int n, double CR_Probability);
	
	/*
	 * Calculates Newton algorithms f and fdev functions.
	 */
	void funcd(float theta, float*ff, float*ffdev, double CR_Probability);
	
	/*
	 * Newton - Rapshon execution algorithm.
	 */
	float rtsafe(float x1, float x2, float xacc, double CR_Probability);
	
	/*******************************  NEWTON RAPSHON ALGORITHM  ********************************/
	
	/*
	 * Estimates theta parameters by means of running newton iterative algorithm.
	 */
	double NewtonRaphsonMethod(double initialGuess, double* Vjs, int j, double upper_bound);
	
	/*
	 * Theta parameter estimation function.
	 */
	double f(double theta, int n, double* VjMeans, int j);
	
	/*
	 * Theta parameter estimation function derivation.
	 */
	double fdev(double theta, int n, int j);
	
	/*
	 * Calculates Newton algorithms f and fdev functions.
	 */
	void funcd(double theta, double*ff, double*ffdev, double* VjMeans, int j);
	
	/*
	 * Newton - Rapshon execution algorithm.
	 */
	double rtsafe(double x1, double x2, double xacc, double* VjMeans, int j);
	
};

#endif

#ifndef _KENDALL_SIMPLE_MODEL_
#define _KENDALL_SIMPLE_MODEL_

#include "Population.h"

class Kendall_Simple_Model
{
public:
	
	/*
	 * Problem size.
	 */
	int ProblemSize;
	
	/*
	 * Vj probabilities matrix.
	 */
	double** VProbs;
	
	/*
	 * Spread parameter.
	 */
	double ThetaParameter;
	
	/*
	 * Psi normalization constant.
	 */
	double* Psis;
	
	/*
	 * The constructor.
	 */
	Kendall_Simple_Model(int size);
	
	/*
	 * The destructor. It frees the memory allocated at the construction of the kendall model.
	 */
	virtual ~Kendall_Simple_Model();
	
	/*
	 * Learns a Mallows model based on the Kendall distance and the individuals in the model.
	 */
	void Learn(int * consensusRanking, int **&cases, int sel_total, double upper_bound);
	
	/*
	 * Given the consensus ranking, it samples a new individual.
	 */
	void Sample(int * permutation, int * consensusRanking);
	
	/*
	 * Returns the theta parameters estimated.
	 */
	double GetThetaParameter();
	
	/*
	 * Creates a population with the consensus ranking and theta paramater assigned.
	 */
	void CreatePopulation(double theta);
	
private:
	
	/*
	 * Calculates the spread theta parameters from the ConsensusRanking and the individuals in the population.
	 */
	double CalculateThetaParameter(int*ConsensusRanking, int**&cases, double cases_num, double upper_bound);
	
	/*
	 * Calculates the total Psi normalization constant from the ThetaParameters and psi-s vector.
	 */
	double CalculatePsiConstants(double theta, double * psis);
	
	/*
	 * Generates a permutation from a v vector.
	 */
	void GeneratePermuFromV(int * v, int * permu, int n);
	
	
	/*******************************  NEWTON-RAPSHON ALGORITHM for THETAS ESTIMATION ********************************/
	
	/*
	 * Estimates theta parameters by means of running newton iterative algorithm.
	 */
	double NewtonRaphsonMethod(double initialGuess, double* Vjs, double upper_bound);
	
	/*
	 * Theta parameter estimation function.
	 */
	float f(double theta, int n, double* VjMeans);
	
	/*
	 * Theta parameter estimation function derivation.
	 */
	float fdev(double theta, int n);
	
	/*
	 * Calculates Newton algorithms f and fdev functions.
	 */
	void funcd(float theta, float*ff, float*ffdev, double* VjMeans);
	
	/*
	 * Newton - Rapshon execution algorithm.
	 */
	float rtsafe(float x1, float x2, float xacc, double* VjMeans);
	
	
};

#endif
