/*
 *  GeneralizedMallowsModel.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 4/26/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */


#ifndef GENERALIZEDMALLOWSMODEL_H__
#define GENERALIZEDMALLOWSMODEL_H__

#include "Kendall.h"
#include "Individual.h"
#include "Population.h"
#include <list>
#include <vector>


class CGeneralizedMallowsModel
{
	
public:
	
	//Kendall distance model
	Kendall_Model * m_kendall_model;
	
	//Problem size.
    int ProblemSize;
	
	//Consensus Permutation Ranking.
	int* ConsensusRanking;
	
	//Aprioris matrix.
	double ** Gammajl;
	
    // The constructor. It initializes a generalized mallows model empty for a given distance. Distance-> 0-Kendall, 1-Cayley
	CGeneralizedMallowsModel();
	
    // The destructor.
    virtual ~CGeneralizedMallowsModel();
	
    // It estimates the generalized mallows model from the given cases.
    void LearnProbabilities(int **&cases, double ** & values, double sel_total, int* best_individual);
	
    // It creates a new individual sampling the mallows probabilistic model.
    CIndividual * Simulate(int * consensusRanking);
	
	// Creates a population with the consensus ranking and theta paramaters assigned.
	void CreatePopulation(double * thetaParameters, CPopulation * population, int * consensusRanking);
		
	/*
	 * Calculates if theta values did converge to the upper bound.
	 */
	bool ThetasConverge();
	
	//Calculates ThetaParameters average value.
	double GetThetasAverage();
	
	/*
	 * Calculates the probability of the individual given the probabilistic model.
	 */
	double Probability(int * individual);
	
private:
		
	// Calculates de consensus permutation from the given population cases.
	void CalculateConsensusRanking(int**&cases, double sel_total, int* consensusRanking);
	
	// Given the consensus ranking, it samples a new individual.
	void Sample(int*permu, int*consensus);
		
	void MostLikelyConsensusRanking(int * consensusPermutation, int**&cases, int sel_total);
	

	

	
	/******************* New approach for the Generalized Mallows Learning**********************/
	
	void CalculateAdjacencyMatrixQjl(int**&cases, double sel_total,double ** Qjl);
	
	void CalculateAdjacencyMatrixQjl(CPopulation * population, double sel_total,double ** Qjl);
	
	// Calculates de consensus permutation from the given population cases with the heuristic proposed by Flinger.
	void CalculateConsensusRankingFlinger(int*consensusPermutation, double ** Qjl);
	
	void CalculateThetaParameters2(int*consensus, double ** Qjl, double * thetas);
	
	void IncludeAPriorisGammaMatrix(double ** Qjl, double N, double v);
		
	void NormalizeMatrix_Rows(int** matrix, double** results,int size);

};
#endif
