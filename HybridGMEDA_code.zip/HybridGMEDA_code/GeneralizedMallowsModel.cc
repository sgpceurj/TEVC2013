/*
 *  GeneralizedMallowsModel.cc
 *  DiscreteEDA
 *
 *	This class implements the learning and sampling of the Generalized Mallows probabilistic model.
 *
 *  Created by Josu Ceberio Uribe on 4/26/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "EDA.h"
#include "GeneralizedMallowsModel.h"
#include "Problem.h"
#include "LocalSearch.h"
#include "SortingTools.h"
#include "PermutationTools.h"
#include "Tools.h"
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <list>
#include <vector>
using std::cerr;
using std::cout;
using std::endl;

/*
 * Class constructor.
 */
CGeneralizedMallowsModel::CGeneralizedMallowsModel()
{
	ProblemSize=IND_SIZE;
	ConsensusRanking=new int[ProblemSize];
	
	m_kendall_model= new Kendall_Model(ProblemSize,GetFlowshopProblem()->MACHINE_NUM);

	
	#ifdef MALLOWS_FLIGNER
			
	#ifdef APRIORIS_TFT
	
		//1.-Initialize matrix Gammajl and delays/margins matrix.
		Gammajl=(double**)malloc(sizeof(double*)*ProblemSize);
		int ** partialTFTs=(int**)malloc(sizeof(int*)*ProblemSize);
		int * residualProfile= (int*)malloc(sizeof(int)*ProblemSize);
		for (int i=0;i<ProblemSize;i++)
		{
			residualProfile[i]=0;
			Gammajl[i]=(double*)malloc(sizeof(double)*ProblemSize);
			partialTFTs[i]=(int*)malloc(sizeof(int)*ProblemSize);
			for (int j=0;j<ProblemSize;j++)
			{
				Gammajl[i][j]=0;
				partialTFTs[i][j]=0;
			}
		}
	
	
		//2.-Calculate aprioris from partial TFTs matrix normalizing values.
		GetFlowshopProblem()->JobsPartialTFTAnalysis(partialTFTs,residualProfile);
		NormalizeMatrix_Rows(partialTFTs,Gammajl,ProblemSize);
		//PrintMatrix(partialTFTs,IND_SIZE,IND_SIZE,"Partial TFTs: " );
		//PrintMatrixDouble(Gammajl,IND_SIZE,IND_SIZE,"Partial TFTs norm: " );
	
		//4.-delete matrix of delays
		for (int i=0;i<ProblemSize;i++)
		{
			delete [] partialTFTs[i];
		}
		delete [] partialTFTs; 
		delete [] residualProfile;
	
	#endif
	
	#ifdef APRIORIS_DELAYS
		//1.-Initialize matrix Gammajl and delays/margins matrix.
		Gammajl=(double**)malloc(sizeof(double*)*ProblemSize);
		int ** delays=(int**)malloc(sizeof(int*)*ProblemSize);
		int * residualProfile= (int*)malloc(sizeof(int)*ProblemSize);
		for (int i=0;i<ProblemSize;i++)
		{
			residualProfile[i]=0;
			Gammajl[i]=(double*)malloc(sizeof(double)*ProblemSize);
			delays[i]=(int*)malloc(sizeof(int)*ProblemSize);
			for (int j=0;j<ProblemSize;j++)
			{
				Gammajl[i][j]=0;
				delays[i][j]=0;
			}
		}
	
		//2.-Calculate aprioris from delays/margins matrix normalizing values.
		GetFlowshopProblem()->JobsDelayMarginAnalysis(delays, residualProfile);
		NormalizeMatrix_Rows(delays,Gammajl,ProblemSize);
		//PrintMatrix(delays,IND_SIZE,IND_SIZE,"Delays: " );
		//PrintMatrixDouble(Gammajl,IND_SIZE,IND_SIZE,"Delays: " );
	
		//4.-delete matrix of delays
		for (int i=0;i<ProblemSize;i++)
		{
			delete [] delays[i];
		}
		delete [] delays;
		delete [] residualProfile;
	
	#endif
	
	#ifdef APRIORIS_IDLETIMES
	//1.-Initialize matrix Gammajl and delays/margins matrix.
	Gammajl=(double**)malloc(sizeof(double*)*ProblemSize);
	int ** idleTimes=(int**)malloc(sizeof(int*)*ProblemSize);
	for (int i=0;i<ProblemSize;i++)
	{
		Gammajl[i]=(double*)malloc(sizeof(double)*ProblemSize);
		idleTimes[i]=(int*)malloc(sizeof(int)*ProblemSize);
		for (int j=0;j<ProblemSize;j++)
		{
			Gammajl[i][j]=0;
			idleTimes[i][j]=0;
		}
	}
		//2.-Calculate aprioris from delays/margins matrix normalizing values.
	GetFlowshopProblem()->MachineIdleTimeAnalysis(idleTimes);
	//PrintMatrix(idleTimes,IND_SIZE,IND_SIZE,"idleTimes: " );
	NormalizeMatrix_Rows(idleTimes,Gammajl,ProblemSize);
	
	//PrintMatrixDouble(Gammajl,IND_SIZE,IND_SIZE,"idleTimes: " );
	//4.-delete matrix of delays
	for (int i=0;i<ProblemSize;i++)
	{
		delete [] idleTimes[i];
	}
	delete [] idleTimes;
	
	#endif
	
	#endif
}

/*
 * Class destructor.
 */
CGeneralizedMallowsModel::~CGeneralizedMallowsModel()
{
	#ifdef MALLOWS_FLIGNER
	
		for	(int i=0;i<ProblemSize;i++)
			delete [] Gammajl[i];
		delete [] Gammajl;  
	
	#endif

	delete m_kendall_model;

	delete [] ConsensusRanking;

}

/******************************  SIMULATING MODEL  *******************************/
/*
 * Simulates a new individual sampling the probabilistic model.
 */
CIndividual * CGeneralizedMallowsModel::Simulate(int * consensusRanking)
{
	//1.- Create New individual.
	//cout << "1. Create a new individual."<<endl;
	CIndividual * individual = new CIndividual(IND_SIZE);
	int* genes=individual->Genes();
	
	//2.- Sample permutation from Vs.
	//cout << "2. Sample permutation."<<endl;
	m_kendall_model->Sample(genes,consensusRanking);
		
	//cout<<individual<<endl;
	//cout << "Simulation finished..."<<endl;
	return individual;
}

/*******************************  LEARNING MODEL  ********************************/

/*
 * Estimates the mallows model from the given cases.
 */
void CGeneralizedMallowsModel::LearnProbabilities(int **&cases,double **&values, double sel_total, int* best_individual)
{
	#ifndef MALLOWS_FLIGNER
		
		//1.- Calculate the consensus ranking/permutation.
		CalculateConsensusRanking(cases,(int)sel_total,ConsensusRanking);

		//2.- Learn model.
		m_kendall_model->Learn(ConsensusRanking, cases,(int)sel_total,UPPER_THETA_KENDALL);
	
	#else
		
		//1.- Calculate the consensus ranking/permutation.
		//Initialize matrix Qjl.
		double **Qjl=(double**)malloc(sizeof(double*)*ProblemSize);
		for (int i=0;i<ProblemSize;i++)
		{
			Qjl[i]=(double*)malloc(sizeof(double)*ProblemSize);
			for (int j=0;j<ProblemSize;j++)
				Qjl[i][j]=0;
		}
		CalculateAdjacencyMatrixQjl(cases, sel_total, Qjl);
		//if (drand48() < MALLOWS_FLIGNER)
		if (GEN_NUM==1)
		{
			IncludeAPriorisGammaMatrix(Qjl, 0.0, 1.0);
			CalculateConsensusRankingFlinger(ConsensusRanking, Qjl);
			//2.- Learn model.
			double * predefined_thetas= new double[IND_SIZE-1];
			for (int i=0; i<IND_SIZE-1;i++) predefined_thetas[i]=1;
			m_kendall_model->Learn(ConsensusRanking, Qjl, UPPER_THETA_KENDALL,predefined_thetas);
			delete [] predefined_thetas;
		}
	else {
		CalculateConsensusRankingFlinger(ConsensusRanking, Qjl);
		//2.- Learn model.
		m_kendall_model->Learn(ConsensusRanking, Qjl, UPPER_THETA_KENDALL);
		
	}

		//3.-delete matrix of delays
		for (int i=0;i<ProblemSize;i++)
			delete [] Qjl[i];
		delete [] Qjl;
	
	#endif
}

/*
 * Calculates de consensus permutation from the given population cases.
 */
void CGeneralizedMallowsModel::CalculateConsensusRanking(int**&cases, double sel_total, int*consensusPermutation)
{
	int i, j;
	//Initialize matrix to zeros.
	int FrecuencyMatrix[ProblemSize][ProblemSize];
	for (i=0;i<ProblemSize;i++)
	{
		for (j=0;j<ProblemSize;j++)
			FrecuencyMatrix[i][j]=0;
	}
	
	int geneValue, genePosition;
	
	//cout<<"Filling frecuency matrix"<<endl;
	//Fill frecuency matrix reviewing individuals in the population.
	//para cada permutación muestreada:
	for (i = 0; i < sel_total; i++)
	{
		int* individua = cases[i];
		//PrintArray(individua, ProblemSize, "case: ");
		for (j=0;j<ProblemSize;j++)
		{
			geneValue=j;
			genePosition=individua[j];
			FrecuencyMatrix[genePosition][geneValue]++;
		}
	}
	
	//cout<<"Calculate consensus vector: "<<endl;
	//Calculate consensus vector.
	double * consensusVector=new double[ProblemSize];
	int job,position;
	double positionMean;
	for (job=0;job<ProblemSize;job++)
	{
		positionMean=0;
		for (position=0;position<ProblemSize;position++)
		{
			positionMean=positionMean+position*FrecuencyMatrix[position][job];
		}
		positionMean=positionMean/sel_total;
		consensusVector[job]=positionMean;	
	}
	
	//PrintArrayDouble(consensusVector,IND_SIZE,"Consensus vector: ");
	//cout<<"Generando la permutacion"<<endl;
	RandomKeys(consensusPermutation, consensusVector,ProblemSize);
	//PrintArray(consensusPermutation,IND_SIZE,"Consensus Permutation: ");
	//cout<<"---------------------"<<endl;
	//cout<<"Encontrar el mejor vecino a un swap de distancia que minimice la suma de la distancias del data set"<<endl
	//MostLikelyConsensusRanking(consensusPermutation,cases,sel_total);
	delete[] consensusVector;
}

/*
void CGeneralizedMallowsModel::MostLikelyConsensusRanking(int * consensusPermutation, int**&cases, int sel_total)
{
	int k,j, best_k, best_j,aux;
	int suma_opt=100000000,suma_improve=0;
	//PrintArray(consensusPermutation,IND_SIZE," CR: ");
	for (k=0;k<IND_SIZE-1;k++)
	{
			j=k+1;

			//swap k and j positions.
			aux=consensusPermutation[k];
			consensusPermutation[k]=consensusPermutation[j];
			consensusPermutation[j]=aux;
			
			//Calculate total sum of distances,
			suma_improve=0;
			for (int index=0;index<sel_total;index++)
			{
				int* indiv = cases[index];
				suma_improve+=Kendall(indiv, consensusPermutation,IND_SIZE);
			}
		
			if (suma_improve<suma_opt)
			{
				//cout<<"improve: "<<suma_improve<<" optimo: "<<suma_opt<<"k: "<<k<<" j: "<<j<<endl;
				//guardar que el mejor swap
				//cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
				best_k=k;
				best_j=j;
				suma_opt=suma_improve;
			}

			//restore the positions swapped previously. 
			aux=consensusPermutation[j];
			consensusPermutation[j]=consensusPermutation[k];
			consensusPermutation[k]=aux;
	}
	aux=consensusPermutation[best_j];
	consensusPermutation[best_j]=consensusPermutation[best_k];
	consensusPermutation[best_k]=aux;
}
*/
/******************* New approach for the Generalized Mallows Learning**********************/

void CGeneralizedMallowsModel::IncludeAPriorisGammaMatrix(double ** Qjl, double N, double v)
{
	int i,j;
	
	PrintMatrixDouble(Gammajl,IND_SIZE, IND_SIZE,"Gamma: ");
	PrintMatrixDouble(Qjl,IND_SIZE, IND_SIZE,"Qjl antes: ");
	//1.-Combine both matrix.
	for (i=0;i<IND_SIZE;i++)
	{
		for (j=0;j<IND_SIZE;j++)
		{
			Qjl[i][j] = (Qjl[i][j]*N + Gammajl[i][j]*v); //  / (double)(N+v); //N+v=1
		}
	}
		
	PrintMatrixDouble(Qjl,IND_SIZE, IND_SIZE,"Qjl despues: ");
}

void CGeneralizedMallowsModel::NormalizeMatrix_Rows(int** matrix, double** results,int size)
{
	int range;
	for (int i=0;i<size-1;i++)
	{
		for (int j=i+1;j<size;j++)
		{
			range=abs(matrix[i][j]) + abs(matrix[j][i]);
			/*if ((matrix[i][j]>0 && matrix[j][i]<0) || (matrix[i][j]<0 && matrix[j][i]>0))
			{//different sign values.
				if (matrix[i][j]>0 && matrix[j][i]<0)
					results[i][j]=0.10;
				else
					results[i][j]=0.90;
			}
			else*/
			if (range==0) results[i][j]=0.5;
			else results[i][j] = 1 - (double)abs(matrix[i][j])/(double)range; //otherwise
			
			results[j][i] = 1 - results[i][j];
		}
	}
	
}

void CGeneralizedMallowsModel::CalculateAdjacencyMatrixQjl(int**&cases, double sel_total,double ** Qjl)
{
	int index, j,l, z, v;
	double proportion=1/sel_total;
	//cout<<"Filling frecuency matrix"<<endl;
	//Fill frecuency matrix reviewing individuals in the population.
	for (index=0;index<sel_total;index++)
	{
		int* indiv = cases[index];
		//PrintArray(indiv,ProblemSize,"Indiv: ");
		for (v=0;v<ProblemSize-1;v++)
		{
			j=indiv[v];
			for (z=v+1;z<ProblemSize;z++)
			{
				l=indiv[z];
				if (j<l)//modificacion
					Qjl[v][z]+=proportion;
				else 
					Qjl[z][v]+=proportion;					
			}
		}
	}
}

void CGeneralizedMallowsModel::CalculateAdjacencyMatrixQjl(CPopulation * population, double sel_total,double ** Qjl)
{
	double proportion=1/sel_total;
	int index, v, j, l,z;
	//cout<<"Filling frecuency matrix"<<endl;
	//Fill frecuency matrix reviewing individuals in the population.
	POSITION pos=population->GetHeadPosition();
	for (index=0;index<sel_total;index++)
	{
		CIndividual * ind= population->GetAt(pos);
		pos= population->GetNext(pos);
		int* indiv = ind->Genes();
		//PrintArray(indiv,ProblemSize,"Indiv: ");
		for (v=0;v<ProblemSize-1;v++)
		{
			j=indiv[v];
			for (z=v+1;z<ProblemSize;z++)
			{
				l=indiv[z];
				if (j<l)//modificacion
					Qjl[v][z]+=proportion;
				else 
					Qjl[z][v]+=proportion;					
			}
		}
	}
}

/*
 * Calculates de consensus permutation from the given population cases with the heuristic proposed by Flinger.
 */
void CGeneralizedMallowsModel::CalculateConsensusRankingFlinger(int*consensusPermutation, double ** Qjl)
{	
	//cout<<"Calculating qlArray"<<endl;
	double * qlArray= new double[ProblemSize];
	for (int l=0;l<ProblemSize;l++)
	{
		double ql=0;
		for (int j=0;j<ProblemSize;j++) ql=ql+Qjl[j][l];
		qlArray[l]=ql;
	}

	RandomKeys(consensusPermutation, qlArray, ProblemSize);
	//cout<<"Encontrar el mejor vecino a un swap de distancia que minimice la suma de la distancias del data set"<<endl;
	//MostLikelyConsensusRanking(consensusPermutation,cases,sel_total);
	delete [] qlArray;
}

double CGeneralizedMallowsModel::GetThetasAverage()
{
	int i;
	double average=0;
	double * ThetaParameters=m_kendall_model->GetThetaParameters();
	for (i=0;i<ProblemSize-1;i++) average+=ThetaParameters[i];
	average=average/(ProblemSize-1);
	return average;
}

/*
 * Calculates if theta values did converge to the upper bound.
 */
bool CGeneralizedMallowsModel::ThetasConverge()
{
	double * ThetaParameters=m_kendall_model->GetThetaParameters();
	double thetasSum=0;
	for (int i=0;i<ProblemSize-1;i++)
	{
		thetasSum+=ThetaParameters[i];
	}
	//cout<<"Thetas sunm: "<<thetasSum<<" limit: "<<(UPPER_THETA_KENDALL*(ProblemSize-1)*0.95)<<endl;
	return (thetasSum>= (UPPER_THETA_KENDALL*(ProblemSize-1)*0.95));
	
}

double CGeneralizedMallowsModel::Probability(int * individual)
{
	int * v= new int[IND_SIZE-1];
	int * composition= new int[IND_SIZE-1];
	int * invertedB= new int[IND_SIZE];
	
	Invert(individual, IND_SIZE, invertedB);	
	Compose(ConsensusRanking,invertedB,composition,IND_SIZE); 
	vVector(v,composition,IND_SIZE);
	
	double exponent=0;
	double Psi=1;
	for (int i=0;i<IND_SIZE-1;i++){
		exponent+=m_kendall_model->ThetaParameters[i]*v[i];
		Psi=Psi*m_kendall_model->Psis[i];
	}

	double probability=exp(-exponent)/Psi;
	return probability;
}
