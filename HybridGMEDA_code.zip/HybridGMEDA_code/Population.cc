// Population.cpp: implementation of the CPopulation class.
//
#include "Population.h"
#include "SortingTools.h"
using std::istream;
using std::ostream;

using std::cerr;
using std::cout;
using std::endl;

/*
 * Constructor function.
 */
CPopulation::CPopulation(): m_individual(NULL), m_next(NULL), m_prev(NULL)
{
	// m_next will be the head of the list and
	// m_prev the tail.
}

/*
 * Destructor function.
 */
CPopulation::~CPopulation()
{
	if(m_next!=NULL) delete m_next;
}

/*
 * It return the node at the head of the list.
 */
POSITION CPopulation::GetHeadPosition()
{
	return m_next;
}

/*
 * It returns the individual at the tail of the list and removes its node.
 */
void CPopulation::RemoveTail()
{
	
	// If the list is empty the function will fail.
	
	 if(m_next==m_prev)
	 {
		 // There is only one individual in the list.
		 delete m_prev;
		 m_next = NULL;
		 m_prev = NULL;
	 }
	 else
	 {
		 // Delete the node at the tail and update the links.
	 
		 CPopulation * last_but_one = m_prev->m_prev;
		 last_but_one->m_next = NULL;
	 
		 delete m_prev;
		 m_prev = last_but_one;
	 }
}

/*
 * Removes the first position of the population.
 */
void CPopulation::RemoveHead()
{
	
	// If the list is empty the function will fail.
	
	if(m_next==m_prev)
	{
		// There is only one individual in the list.
		delete m_prev;
		m_next = NULL;
		m_prev = NULL;
	}
	else
	{
		
		// Delete the node at the tail and update the links.
		CPopulation * all_but_first= m_next->m_next;
		all_but_first->m_prev=NULL;
		
		m_next=all_but_first;
	}
}

/*
 * It moves forward in the list.
 */
POSITION CPopulation::GetNext(POSITION pos)
{
	if(pos==NULL) return NULL;
	else return pos->m_next;
}

/*
 * It returns the individual in the node pointed by pos.
 */
CIndividual * & CPopulation::GetAt(POSITION pos)
{
	// If pos is NULL the function will fail.

	return pos->m_individual;
}

/*
 * It returns the individual at the head of the list.
 */
CIndividual * & CPopulation::GetHead()
{
	// If the list is empty  the function will fail.

	return m_next->m_individual;
}

/*
 * It returns the individual at the tail of the list.
 */
CIndividual * & CPopulation::GetTail()
{
	// If the list is empty the function will fail.

	return m_prev->m_individual;
}

/*
 * It adds the given individual at the end of the list.
 */
void CPopulation::AddTail(CIndividual *individual)
{
	if(m_next==NULL)
	{
		// The list is empty.

		m_prev = new CPopulation;
		m_prev->m_individual = individual;

		m_next = m_prev;
	}
	else
	{
		m_prev->m_next = new CPopulation;
		m_prev->m_next->m_prev = m_prev;
		m_prev = m_prev->m_next;
		m_prev->m_individual = individual;
	}
}

/*
 * It inserts the given individual before the node pointed by pos.
 */
void CPopulation::InsertBefore(POSITION pos, CIndividual *individual)
{
	if(pos==NULL) return; // No position to insert.
	else if(m_next==pos)
	{
		// Insert at the head of the list.

		m_next->m_prev = new CPopulation;
		m_next = m_next->m_prev;////OJOOOORRRR!!!
		m_next->m_next = pos;
		m_next->m_individual = individual;
				
	}
	else
	{
		POSITION aux = pos->m_prev;

		aux->m_next = new CPopulation;
		aux->m_next->m_individual = individual;
		aux->m_next->m_prev = aux;
		aux->m_next->m_next = pos;

		pos->m_prev = aux->m_next;
	}
}

/*
 * Function to add an individual to the population
 */
void CPopulation::AddToPopulation(CIndividual * individual)
{
	POSITION pos;
	
	for(pos=GetHeadPosition(); pos!=NULL && individual->Value() < GetAt(pos)->Value(); pos = GetNext(pos));

	if(pos==NULL)
		AddTail(individual);
	else
		InsertBefore(pos,individual);
	
}

ostream & operator<<(ostream & os,CPopulation & population)
{
  POSITION pos;
  os  << " pop.size: " << POP_SIZE << " indiv.length: " << IND_SIZE << std::endl;
  for(pos = population.GetHeadPosition(); pos!=NULL; pos = population.GetNext(pos))
		os << population.GetAt(pos) << std::endl;
  return os;
}

istream & operator>>(istream & is,CPopulation & population)
{
  char TEXT[50]; //To avoid unwanted characters  , str2[15];
  is >> TEXT >> POP_SIZE >> TEXT >> IND_SIZE;      
  for(int i=0; i<POP_SIZE; i++)
  {
    CIndividual * individual = new CIndividual(IND_SIZE);
    is >> individual;
    population.AddToPopulation(individual);
  }
  return is;
}

/*
 * Exports the population to the file 'FileName'.
 */
void CPopulation::ExportPopulation(char * FileName)
{
	ofstream file;

	file.open(FileName);
	cout<<FileName<<endl;
	file  << *this;
	file.close();
	
}

/*
 * Imports a population from the file 'FileName'.
 */
void CPopulation::ImportPopulation(char * FileName)
{
  /*i've never tried this function!!!!!*/
	ifstream file;

	file.open(FileName);

	file  >> *this;
}

/*
 * Prints in standard output 'length' integer elements of a given array.
 */
void CPopulation::PrintArray(int* array, int length, string text)
{
	cout<<text;
	for (int i=0;i<length;i++){
		cout<<array[i]<<" ";
	}
	cout<<" "<<endl;
}

/*
 * Inserts a given value in a position of the array an the values after that position are displaced 1 position.
 */
void CPopulation::RemoveAt(int*array,int positionIndex, int n)
{
	for (int i=positionIndex;i<n-1;i++)
	{
		array[i]=array[i+1];
	}
}

/*
 * Prints the current population.
 */
void CPopulation::Print()
{
	POSITION pos;
	for(pos = GetHeadPosition(); pos!=NULL; pos = GetNext(pos))
		cout << GetAt(pos) << std::endl;
}

/*
 * Determines if the individuals in the population are equal.
 */
bool CPopulation::Same(int size)
{
	int best=GetHead()->Value();
	POSITION pos=GetHeadPosition();
	pos=GetNext(pos);
	best=GetAt(pos)->Value();//avoid the best solution.
	int ind=1;
	for(; pos!=NULL && ind<size; pos = GetNext(pos))
	{
		if (GetAt(pos)->Value()!=best)
			return false;
		ind++;
	}
	return true;
}

/*
 * Returns a random position of the population below 'limit'
 */
POSITION CPopulation::RandomPosition (int limit)
{
	int random=rand()% limit;
	POSITION pos;
	int i=0;
	for(pos = GetHeadPosition(); pos!=NULL && i<random; pos = GetNext(pos)) i++;
	return pos;
}

/*
 * Removes the position 'pos' of the population.
 */
void CPopulation::RemoveAt(POSITION pos)
{
	// If the list is empty the function will fail.
	if(m_next==m_prev)
	{
		// There is only one individual in the list.
		delete m_prev;
		m_next = NULL;
		m_prev = NULL;
	}
	else
	{
		if (pos->m_prev==NULL)
		{
			//remove head.
			RemoveHead();
		}
		else if (pos->m_next==NULL)
		{
			//remove tail.
			RemoveTail();
		}
		else
		{	
			pos->m_prev->m_next=pos->m_next;
			pos->m_next->m_prev=pos->m_prev;
			pos->m_next=NULL;
			pos->m_prev=NULL;
			delete pos->m_individual;
			delete pos;
		}
	}
}

