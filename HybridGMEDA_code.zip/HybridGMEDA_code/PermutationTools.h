/*
 *  Tools.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 9/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */
#include <string.h>
#include <sstream>
#include <fstream>
#include <iostream>
#include "Population.h"
#include <stdlib.h>
#include <stdio.h>

using std::stringstream;
using std::string;


/*
 * It determines if the given int sequecen if it is indeed a permutation or not.
 */
bool isPermutation(int * permutation, int size);

/*
 *	Calculates V_j-s vector.
 */
void vVector(int*v, int*permutation, int n);

/*
 * Inverts a permutation.
 */
void Invert(int*permu, int n, int* inverted);

/*
 * Inverts a permutation.
 */
int* Invert(int*permu, int n);

/*
 * Implements the compose of 2 permutations of size n.
 */
void Compose(int*s1, int*s2, int*res, int n);

/*
 * Generates a permutation from a v vector.
 */
void GeneratePermuFromV(int*v,int*permu,int n);

/*
 * Generates a random permutation of size 'n' in the given array.
 */
void GenerateRandomPermutation(int size, int * permutation);

/*
 * Generates a random population of size 'samplesNum' with individuals of size 'size'.
 */
void GenerateRandomPopulation(CPopulation * population, int samplesNum, int size);

/*
 * Evaluates the objective function of the array.
 */
int Evaluate(int * array, int size);


//Calculates the mean fitness of those individuals that the job 'job' is located in the position 'pos' in the processing sequence
double AverageJobPositionIndividuals(int job, int position, CPopulation * cases, int ProblemSize, int samplesNum);

//Calculates the mean fitness of those individuals that the job 'job' is located in the position 'pos' in the processing sequence
double AverageJobJobIndividuals(int job_j, int job_l, CPopulation * cases, int ProblemSize, int samplesNum);

void CalculateInstanceVarianceMatrix_JobPosition(double** indexVariance, double** positionVariance, int size, int samplesNum);

void CalculateFrecuencyMatrix(int** FrecuencyMatrix, CPopulation * cases, int ProblemSize, int samplesNum);

void AnalyzeInstance_JobPosition(int * jobs, int * positions, int samples);

void AnalyzeInstance_JobPosition(double * jobsDistribution, int samples, bool invert);

int * vVector2Permutations(int* permutationA, int*permutationB, int size);

/*
 * Calculates the tau Kendall distance between 2 permutations.
 */
int Kendall(int* permutationA, int*permutationB, int size);
