/*
 *  Kendall_Distance.cpp
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/17/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "Kendall.h"
#include "EDA.h"
#include "PermutationTools.h"
#include "Variables.h"
#include "Tools.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
using std::cerr;
using std::cout;
using std::endl;

/*
 * The constructor of the model.
 */
Kendall_Model::Kendall_Model(int n, int m)
{
	ProblemSize=n;
	ThetaParameters=new double[ProblemSize-1];
	ThetaBounds= new double[ProblemSize];
	Psis= new double[ProblemSize-1];	
	ThetaConvergenceRanking= new int[ProblemSize-1];
	//reservar memoria para las probabilidades de Vs.
	VProbs=new double*[ProblemSize-1];
	for (int i=0;i<ProblemSize-1;i++)
	{		
		VProbs[i]=new double[ProblemSize];
		ThetaConvergenceRanking[i]= MAX_INTEGER;
	}
	
	if (UPPER_THETA_KENDALL==0)
	{
		switch (n) 
		{
			case 20:
				if(m==5)
					UPPER_THETA_KENDALL=1.5;//original 2.1, barrido 1: 1.9
				else if (m==10)
					UPPER_THETA_KENDALL=1.4;//original 2.1, barrido 1: 1.4
				else 
					UPPER_THETA_KENDALL=1.4;//original 2.1, barrido 1: 1.5
				break;
				
			case 50:
				if(m==5)
					UPPER_THETA_KENDALL=3.7;//original 3.3, barrido 1: 5.5
				else if (m==10)
					UPPER_THETA_KENDALL=2.8;//original 3.3, barrido 1: 5.1
				else
					UPPER_THETA_KENDALL=3.0;//original 3.3, barrido 1: 4.2, definitive: 3.0.
				break;
			
			case 100:
				if(m==5) 
					UPPER_THETA_KENDALL=4.9;//original 3.8, barrido 1: 4.2
				else if(m==10)
					UPPER_THETA_KENDALL=3.7;//original 3.8, barrido 1: 4.3
				else
					UPPER_THETA_KENDALL=4.7;//original 3.8, barrido 1: 5.4
					break;
			
			case 200:
				if (m==10)
					UPPER_THETA_KENDALL=5.3;//original 4.0, barrido 1: 5.8
				else
					UPPER_THETA_KENDALL=5.5;//original 4.0, barrido 1: 5.7
				break;
				
			case 250:
				if (m==10)
					UPPER_THETA_KENDALL=5.2;//barrido values
				else
					UPPER_THETA_KENDALL=4.4;//barrido values
				break;
				
			case 300:
				if (m==10)
					UPPER_THETA_KENDALL=4.6;//barrido values
				else
					UPPER_THETA_KENDALL=5.2;//barrido values
				break;
				
			case 350:
				if (m==10)
					UPPER_THETA_KENDALL=6.6;//barrido values
				else
					UPPER_THETA_KENDALL=7.0;//barrido values
				break;
				
			case 400:
				if (m==10)
					UPPER_THETA_KENDALL=5.5;//barrido values
				else
					UPPER_THETA_KENDALL=5.0;//barrido values
				break;
				
			case 450:
				if (m==10)
					UPPER_THETA_KENDALL=4.0;
				else
					UPPER_THETA_KENDALL=6.7;
				break;
			
			case 500:
				UPPER_THETA_KENDALL=4.4;//original 4.5, barrido 1: 4.6
				break;
			
			default:
				UPPER_THETA_KENDALL=1;
				break;
		}
	}
	
	LOWER_THETA_KENDALL=UPPER_THETA_KENDALL*0.25;
}

/*
 * The destructor of the model.
 */
Kendall_Model::~Kendall_Model()
{
	for (int i=0;i<ProblemSize-1;i++)
	{
		delete [] VProbs[i];
	}
	delete [] VProbs;
	delete [] Psis;
	delete [] ThetaParameters;
	delete [] ThetaConvergenceRanking;

}

/*
 * Learns a Mallows model based on the Kendall distance and the individuals in the model.
 */
void Kendall_Model::Learn(int * consensusRanking, int **&cases, int sel_total, double upper_bound)
{
	//calculate theta parameters
	CalculateThetaParameters(consensusRanking, cases, sel_total, ThetaParameters,upper_bound);
	
	for (int i=0;i<IND_SIZE-1;i++)
	{
		if (ThetaParameters[i]>upper_bound*0.90 && ThetaConvergenceRanking[i]==MAX_INTEGER)
		{
			ThetaConvergenceRanking[i]=GEN_NUM;
		}
	}
	
	//3.- Calculate psi constant.
	//cout << "3.- Calculate psi constants"<<endl;
	CalculatePsiConstants(ThetaParameters, Psis);
	
	//4.- Calculate Vj probabilities matrix.
	//cout << "4.- Calculate Vj probabilities matrix"<<endl;
	double upper, lower, checkSum;
	int j,r;
	for(j=0;j<ProblemSize-1;j++)
	{
		checkSum=0;
		for(r=0;r<ProblemSize-j;r++)
		{ //v(j,i) proba dql v_j tome valor i		
			upper=exp((-1) * r * ThetaParameters[j]);
			lower=Psis[j];
			VProbs[j][r] =  upper/lower;
			checkSum+=VProbs[j][r];
		}
	}		
}

/*
 * Learns a Mallows model based on the Kendall distance and Qjl adjacency matrix learnt previously.
 */
void Kendall_Model::Learn(int * consensusRanking, double ** Qjl, double upper_bound)
{
	//calculate theta parameters
	CalculateThetaParameters(consensusRanking, Qjl, ThetaParameters, upper_bound);
	
	//3.- Calculate psi constant.
	//cout << "3.- Calculate psi constants"<<endl;
	CalculatePsiConstants(ThetaParameters, Psis);
	
	//4.- Calculate Vj probabilities matrix.
	//cout << "4.- Calculate Vj probabilities matrix"<<endl;
	double upper, lower, checkSum;
	int j,r;
	for(j=0;j<ProblemSize-1;j++)
	{//por seguir la nomenclatura del paper "consensus ranjking under constrined sensing" de marina meila..
		checkSum=0;
		for(r=0;r<ProblemSize-j;r++)
		{ //v(j,i) proba dql v_j tome valor i		
			upper=exp((-1) * r * ThetaParameters[j]);
			lower=Psis[j];
			VProbs[j][r] =  upper/lower;
			checkSum+=VProbs[j][r];
		}
	}	
}

/*
 * Learns a Mallows model based on the Kendall distance and Qjl adjacency matrix learnt previously.
 * Theta parameters are already assigned.
 */
void Kendall_Model::Learn(int * consensusRanking, double ** Qjl, double upper_bound, double * thetas)
{
	//calculate theta parameters
	CalculateThetaParameters(consensusRanking, Qjl, ThetaParameters, upper_bound);
	memcpy(ThetaParameters, thetas, sizeof(double)*IND_SIZE-1);

	//3.- Calculate psi constant.
	//cout << "3.- Calculate psi constants"<<endl;
	CalculatePsiConstants(ThetaParameters, Psis);
	
	//4.- Calculate Vj probabilities matrix.
	//cout << "4.- Calculate Vj probabilities matrix"<<endl;
	double upper, lower, checkSum;
	int j,r;
	for(j=0;j<ProblemSize-1;j++)
	{//por seguir la nomenclatura del paper "consensus ranjking under constrined sensing" de marina meila..
		checkSum=0;
		for(r=0;r<ProblemSize-j;r++)
		{ //v(j,i) proba dql v_j tome valor i		
			upper=exp((-1) * r * ThetaParameters[j]);
			lower=Psis[j];
			VProbs[j][r] =  upper/lower;
			checkSum+=VProbs[j][r];
		}
	}	
	//delete unnecessary structures.
}

/*
 * Given the consensus ranking, it samples a new individual.
 */
void Kendall_Model::Sample(int * permutation, int * consensusRanking)
{
	int i, index;
	double randVal, acumul;
	int * aux= new int[ProblemSize];
	for (i=0;i < ProblemSize;i++) aux[i]=0;
	
	//generate samples and calcualte likelihood
	//cout << "2.1. Sample a Vj."<<endl;
	int * v= new int[ProblemSize-1];
	for(i=0;i<ProblemSize-1;i++)
	{
		//muestreo de las n-1 posiciones del vector V que definen la permutacion
		randVal=(double)rand()/((double)RAND_MAX+1);
		acumul=VProbs[i][0];
		index=0;
		for(index=0;(index<ProblemSize-1 && acumul<randVal);index++)
			acumul += VProbs[i][index+1];
		v[i]=index;
	}
	
	GeneratePermuFromV(v,aux,ProblemSize);
	Compose(aux,consensusRanking,permutation,ProblemSize);
	delete [] v;
	delete [] aux;	
}

/*
 * Calculates the spread theta parameter from the ConsensusRanking and the individuals in the population.
 */
void Kendall_Model::CalculateThetaParameters(int*consensus, int**&cases, double cases_num, double * thetas, double upper_bound)
{	
	double initialTheta = 0.001;
	double * VjsMean= new double[ProblemSize-1];
	int * VjsNonMean= new int[ProblemSize-1];
	int * Vjs = new int[ProblemSize-1];
	int * invertedB = new int[ProblemSize];
	int * composition = new int[ProblemSize];
	int i,j;
    for (i=0;i<ProblemSize-1;i++) {VjsNonMean[i]=0;VjsMean[i]=0;}
	//Calculate Vjmean vector from the population
	//cout << "Calculate Vjsmean vector"<<endl;
	//int Vjs[ProblemSize-1];
	Invert(consensus,ProblemSize,invertedB);
	
	for (i=0;i<cases_num;i++)
	{
		int* individua=cases[i];
		
		Compose(individua,invertedB,composition,ProblemSize);
		
		vVector(Vjs, composition, ProblemSize);
		
		for (j=0;j<ProblemSize-1;j++)
		{
			VjsNonMean[j]=VjsNonMean[j]+Vjs[j];
		}
	}
	
	double valuee;
	for (i=0;i<ProblemSize-1;i++)
	{	
		valuee=(double)VjsNonMean[i]/cases_num;
		VjsMean[i]=valuee;
	}

		//calculate array of thetas.

	for (j=1;j<ProblemSize;j++)
	{
		thetas[j-1]= NewtonRaphsonMethod(initialTheta, VjsMean, j, upper_bound);	
	}
	
	delete [] VjsMean;
	delete [] VjsNonMean;
	delete [] Vjs;
	delete [] invertedB;
	delete [] composition;
	//PrintArrayDouble(thetas,IND_SIZE-1,"Thetas: ");
}	

/*
 * Calculates the spread theta parameter from the ConsensusRanking and the individuals in the population.
 */
void Kendall_Model::CalculateThetaParameters(int*consensus, double ** Qjl, double * thetas, double upper_bound)
{	
	double * VjsMean= new double[ProblemSize-1];
	double valuee;
	int j, l;
	int * invertedCR = new int[ProblemSize];
	
	Invert(consensus,ProblemSize,invertedCR);
	
	for (j=0;j<IND_SIZE-1;j++)
	{
		int job=invertedCR[j];
		valuee=0;
		for (l=0;l<IND_SIZE;l++)
		{
			if (consensus[l]>j)//l is not between invertedCR[0] and invertedCR[j]
				valuee+=Qjl[l][job];
		}
		VjsMean[j]=valuee;
	}
	
	double initialTheta = 0.001;
	
	//calculate array of thetas.
	for (j=0;j<ProblemSize-1;j++)
		thetas[j]= NewtonRaphsonMethod(initialTheta, VjsMean, j+1, upper_bound);
	
	delete [] VjsMean;
	delete [] invertedCR;
}	

/*
 * Calculates the total Psi normalization constant from the ThetaParameter and psi-s vector.
 */
void Kendall_Model::CalculatePsiConstants(double* thetas, double* psi)
{
	//en el param psi se dejan los valores de las ctes d normalización psi_j
	//returns psiTotal: la multiplicacion de los n-1 psi_j
	int n=ProblemSize;
	//calculate psi
	int i, j;
	for(i=0;i< n - 1;i++)
	{
		j=i+1;//el indice en el paper es desde =1 .. n-1 
		psi[i] = (1 - exp((-1)*(n-j+1)*((double)thetas[i])))/(1 - exp((-1)*((double)thetas[i])));
		//cout<<psi[i]<<" ";
	}
}

/*
 * Generates a permutation from a v vector.
 */
void Kendall_Model::GeneratePermuFromV(int*v,int*permu,int n)
{
	int at;
	int i;
	permu[0]=n-1;
	for (int element=n-2;element>=0;element--)
	{
		at=v[element];
		
		for (i=n-2;i>=at;i--)
		{
			permu[i+1]=permu[i];
		}
		permu[at]=element;
		
//		InsertAt(permu,element,at,n);
	}
}

/*
 * Returns the theta parameters estimated.
 */
double * Kendall_Model::GetThetaParameters()
{
	return ThetaParameters;
}

/*
 * Creates a population with the consensus ranking and theta paramater assigned.
 */
void Kendall_Model::CreatePopulation(double * thetaParameters, CPopulation * population, int * consensusRanking)
{
	//1.- Calculate psi constant
	double * psi = new double[ProblemSize-1];
	CalculatePsiConstants(thetaParameters, psi);
	
	//2.- Calculate Vj probabilities matrix.
	for(int j=0;j<ProblemSize-1;j++){//por seguir la nomenclatura del paper "consensus ranjking under constrined sensing" de marina meila..
		double checkSum=0;
		for(int r=0;r<ProblemSize-j;r++)
		{ //v(j,i) proba dql v_j tome valor i
			VProbs[j][r] =  exp((-1) * r * thetaParameters[j]) / psi[j];
			checkSum+=VProbs[j][r];
		}
	}
	
	delete [] psi;
}


/*
 * Calculates the needed theta (upper bound) to assign the given probability to the consensus ranking.
 */
double Kendall_Model::CalculateThetaUpperBound(double CR_Probability)
{
	double upper_theta= NewtonRaphsonMethod(0.01, CR_Probability);
	return upper_theta;
}



/*******************************  NEWTON-RAPSHON ALGORITHM for UPPER THETA ESTIMATION ********************************/
	
/*
 * Estimates the theta parameter needed to assign the given probability to the consensus ranking.
 */
double Kendall_Model::NewtonRaphsonMethod(double initialGuess, double CR_Probability)
{
	float xacc=0.0001;
	float theta= rtsafe(initialGuess, 10, xacc, CR_Probability);
	return theta;
}

/*
 * Newton - Rapshon execution algorithm.
 */
float Kendall_Model::rtsafe(float x1, float x2, float xacc, double CR_Probability)
{
	int iter; 
	float df,dx,dxold,f,fh,fl; 
	float temp,xh,xl,rts;
	
	funcd(x1,&fl,&df,CR_Probability);
	funcd(x2,&fh,&df,CR_Probability); 
	//if ((fl > 0.0 && fh > 0.0) || (fl < 0.0 && fh < 0.0))
	//cout<<"Root must be bracketed in rtsafe"<<endl; 
	if (fl == 0.0) 
		return x1; 
	if (fh == 0.0) 
		return x2; 
	if (fl < 0.0) 
	{
		xl=x1;
		xh=x2; 
	} 
	else 
	{
		xh=x1; 
		xl=x2;
	} 
	rts=0.5*(x1+x2); 
	dxold=fabs(x2-x1); 
	dx=dxold; 
	funcd(rts,&f,&df,CR_Probability); 
	//cout<<rts<<endl;
	for (iter=1;iter<=MAXIT;iter++) 
	{
		//Initialize the guess for root, the “stepsize before last,” and the last step.
		//Loop over allowed iterations. 
		if ((((rts-xh)*df-f)*((rts-xl)*df-f) > 0.0)	//Bisect if Newton out of range, 
			|| (fabs(2.0*f) > fabs(dxold*df))) 
		{	//or not decreasing fast enough.
			dxold=dx; 
			dx=0.5*(xh-xl); 
			rts=xl+dx; 
			if (xl == rts) 
				return rts;
		} 
		else 
		{ 
			dxold=dx;
			dx=f/df; 
			temp=rts; 
			rts -= dx; 
			if (temp == rts) 
				return rts;
			//Change in root is negligible. Newton step acceptable. Take it.
		} 
		//cout<<"DX: "<<dx<<endl;
		if (fabs(dx) < xacc){ 
			return rts;
		}
		funcd(rts,&f,&df,CR_Probability); //The one new function evaluation per iteration.
		//Orient the search so that f(xl) < 0.
		//Convergence criterion.
		
		if (f < 0.0)	//Maintain the bracket on the root. 
			xl=rts;
		else 
			xh=rts;
		
		//cout<<"rts: "<<rts<<endl;
	} 

	
	return 0.0;	//Never get here.
}

/*
 * Calculates Newton algorithms f and fdev functions
 */
void Kendall_Model::funcd(float theta, float *ff ,float *ffdev,  double CR_Probability)
{
	int n = ProblemSize;
	*ff = f(theta, n, CR_Probability);
	*ffdev =fdev(theta,n, CR_Probability);
}

/*
 * Theta parameter estimation function.
 */
float Kendall_Model::f(double theta, int n, double CR_Probability)
{ 
	double oper=1;
	double oper1;
	double oper2=1-exp(-theta);
	for (int j=1;j<=n-1;j++)
	{
		oper1=1-exp(-theta*(n-j+1));
		oper=oper * (oper1/oper2);
	}
	double resul=1 - CR_Probability*oper;
	return resul;
}

/*
 * Theta parameter estimation function derivation.
 */
float Kendall_Model::fdev(double theta, int n, double CR_Probability)
{
	double oper=1;
	double oper1;
	double oper2=pow((1-exp(-theta)),2);
	for (int j=1;j<=n-1;j++)
	{
		oper1 = (1-exp(-theta*(n-j+1)) )  * (1 - exp(-theta)) - (1-exp(-theta*(n-j+1))) * (theta*exp(-theta));
		oper=oper*(oper1/oper2);
	}
	double resul= -CR_Probability*oper;
	return resul;
}

/*******************************  NEWTON-RAPSHON ALGORITHM for THETAS ESTIMATION ********************************/

/*
 * Estimates theta parameters by means of running newton iterative algorithm.
 */
double Kendall_Model::NewtonRaphsonMethod(double initialGuess, double* Vjs, int j, double upper_bound)
{	
	float xacc=0.0001;
	float theta= rtsafe(initialGuess,upper_bound, xacc, Vjs, j);
	return theta;
}

/*
 * Calculates Newton algorithms f and fdev functions
 */
void Kendall_Model::funcd(double theta, double *ff ,double *ffdev,  double* Vjs, int j)
{
	int n = ProblemSize;
	*ff = f(theta, n,Vjs, j);
	*ffdev =fdev(theta,n, j);
}

/*
 * Newton - Rapshon execution algorithm.
 */
double Kendall_Model::rtsafe(double x1, double x2, double xacc, double* Vjs, int j)
{
	int iter; 
	double df,dx,dxold,f,fh,fl; 
	float temp,xh,xl,rts;
	
	funcd(x1,&fl,&df,Vjs,j);
	funcd(x2,&fh,&df,Vjs,j); 
	//if ((fl > 0.0 && fh > 0.0) || (fl < 0.0 && fh < 0.0))
	//cout<<"Root must be bracketed in rtsafe"<<endl; 
	if (fl == 0.0) 
		return x1; 
	if (fh == 0.0) 
		return x2; 
	if (fl < 0.0) 
	{
		xl=x1;
		xh=x2; 
	} 
	else 
	{
		xh=x1; 
		xl=x2;
	} 
	rts=0.5*(x1+x2); 
	dxold=fabs(x2-x1); 
	dx=dxold; 
	funcd(rts,&f,&df,Vjs,j); 
	//cout<<"beginning xl: "<<xl<<" xh: "<<xh<<" rts: "<<rts<<endl;
	//cout<<"f: "<<f<<" df: "<<df<<endl;
	for (iter=1;iter<=MAXIT;iter++) 
	{
		//Initialize the guess for root, the “stepsize before last,” and the last step.
		//Loop over allowed iterations. 
		if ((((rts-xh)*df-f)*((rts-xl)*df-f) > 0.0)	//Bisect if Newton out of range, 
			|| (fabs(2.0*f) > fabs(dxold*df))) 
		{	//or not decreasing fast enough.
			dxold=dx; 
			dx=0.5*(xh-xl); 
			rts=xl+dx; 
		//	cout<<"here: "<<endl;
			if (xl == rts) 
				return rts;
		} 
		else 
		{ 
			//cout<<"f: "<<f<<" df: "<<df<<endl;
			dxold=dx;
			dx=f/df; 
			
			temp=rts; 
			rts -= dx; 
			if (temp == rts) 
				return rts;
			//Change in root is negligible. Newton step acceptable. Take it.
		} 
		//cout<<"DX: "<<dx<<endl;
		if (fabs(dx) < xacc){ 
			return rts;
		}
		funcd(rts,&f,&df,Vjs,j); //The one new function evaluation per iteration.
		//Orient the search so that f(xl) < 0.
		//Convergence criterion.
		
		if (f < 0.0)	//Maintain the bracket on the root. 
			xl=rts;
		else 
			xh=rts;
		
	//	cout<<"iterating xl: "<<xl<<" xh: "<<xh<<" rts: "<<rts<<endl;
	} 
	//cout<<"end xl: "<<xl<<" xh: "<<xh<<endl;

	cout<<"Maximum number of iterations exceeded in rtsafe"<<endl;
	exit(1);
	return 0.0;	//Never get here.
}

/*
 * Theta parameter estimation function.
 */
double Kendall_Model::f(double theta, int n, double* VjMeans, int j)
{ 
	double oper1 = ( (n - j + 1) /(double)(exp((n - j + 1)*theta) - 1 ) );
	double oper2 = VjMeans[j-1];
	double results= ( 1 /(double)( exp(theta) -1 ) ) -oper1 -oper2;
	
	return results;
}

/*
 * Theta parameter estimation function derivation.
 */
double Kendall_Model::fdev(double theta, int n, int j)
{
	double oper1=((-1)*exp(theta) / pow(exp(theta)-1, 2));
	double oper2 =( pow(n-j+1,2) * exp(theta*(n-j+1))) / (double)pow(exp(theta*(n-j+1))-1,2);
	if (isnan(oper2)==true)
	{
		oper2=0;
	}

	return oper1+oper2;
}
