/*
 *  LocalSearch.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 9/15/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include <fstream>
#include <iostream>
#include "Individual.h"
#include "GeneralizedMallowsModel.h"
using std::istream;
using std::ostream;
using std::string;

/*
 * This method applies a greedy local search with the swap operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Swap(PFSP * fsp, CIndividual *  individual, int power);

/*
 * This method applies a greedy local search with the insert operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Insert(PFSP * fsp, CIndividual * individual, int power);

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 */
CIndividual * VNS(PFSP * fsp, CIndividual *  individual, int upper_iteraciones, int shake_power);

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 * Includes a guided shake swap that changes dynamically according to the improvement.
 */
CIndividual * VNS_dynamicOrbits(PFSP * fsp, CIndividual *  individual, int shake_power);

/*
 * Executes a variable neighborhood search over the insert incremental neighborhoods and swap neighborhood for scaping
 * from the local optima.
 */
CIndividual * IncrementalVNS(PFSP * fsp, CIndividual *  individual);

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 */
CIndividual * VNS(PFSP * fsp, CIndividual *  individual, int shake_power);

/*
 * Executes a variable neighborhood search over the insert and swap neighborhoods for the given PFSP instance.
 */
CIndividual * VNS_Inverted(PFSP * fsp, CIndividual *  individual, int shake_power);

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 * This algorithm is proposed in the paper "New VNS heuristic for total flowtime flowshop scheduling problem" Costa et al. 2011 Tech Report.
 */
CIndividual * VNS_4(PFSP * fsp, CIndividual *  individual, int shake_power);
int * Shift(PFSP * fsp, int job_index);
bool LocalSearch_BestFirst_Swap(PFSP * fsp, CIndividual * individual);
bool LocalSearch_BestFirst_Insert(PFSP * fsp, CIndividual *  individual);

/*
 * Applies a swap shake over an individual.
 */
void Shake_Swap(CIndividual *  individual, int shake_power);

/*
 * Applies a limited swap shake over an individual. 
 */
void Shake_Swap(CIndividual *  individual, int shake_power, int orbit_size);

/*
 * This method applies shake_power times a pertubation (swap) following the highest influence swaps.
 */
void Shake_Swap_GeneLinkage(CIndividual *  individual, int shake_power, int ** influenceMatrix);
void GeneLinkageIdentification(CIndividual * individual, int ** influenceMatrix);

/*
 * Applies an insert shake over an individual.
 */
void Shake_Insert(CIndividual *  individual, int shake_power);

void Shake_Insert(CIndividual *  individual, int shake_power, int orbit_size);

/*
 * This method moves the value in position i to the position j.
 */
int * InsertAt (int * array, int i, int j);

/*
 * Prints in the standard output genes.
 */
void Print(int * array, int size, string text);

/*
 * This method applies a swap of the given i,j positions in the array.
 */
int * Swap(int * array, int i, int j);

/*
 * This method implements the enhanced VNS purposed in the paper of the algorithm AGA of Xiao Xu.
 */
CIndividual * eVNS(CIndividual *  individual, int k, int max_local, PFSP * fsp);
