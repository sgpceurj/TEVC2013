// Solution.cpp: implementation of the CSolution class.
//

#include "Solution.h"
#include "EDA.h"
#include "LocalSearch.h"
#include "PermutationTools.h"
#include "Problem.h"
#include "LR.h"
#include "LocalSearch.h"
#include "Tools.h"
#include <math.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>


#define itoa(a,b,c) sprintf(b, "%d",a)

long double tlearn=0;
long double tcreate=0;
long double tanalyze=0;

timeval llearnin,llearnout;


CSolution::CSolution(): m_generation(0),m_generation_init(0),m_total(0),m_old_total(MIN_INTEGER)
{
    time_t actual=time(NULL);
	while (actual == time(NULL));
	
	// Seed for random numbers.
	//int value=time(NULL)+SEED;
	//value=SEED;
	//srand(value);

	m_influence_matrix= new int*[IND_SIZE];
	for (int i=0;i<IND_SIZE;i++)
	{
		m_influence_matrix[i]= new int[IND_SIZE];
	}
	

		
#ifndef GUIDED_LR_START	
	int* permutation= new int[IND_SIZE];
	GenerateRandomPermutation(IND_SIZE,permutation);
	CIndividual * individual= new CIndividual(IND_SIZE);
	individual->SetGenes(permutation);
	AddToPopulation(individual);
	m_total += individual->Value();
	BEST=individual;
	BEST_FITNESS=-individual->Value();
	
	//Initial population created randomly as usual
	for(int i=0;i<POP_SIZE-1;i++)
	{
		//Create random individual
		int* permutation= new int[IND_SIZE];
		GenerateRandomPermutation(IND_SIZE,permutation);
		CIndividual * individual= new CIndividual(IND_SIZE);
		individual->SetGenes(permutation);

		AddToPopulation(individual);
		m_total += individual->Value();
	}
#else
	
	CIndividual * lr_individual=NonDeterministic_LRnm(IND_SIZE,GetFlowshopProblem());
 	cout<<"LR solution: "<<lr_individual<<endl;

	//AddToPopulation(individual);
//	m_total += individual->Value();

	//guided from the solution of LR
	for (int i=0;i<POP_SIZE/2;i++)
	{ 
		CIndividual * individual= lr_individual->Clone();
		Shake_Insert(individual, 5,ORBIT_RESTART);
		AddToPopulation(individual);
		m_total += individual->Value();
	}
	//random initialization
	for(int i=0;i<POP_SIZE/2;i++)
	{
		//Create random individual
		int* permutation= new int[IND_SIZE];
		GenerateRandomPermutation(IND_SIZE,permutation);
		CIndividual * individual= new CIndividual(IND_SIZE);
		individual->SetGenes(permutation);
		
		AddToPopulation(individual);
		m_total += individual->Value();
	}
	
#endif
	
#ifdef LR_START
	for (int i=0;i<POP_SIZE/2;i++)
	{ 
		CIndividual * lr_individual=NonDeterministic_LRnm(IND_SIZE,GetFlowshopProblem());
		cout<<"i: "<<i<<" LR solution: "<<lr_individual->Value()<<endl;
		AddToPopulation(lr_individual);
		m_total += lr_individual->Value();
	}

	//random initialization
	for(int i=0;i<POP_SIZE/2;i++)
	{
		//Create random individual
		int* permutation= new int[IND_SIZE];
		GenerateRandomPermutation(IND_SIZE,permutation);
		CIndividual * individual= new CIndividual(IND_SIZE);
		individual->SetGenes(permutation);
		
		AddToPopulation(individual);
		m_total += individual->Value();
	}
#endif
	BEST=GetBestIndividual();

	BEST_FITNESS=-GetBestIndividual()->Value();

	CreateStructures();   

    //starts the timer from 0.
    StartTimer();
}

CSolution::~CSolution()
{
	DestroyStructures();
}

void CSolution::CreateStructures()
{
	// Memory allocation for the structure storing the
    // selected individuals.
    m_cases = new int*[SEL_SIZE];
	
    // Memory allocation for the structure storing the
    // evaluation function values of selected individuals (when BSC)
    m_values = new double*[IND_SIZE];
    for (int i=0;i<IND_SIZE;i++)
    {
        m_values[i] = new double[STATES[i]-1];
        for (int j=0;j<(STATES[i]-1);j++)
            m_values[i][j] = 1;
    }
    m_sel_total = (double)0;
}

void CSolution::DestroyStructures()
{
	int i;
	
    // Destruction of the population.
    for(i=0;i<POP_SIZE;i++)
    {
        delete m_population.GetTail();
        m_population.RemoveTail();
    }
	
    // Destruction of the structure storing the selected individuals.
    delete [] m_cases;
	
    for (i=0;i<IND_SIZE;i++) 
        delete [] m_values[i];
    delete [] m_values;
}
void CSolution::Improve( int generation )
{
	//cout<<"Start improve"<<endl;
	double oldScore=-GetBestIndividual()->Value();
    int i,r;

    //cout<<"Initialize SEL_SIZE population structure"<<endl;
    // Select SEL_SIZE individual from the population.
    // Initialize eval_func structures for BSC
    m_sel_total = 0;
    for (r=0;r<IND_SIZE;r++)
        for (int s=0;s<(STATES[0]-1);s++)
            m_values[r][s] = (double)0;	
	//cout<<"here"<<endl;
	#ifndef RTR
	
	//Truncation selection method.
	POSITION pos = m_population.GetHeadPosition();
    for(i=0;i<SEL_SIZE;i++)
    {
		m_cases[i] = m_population.GetAt(pos)->Genes();
        for (int j=0;j<IND_SIZE;j++)
        {	
			if (m_cases[i][j]!=(STATES[j]-1))
				m_values[j][m_cases[i][j]] += m_population.GetAt(pos)->Value();
		}
        m_sel_total += m_population.GetAt(pos)->Value();
        pos = m_population.GetNext(pos);            
    }
		//cout<<"here2"<<endl;
	#else
	//cout<<"Tournament Selection Scheme"<<endl;
	//Tournament selection method.
	for(i=0;i<SEL_SIZE;i++)
    {
		CPopulation tournament_pool;
		for (int j=0;j<RTR;j++)
		{
			POSITION randomPos=m_population.RandomPosition(IND_SIZE);
			CIndividual *individual=m_population.GetAt(randomPos);
			tournament_pool.AddToPopulation(individual);
		}
		CIndividual * ind=tournament_pool.GetHead();
		//cout<<"Best of the tournament: "<<ind<<endl;

		m_cases[i] = ind->Genes();
        for (int j=0;j<IND_SIZE;j++)
        {	
			if (m_cases[i][j]!=(STATES[j]-1))
				m_values[j][m_cases[i][j]] += ind->Value();
		}
        m_sel_total += ind->Value();
	}
	
	#endif
	
   //  cout<<"Learning..."<<endl;
    //// Learn the Bayesian network which best fits the selected
    // individuals.
	gettimeofday(&llearnin,NULL);
	
	//cout<<"Learning probabilities with generalized mallows"<<endl;
	int* inverted_best= new int[IND_SIZE];
	Invert(GetBestIndividual()->Genes(),IND_SIZE,inverted_best);
	m_generalized_mallows_model.LearnProbabilities(m_cases,m_values,SEL_SIZE,inverted_best);
	delete[]inverted_best;
	THETAS_AVERAGE=m_generalized_mallows_model.GetThetasAverage();
	//cout<<"Learning end.."<<endl;

	gettimeofday(&llearnout,NULL);

	//cout<<"Learn="<<(llearnout.tv_sec-llearnin.tv_sec)+(llearnout.tv_usec-llearnin.tv_usec)/1000000<<endl;

	tlearn+=(llearnout.tv_sec-llearnin.tv_sec)*1000000+(llearnout.tv_usec-llearnin.tv_usec);

    // Create the new population.
    gettimeofday(&llearnin,NULL);
			
	//cout<<"Sampling generalized mallows..."<<endl;
	//CPopulation offspring;

	for(i=0;i<OFFSPRING_SIZE && EVALUATIONS<MAX_EVALUATIONS;i++)
	{
		CIndividual * individual=m_generalized_mallows_model.Simulate(m_generalized_mallows_model.ConsensusRanking);
		
		#ifdef VNS_SEARCH
		if (drand48() < VNS_SEARCH)
		{
			individual=VNS(GetFlowshopProblem(),individual,1,0);	
		}
		#endif

		#ifndef RTR
		AddToPopulation(individual);
		#else
		offspring.AddToPopulation(individual);
		#endif
	}
	
	#ifndef RTR
	//merge replacement
	//cout<<"Sampling generalized mallows end..."<<endl;
	for(i=0;i<OFFSPRING_SIZE;i++)
	{
		delete m_population.GetTail();
		m_population.RemoveTail();
	}
	#else
	//cout<<"Restricted Tournament Replacement"<<endl;
	//Restricted Tournament Replacement
	int lowest;
	int j=0, distance=0;
	POSITION pos,Y_Pos,randomPos;
	int w=IND_SIZE;
	CIndividual * X;
	CIndividual *Y;
	CIndividual *individual;
	
	for (pos = offspring.GetHeadPosition();j<OFFSPRING_SIZE;pos=offspring.GetNext(pos))
	{
		X = offspring.GetAt(pos);
		
		lowest=MAX_INTEGER;
		//Select a random subset of individuals.	
		for (int i=0;i<w;i++)
		{	
			randomPos=m_population.RandomPosition(POP_SIZE);
			individual=m_population.GetAt(randomPos);
			distance=Kendall(individual->Genes(),X->Genes(), IND_SIZE);

			if (lowest>distance)
			{
				Y_Pos=randomPos;
				Y=individual;
				lowest=distance;
			}
		}
		if (Y->Value()<X->Value())
		{
			//Remove promissing from the m_population.
			m_population.RemoveAt(Y_Pos);
			m_population.AddToPopulation(X);
		}
		j++;
	}

	#endif

	#ifdef RESTART

	if (m_population.Same(POP_SIZE) && EVALUATIONS<MAX_EVALUATIONS) 
	{	
		//vns to the best solution in the population.
		//m_population.GetHead()=VNS(GetFlowshopProblem(),m_population.GetHead(),5,10);	
 
		//flush population except the first solution
		if (BEST->Value()<m_population.GetHead()->Value())
		{
			RESTARTS=0;
			BEST=m_population.GetHead()->Clone();
		}
		RESTARTS++;
//		cout<<"RESTART "<<RESTARTS<<" ----------------------------> AT GENERATION: "<<GEN_NUM<<" EVALUATIONS: "<<EVALUATIONS<<" BEST: "<<BEST->Value()<<endl;

		for (int i=0;i<POP_SIZE;i++)
		{ 
			delete m_population.GetTail();
			m_population.RemoveTail();
		}
	//	cout<<"after removing"<<endl;
	#ifndef RANDOM_RESTART
		
		//ORBIT_RESTART
		//restart by orbits
		for (int i=0;i<POP_SIZE;i++)
		{ 
			CIndividual * individual= BEST->Clone();
			Shake_Insert(individual, 5,ORBIT_RESTART);
			AddToPopulation(individual);
		}

		
	#else
		//Random restart
		for (int i=0;i<POP_SIZE-1;i++)
		{
			//Create random individual
			int* permutation= new int[IND_SIZE];
			GenerateRandomPermutation(IND_SIZE,permutation);
			CIndividual * individual= new CIndividual(IND_SIZE);
			individual->SetGenes(permutation);
			AddToPopulation(individual);
		}
		
	#endif
	}
	
	
	#endif
    gettimeofday(&llearnout,NULL);

    //cout<<"Create="<<(llearnout.tv_sec-llearnin.tv_sec)+(llearnout.tv_usec-llearnin.tv_usec)/1000000<<endl;

    tcreate+=(llearnout.tv_sec-llearnin.tv_sec)*1000000+(llearnout.tv_usec-llearnin.tv_usec);

    gettimeofday(&llearnin,NULL);

    // Calculate the new total.
    m_old_total = m_total;
    m_total = 0;
    for(POSITION pos = m_population.GetHeadPosition();
        pos!=NULL;pos = m_population.GetNext(pos))
        m_total += m_population.GetAt(pos)->Value();

    // Update the generation counter.
    m_generation++;

    gettimeofday(&llearnout,NULL);

    //cout<<"Analyze="<<(llearnout.tv_sec-llearnin.tv_sec)+(llearnout.tv_usec-llearnin.tv_usec)/1000000<<endl;

    tanalyze+=(llearnout.tv_sec-llearnin.tv_sec)*1000000+(llearnout.tv_usec-llearnin.tv_usec);

	
    //checking convergence of the best individual
    double newScore=-GetBestIndividual()->Value();
    if (newScore<oldScore)
    {
    	m_best_changed=true;
		BEST_FITNESS=(int)newScore;
    }
    else
    {
    	m_best_changed=false;
    }
	//cout<< "Improve finished..."<<endl;
}

bool CSolution::Last()
{
  CIndividual * ind = GetBestIndividual();
  
  if ((int)OPTIMAL == (int)ind->Value())
  {
    return true;
  }
  else 
  {
    return m_generation == MAX_GENERATIONS;
  }
}

ostream & operator<<(ostream & os,CSolution & solution)
{

    os 
        << "Population size: " << POP_SIZE << endl
        << "Selected individuals: " << SEL_SIZE << endl
        << "Offspring size: " << OFFSPRING_SIZE << endl
        << "Elitism: " << ELITISM << endl
        << "Generation: " << solution.m_generation << endl
        << "Convergence generation: "<<CONVERGENCE_ITERATION<<endl
        << "Evaluations: " << EVALUATIONS << endl
		<< "Convergence evaluation: "<<CONVERGENCE_EVALUATIONS<<endl
        << "Total time: " << solution.timer.TimeString() << endl
        << "Execution time: " << solution.timer.ExecutionTimeString() << endl
		<< "EDA improvement rate: "<<EDA_IMPROVEMENT_RATE<<endl
		<< "EDA solution: "<<EDA_SOLUTION<<endl
        << "Best individual: " << solution.m_population.GetHead();
    return os;
}


CIndividual * & CSolution::RangeBasedSelection()
{
    double bound = (1+POP_SIZE)*POP_SIZE/2;
    double which = rand()*bound/RAND_MAX;

    POSITION pos = m_population.GetHeadPosition();
    for(int i=POP_SIZE;which>i;i--) 
    {
        pos = m_population.GetNext(pos);
        which -= i;
    }

    return m_population.GetAt(pos);
}

void CSolution::AddToPopulation(CIndividual * individual)
{
  m_population.AddToPopulation(individual);
}


void CSolution::StartTimer()
{
    //set the time at the beginning
    timer.Reset();
}


void CSolution::StopTimer()
{
    //Stop the timer.
    timer.End();
}


int CSolution::GetGenerationNumber()
{
    return m_generation;
}


CIndividual  * & CSolution::GetBestIndividual()
{	
   return m_population.GetHead();
}

bool CSolution::BestIndividualChanged()
{
	return m_best_changed;
}

void CSolution::AnalyzeGeneration()
{

	//  AnalyzeGenerationProblem(*this);
      if (GetGenerationNumber() % GENERATIONSPRINTRESULT == 0)
      {

    	//  if (foutput)
        //     foutput << "Generation "<< GetGenerationNumber() << "(" << timer.TimeString() << "): " << GetBestIndividual() << endl;
      }
    //POPCORRECT=0;
    //POPMISS1=0;
    //POPMISS2=0;
    //POPMISS3=0;
    //POPMISSMORE=0;
}

void CSolution::WriteSolution()
{
//  WriteSolutionProblem(*this);

    // Stop the timer
    StopTimer();

    //Write the information of the solution in the screen
    cout << *this << endl;

    //Write the information of the solution in the file (if exists)
    if (foutput) {
        if (GetGenerationNumber() % GENERATIONSPRINTRESULT != 0) {
            foutput << "Generation "<< GetGenerationNumber() << ": "
                    << GetBestIndividual() << endl;
            cout << "Generation "<< GetGenerationNumber() << ": "<< GetBestIndividual() << endl;
        }
        foutput << "== final RESULTS =="<< endl
                << *this << endl;
        foutput.close();
    }
}

int* CSolution::GetConsensusRanking()
{
	return m_generalized_mallows_model.ConsensusRanking;
}

