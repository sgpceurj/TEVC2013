// Problem.cpp: implementation of the methods specific to the problem.
//


#include "Problem.h"
#include "EDA.h"


PFSP * m_flowshop_problem;

/*
 * Reads the FSP instance indicated and initializes the corresponding parameters.
 */
int GetFSPProblemInfo(string filename)
{
	int problemsize= m_flowshop_problem->ReadInstance(filename);
	
	//INITIALIZE INDIVIDUAL SIZE AND GENE VALUE RANGES
	IND_SIZE = problemsize;
	MAX_GENERATIONS=100*IND_SIZE;
	MAX_GENERATIONS_NO_IMPROVEMENT=10*IND_SIZE;
	MAX_RESTARTS_NO_IMPROVEMENT=10*IND_SIZE;
	STATES = new int[IND_SIZE];
	for(int i=0;i<IND_SIZE;i++)
	{
		STATES[i] = problemsize;
	}
		
	return (0);
}

/*
 * Reads the problem info of the instance set.
 */
int GetProblemInfo(string filename)
{
	m_flowshop_problem= new PFSP();
	int	result = GetFSPProblemInfo(filename);
	
	return result;
}

/*
 * Frees the resources used by the values of the instance read.
 */
void RemoveProblemInfo()
{
	// The memory allocated in GetProblemInfo() is returned.

	delete [] STATES;
}

/*
 * Calculates the objective function of the given genes.
 */
int Metric(int * genes, int size)
{
	int	value = -m_flowshop_problem->EvaluateFSPTotalFlowtime(genes);
	//int	value = -m_flowshop_problem->EvaluateFSPMakespan(genes);
    return value;
}

/*
 * Returns the pointer of the flowshop_problem object.
 */
PFSP * GetFlowshopProblem()
{
	return m_flowshop_problem;
}




