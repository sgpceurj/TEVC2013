/*
 *  Variables.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

//Integer maximum value
#define MAX_INTEGER 100000000

//Integer minimum value
#define MIN_INTEGER -100000000

//Long integer maximum value
#define MAX_LONG_INTEGER 4294967295

//Every how many generations do we have to print the information
#define GENERATIONSPRINTRESULT 1

//This flag determines if a VNS procedure will be applied after sampling a new individual with a certain
//probability: 0.05, 0.1, 0.2...
//#define VNS_SEARCH 0.01

//This flag indicates if a hard VNS 50,10 will be applied to the best solution. when evolutionary processes ends.
//#define VNS_FINAL_ITERATIONS 50

//This flag indicates if a hard VNS will be applied to the best solution. when evolutionary processes ends.
//The probability especified indicates the percent of evaluations employed for the VNS. If the probability is 0, 
//the VNS will execute 50 iterations.
#define VNS_FINAL_EVALUATIONS 0.5

//This flag indicates if the implementation of the CalculateConsensusRanking and CalculateThetaParameters
//is that described in Marina Meila article, or on the contrary, we follow the suggestion made by Lozano.
//Besides, this flag allows to include to the model.
//#define MALLOWS_FLIGNER 0.1

//This flag indicatees if apriori probabilities extracted from the partial TFTs are included in the model.
//#define APRIORIS_TFT 0

//This flag indicatees if apriori probabilities extracted from delays are included in the model.
//#define APRIORIS_DELAYS 0

//This flag indicates if apriori probabilities extracted from machine idle times are included in the model
//#define APRIORIS_IDLETIMES 0

// Orbit size assigned to the shake of the job in the VNS.
#define ORBIT_SHAKE 20//by default 20

//This flag indicates if a log of generations,best fitness, num of evaluations,... is printed every 0.01 generations.
//#define PRINT_LOG 500

//#define THETA_SPEED

//This flag determines if the population will be restarted when all the individuals in the population are equal.
#define RESTART 500

//This flag indicates that the restart will be carried out with random solutions and not with
//guied solutions
//#define RANDOM_RESTART 0

//This flag indicates if the orbit restart is performed.
#define ORBIT_RESTART 10

//Flag for the activation of the tournament pool with the Restricted Tournament Replacement. Pelikan et al.
//#define RTR 4

//#define GUIDED_LR_START 0

//#define LR_START 0

#define MAX(A,B) ( (A > B) ? A : B)
#define MIN(A,B) ( (A < B) ? A : B)

