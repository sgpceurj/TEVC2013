// Population.h: interface for the CPopulation class.
//
// Description:
//		A list of individuals.
//
// Author:	Ramon Etxeberria
// Date:	1999-09-25

#ifndef _POPULATION_
#define _POPULATION_
#include <string.h>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include "EDA.h"
#include "PFSP.h"
#include "Individual.h"

using std::istream;
using std::ostream;
using std::stringstream;
using std::string;

class CPopulation;

typedef CPopulation * POSITION;

class CPopulation  
{
	// The individual at the current node.
	CIndividual * m_individual;

	// The next node in the list.
	CPopulation * m_next;

	// The previous node in the list.
	CPopulation * m_prev;

public:
	// The constructor. It creates an empty list.
	CPopulation();

	// The destructor. 
	virtual ~CPopulation();

	// It returns the individual at the head of the list.
	CIndividual * & GetHead();

	// It returns the individual in the node pointed by pos.
	CIndividual * & GetAt(POSITION pos);

	// It returns the individual at the tail of the list.
	CIndividual * & GetTail();

	// It moves forward in the list.
	POSITION GetNext(POSITION pos);

	// It return the node at the head of the list.
	POSITION GetHeadPosition();

	// It returns the individual at the tail of the list and removes its node.
	void RemoveTail();
	
	/*
	 * Removes the first position of the population.
	 */
	void RemoveHead();
	
	/*
	 * Removes the position 'pos' of the population.
	 */
	void RemoveAt(POSITION pos);

	/*
	 * Function to add an individual to the population
	 */
	void AddToPopulation(CIndividual * individual);

	/*
	 * Import/Export the population from/to a stream or file
	 */
	friend ostream & operator<<(ostream & os,CPopulation & population);
	friend istream & operator>>(istream & is,CPopulation & population);
	
	/*
	 * Prints in standard output 'length' integer elements of a given array.
	 */
	void PrintArray(int* array, int length, string text);
	
	/*
	 * Imports a population from the file 'FileName'.
	 */
	void ImportPopulation(char * FileName);
	
	/*
	 * Exports the population to the file 'FileName'.
	 */
	void ExportPopulation(char * FileName);
			 
	/*
	 * Prints the current population.
	 */
	void Print();
	
	/*
	 * Returns a random position of the population below 'limit'
	 */
	POSITION RandomPosition(int limit);
	
	/*
	 * Determines if the individuals in the population are equal.
	 */
	bool Same(int size);
	
 private:

	// It inserts the given individual before the node pointed
	// by pos.
	void InsertBefore(POSITION pos, CIndividual * individual);

	// It adds the given individual at the end of the list.
	void AddTail(CIndividual * individual);
	
	/*
	 * Removes the 'positionIndex' from the given array of size 'n'.
	 */
	void RemoveAt(int*array,int positionIndex, int n);

};

#endif

