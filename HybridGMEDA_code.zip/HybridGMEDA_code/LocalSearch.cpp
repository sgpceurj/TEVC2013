/*
 *  LocalSearch.cpp
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 9/15/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "LocalSearch.h"
#include "EDA.h"
#include "Solution.h"
#include "Tools.h"
#include "Problem.h"
#include "PFSP.h"
#include "Timer.h"
#include "PermutationTools.h"
#include <sys/time.h>

#define MAX(A,B) ( (A > B) ? A : B)
/*
 * This method moves the value in position i to the position j.
 */
int * InsertAt (int * array, int i, int j)
{	
	if (i!=j)
	{
		int res[IND_SIZE];
		int val=array[i];
		if (i<j)
		{
			memcpy(res,array,sizeof(int)*i);
			
			for (int k=i+1;k<=j;k++)
				res[k-1]=array[k];
			
			res[j]=val;
			
			for (int k=j+1;k<IND_SIZE;k++)
				res[k]=array[k];
		}
		else if (i>j)
		{
			memcpy(res,array,sizeof(int)*j);
			
			res[j]=val;
			
			for (int k=j;k<i;k++)
				res[k+1]=array[k];
			
			for (int k=i+1;k<IND_SIZE;k++)
				res[k]=array[k];
		}
		memcpy(array,res,sizeof(int)*IND_SIZE);
	}
	return array;
}

/*
 * This method applies a swap of the given i,j positions in the array.
 */
int * Swap(int * array, int i, int j)
{
	int aux=array[i];
	array[i]=array[j];
	array[j]=aux;
	return array;
}


void GeneLinkageIdentification(CIndividual * individual, int ** influenceMatrix)
{
	int aux,i,j;
	int * genes= individual->Genes();
	int objectiveFunction=-individual->Value();
	int * inverted= new int[IND_SIZE];
	for (i=0;i<IND_SIZE;i++)
	{
		//hasta i
		for (j=0;j<i;j++)
		{
			//cout<<"i: "<<i<<" j: "<<j<<endl;
			//PrintArray(genes,IND_SIZE, "before: ");
			//swap i-j
			aux=genes[i];
			genes[i]=genes[j];
			genes[j]=aux;
			//PrintArray(genes,IND_SIZE, "after: ");
			Invert(genes,IND_SIZE,inverted);
			//cout<<"objective function: "<<objectiveFunction<<" swapped fitness: "<<-Metric(inverted,IND_SIZE)<<endl;
			//evaluate the change and save
			
			influenceMatrix[i][j]= objectiveFunction - -Metric(inverted,IND_SIZE);
			
			//swap j-i
			aux=genes[i];
			genes[i]=genes[j];
			genes[j]=aux;
			//exit(1);
		}
	}
	delete [] inverted;
}
/*
 * This method applies a greedy local search with the swap operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Swap(PFSP * fsp, CIndividual *  individual, int power)
{
	float cost_opt, cost_improve, cost_best_provisional;
	int seguir,j,k,aux;
	int best_k=0, best_j=0;
		
	//int * genes= new int[IND_SIZE];
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	
	//cost_opt=-fsp->EvaluateFSPResidualProfileSum(genes);
	cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite(fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
	//cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2(fsp->genes_aux, best_k, fsp->jobsTimeTable_aux2);
	cost_best_provisional=cost_opt;
	int iter=0;
	seguir=1;
	while ((seguir && power==0) || (seguir && iter<power))
	{
		seguir=0;
		for (k=0; k<IND_SIZE-1; k++)
		{
			for (j=k+1; j<IND_SIZE;j++)
			{
				//swap k and j positions.
				aux=fsp->genes_aux[k];
				fsp->genes_aux[k]=fsp->genes_aux[j];
				fsp->genes_aux[j]=aux;
								
                cost_improve=-fsp->EvaluateFSPMakespan(fsp->genes_aux);
//				cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite(fsp->genes_aux, k, fsp->jobsTimeTable_aux);
			//	cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite2(fsp->genes_aux, k, fsp->jobsTimeTable_aux2);

				if (cost_improve>cost_best_provisional)
				{
					//guardar que el mejor swap
					//cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
					best_k=k;
					best_j=j;
					cost_best_provisional=cost_improve;
					seguir=1;
				}

				//restore the positions swapped previously. Because this change does not produce good results.
				aux=fsp->genes_aux[j];
				fsp->genes_aux[j]=fsp->genes_aux[k];
				fsp->genes_aux[k]=aux;
			}
		}

		if (seguir==1)
		{
			//modificar la permutacion con aquel swap que mejore más.
			aux=fsp->genes_aux[best_k];
			fsp->genes_aux[best_k]=fsp->genes_aux[best_j];
			fsp->genes_aux[best_j]=aux;
                            cost_improve=-fsp->EvaluateFSPMakespan(fsp->genes_aux);
			cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite(fsp->genes_aux, best_k, fsp->jobsTimeTable_aux);
			//cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2(fsp->genes_aux, best_k, fsp->jobsTimeTable_aux2);
		}
		iter++;
	}
	
	//int * inverted= new int[IND_SIZE];
	Invert(fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);

	if (best_j==0 && best_k==0)//si estas variables siguen si utilizar quiere decir que no se ha mejorado.
		return false;
	else
		return true;

}

/*
 * This method applies a greedy local search with the swap operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Swap2(PFSP * fsp, CIndividual *  individual, int power)
{
	float cost_opt, cost_improve, cost_best_provisional;
	int seguir,j,k,aux;
	int best_k=0, best_j=0;
	
	//int * genes= new int[IND_SIZE];
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	
                    cost_opt=-fsp->EvaluateFSPMakespan(fsp->genes_aux);
	//cost_opt=-fsp->EvaluateFSPResidualProfileSum(genes);
//	cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2(fsp->genes_aux, best_k, fsp->jobsTimeTable_aux);
	cost_best_provisional=cost_opt;
	int iter=0;
	seguir=1;
	while (((seguir && power==0) || (seguir && iter<power)) && EVALUATIONS<MAX_EVALUATIONS)
	{
		seguir=0;
		for (k=0; k<IND_SIZE-1&& EVALUATIONS<MAX_EVALUATIONS; k++)
		{
			for (j=k+1; j<IND_SIZE&& EVALUATIONS<MAX_EVALUATIONS;j++)
			{
				//swap k and j positions.
				aux=fsp->genes_aux[k];
				fsp->genes_aux[k]=fsp->genes_aux[j];
				fsp->genes_aux[j]=aux;
				
			//	cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite2(fsp->genes_aux, k, fsp->jobsTimeTable_aux);
				cost_improve=-fsp->EvaluateFSPMakespan(fsp->genes_aux);
				if (cost_improve>cost_best_provisional)
				{
					//guardar que el mejor swap
					//cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
					best_k=k;
					best_j=j;
					cost_best_provisional=cost_improve;
					seguir=1;
				}
				
				//restore the positions swapped previously. Because this change does not produce good results.
				aux=fsp->genes_aux[j];
				fsp->genes_aux[j]=fsp->genes_aux[k];
				fsp->genes_aux[k]=aux;
			}
		}
		
		if (seguir==1)
		{
			//modificar la permutacion con aquel swap que mejore más.
			aux=fsp->genes_aux[best_k];
			fsp->genes_aux[best_k]=fsp->genes_aux[best_j];
			fsp->genes_aux[best_j]=aux;
            cost_opt=-fsp->EvaluateFSPMakespan(fsp->genes_aux);
		//	cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2(fsp->genes_aux, best_k, fsp->jobsTimeTable_aux);
		}
		iter++;
	}
	
	//int * inverted= new int[IND_SIZE];
	Invert(fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);
	
	if (best_j==0 && best_k==0)//si estas variables siguen si utilizar quiere decir que no se ha mejorado.
		return false;
	else
		return true;
	
}

/*
 * This method applies a greedy local search with the insert operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Insert(PFSP * fsp, CIndividual *  individual, int power)
{
	//cout<<"in insert: "<<individual<<endl;
	int cost_opt, cost_improve, cost_best_provisional;
	int seguir,j,k;
	int best_k=0, best_j=0;
	
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	
	cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
	//cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2( fsp->genes_aux, 0, fsp->jobsTimeTable_aux2);
	cost_best_provisional=cost_opt;
	
	seguir=1;
	int iter=0;
	while (((seguir && power==0) || (seguir && iter<power)))//&& EVALUATIONS<MAX_EVALUATIONS)
	{
		seguir=0;
		for (k=0; k<IND_SIZE; k++)
		{
			for (j=0; j<IND_SIZE;j++)
			{
				InsertAt(fsp->genes_aux,k,j);
				if(k<j){
					cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite( fsp->genes_aux, k, fsp->jobsTimeTable_aux);
					//cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite2(fsp->genes_aux, k, fsp->jobsTimeTable_aux2);
				}
				else{
					cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite( fsp->genes_aux, j, fsp->jobsTimeTable_aux);
					//cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite2(fsp->genes_aux, j, fsp->jobsTimeTable_aux2);
				}
					
				if (cost_improve>cost_best_provisional)
				{
					//cout<<"cost_improve: "<<cost_improve<<" cost_best: "<<cost_best_provisional<<endl;
					//guardar que el mejor swap
					//cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
					best_k=k;
					best_j=j;
					cost_best_provisional=cost_improve;
					seguir=1;
				}
				//restore the positions modified previously. Because this change does not produce good results.
				InsertAt( fsp->genes_aux,j,k);
			}
		}
		
		if (seguir==1)
		{
			//modificar la permutacion con aquel insert que mejore más.
			InsertAt( fsp->genes_aux,best_k,best_j);
			cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
			//cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2( fsp->genes_aux, 0, fsp->jobsTimeTable_aux2);
		}
		iter++;
	}
	
	Invert( fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);
	
	//cout<<"in insert after: "<<individual<<endl;
	if (best_j==0 && best_k==0)//si estas variables siguen si utilizar quiere decir que no se ha mejorado.
		return false;
	else
		return true;
}

/*
 * This method applies a greedy local search with the insert operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Insert2(PFSP * fsp, CIndividual *  individual, int power)
{	
	//timeval search;
	//timeval search2;
	//gettimeofday(&search,NULL);
	//cout<<"in insert: "<<individual<<endl;
	int cost_opt, cost_improve, cost_best_provisional;
	int seguir,j,k;
	int best_k=0, best_j=0;
	
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	
	//cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
	cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
	cost_best_provisional=cost_opt;
	
	seguir=1;
	int iter=0;
	while (((seguir && power==0) || (seguir && iter<power)) && EVALUATIONS<MAX_EVALUATIONS)
	{
		seguir=0;
		for (k=0; k<IND_SIZE && EVALUATIONS<MAX_EVALUATIONS; k++)
		{
			for (j=0; j<IND_SIZE && EVALUATIONS<MAX_EVALUATIONS;j++)
			{
				InsertAt(fsp->genes_aux,k,j);
				cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite2(fsp->genes_aux, MIN(k,j), fsp->jobsTimeTable_aux);
				if (cost_improve>cost_best_provisional)
				{
					//cout<<"cost_improve: "<<cost_improve<<" cost_best: "<<cost_best_provisional<<endl;
					//guardar que el mejor swap
					//cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
					best_k=k;
					best_j=j;
					cost_best_provisional=cost_improve;
					seguir=1;
				}
				//restore the positions modified previously. Because this change does not produce good results.
				InsertAt( fsp->genes_aux,j,k);
			}
		}

		if (seguir==1)
		{
			//modificar la permutacion con aquel insert que mejore más.
			InsertAt( fsp->genes_aux,best_k,best_j);
			//cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
			cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite2( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
		}
		iter++;
	}
	
	Invert( fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);

	//gettimeofday(&search2,NULL);
	//double t1=search.tv_sec+(search.tv_usec/1000000.0);
	//double t2=search2.tv_sec+(search2.tv_usec/1000000.0);
	//double time=t2-t1;
	//cout<<"time: "<<time<<endl;
	//cout<<individual<<endl;
	//exit(1);
	//cout<<"in insert after: "<<individual<<endl;
	if (best_j==0 && best_k==0)//si estas variables siguen si utilizar quiere decir que no se ha mejorado.
		return false;
	else
		return true;
}

bool LocalSearch_Greedy_Insert3(PFSP * fsp, CIndividual *  individual, int power)
{
	
	//timeval search;
	//timeval search2;
	//gettimeofday(&search,NULL);
	bool Improvement=false;
	int cost_opt, cost_improve, cost_best_provisional;
	int seguir, i,j;
	int * perm_aux= new int[IND_SIZE];
	int * best= new int[IND_SIZE];
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	CloneArray(fsp->genes_aux, best, IND_SIZE);
	cost_opt=individual->Value();
	cost_best_provisional=cost_opt;
	
	seguir=1;
	int iter=0;
	while (((seguir && power==0) || (seguir && iter<power)) && EVALUATIONS<MAX_EVALUATIONS)
	{
		seguir=0;
		//forward step
		for (i=0;i<(IND_SIZE-1) && EVALUATIONS<MAX_EVALUATIONS;i++)
		{
			CloneArray(fsp->genes_aux, perm_aux, IND_SIZE);
			perm_aux=Swap(perm_aux,i,i+1);
//			cost_improve=-fsp->EvaluateFSPTotalFlowtime(perm_aux);
                      cost_improve=-fsp->EvaluateFSPMakespan(perm_aux);
			if (cost_improve>cost_best_provisional)
			{
				CloneArray(perm_aux, best, IND_SIZE);
				cost_best_provisional=cost_improve;
				seguir=1;
			}
			
			for (j=i+1; j<(IND_SIZE-1) && EVALUATIONS<MAX_EVALUATIONS;j++)
			{
				perm_aux=Swap(perm_aux,j,j+1);
//				cost_improve=-fsp->EvaluateFSPTotalFlowtime(perm_aux);
                          cost_improve=-fsp->EvaluateFSPMakespan(perm_aux);
				if (cost_improve>cost_best_provisional)
				{
					CloneArray(perm_aux, best, IND_SIZE);
					cost_best_provisional=cost_improve;
					seguir=1;
				}
			}
		}
	
		//backward step
		fsp->genes_aux=Swap(fsp->genes_aux,0,1);
		for (i=2;i<IND_SIZE && EVALUATIONS<MAX_EVALUATIONS;i++)
		{
			fsp->genes_aux=Swap(fsp->genes_aux,0,i);
			
			CloneArray(fsp->genes_aux, perm_aux, IND_SIZE);
//			cost_improve=-fsp->EvaluateFSPTotalFlowtime(perm_aux);
            cost_improve=-fsp->EvaluateFSPMakespan(perm_aux);
			if (cost_improve>cost_best_provisional)
			{
				CloneArray(perm_aux, best, IND_SIZE);
				cost_best_provisional=cost_improve;
				seguir=1;
			}
			for (j=0;j<(i-2) && EVALUATIONS<MAX_EVALUATIONS;j++)
			{
				perm_aux=Swap(perm_aux,j,j+1);
//				cost_improve=-fsp->EvaluateFSPTotalFlowtime(perm_aux);
	          cost_improve=-fsp->EvaluateFSPMakespan(perm_aux);
				if (cost_improve>cost_best_provisional)
				{
					CloneArray(perm_aux, best, IND_SIZE);
					cost_best_provisional=cost_improve;
					seguir=1;
				}
			}
		}

		if (seguir==1)
		{
			Improvement=true;
			CloneArray(best, fsp->genes_aux, IND_SIZE);
			//cost_opt=-fsp->EvaluateFSPTotalFlowtime(fsp->genes_aux);
                  cost_opt=-fsp->EvaluateFSPMakespan(fsp->genes_aux);
		}
		iter++;
	}
	CloneArray(best, fsp->genes_aux, IND_SIZE);
	Invert(fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);

	delete [] perm_aux;
	delete [] best;
	return Improvement;
}


bool LocalSearch_Greedy_Insert_Incremental(PFSP * fsp, CIndividual *  individual, int orbit_size)
{
	//cout<<orbit_size<<endl;
	int min=0;
	int max=0;
	int min_job=0;
	int max_job=0;
	int * perm_aux= new int[IND_SIZE];

	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	//PrintArray(fsp->genes_aux, IND_SIZE, "best ");
	int cost_opt=individual->Value();
	int cost_best_provisional=cost_opt;
	int cost_improve=0;
	int best_k=0,best_j=0;
	bool seguir=false;

	for (int job=0;job<IND_SIZE && EVALUATIONS<MAX_EVALUATIONS;job++)
	{
		seguir=0;
		min=MAX(0,job-orbit_size);		
		max=MIN(IND_SIZE-1,job+orbit_size);
		
		//orbit limits
		if (orbit_size==5)
		{
			min_job=job;
			max_job=job+1;
		}
		else
		{
			if (job-orbit_size<0)
				min_job=-1;// do no execute lower index step
			else
				min_job=min;

			if (job+orbit_size>=IND_SIZE)
			{
				max=-1;
			}
			else
				max_job=max;
		}
		
		
	
	//	cout<<"job: "<<job<<" min: "<<min<<" min_job: "<<min_job<<" max: "<<max<<" max_job: "<<max_job<<endl;
		//cout<<"=========JOB: "<< job<<" min: "<<min<<" max: "<<max<<endl;		
		//lower orbit step
		for (int lower_index=min;lower_index<=min_job && EVALUATIONS<MAX_EVALUATIONS;lower_index++)
		{
			//cout<<"lower_index: "<<lower_index<<endl;
			InsertAt(fsp->genes_aux,job,lower_index);
	//		PrintArray(fsp->genes_aux, IND_SIZE,"lower ");
			cost_improve=-fsp->EvaluateFSPTotalFlowtime(fsp->genes_aux);
			if (cost_improve>cost_best_provisional)
			{
				//cout<<"lower: "<<cost_improve<<endl;
				best_k=job;
				best_j=lower_index;
				cost_best_provisional=cost_improve;
				seguir=1;
			}
			InsertAt(fsp->genes_aux,lower_index,job);
		}
		
		//upper orbit step
		for (int upper_index=max_job;upper_index<=max && EVALUATIONS<MAX_EVALUATIONS;upper_index++)
		{
			//cout<<"upper_index: "<<upper_index<<endl;
			InsertAt(fsp->genes_aux,job,upper_index);
	//		PrintArray(fsp->genes_aux, IND_SIZE,"upper ");
			cost_improve=-fsp->EvaluateFSPTotalFlowtime(fsp->genes_aux);
			if (cost_improve>cost_best_provisional)
			{
				//cout<<"upper: "<<cost_improve<<endl;
				best_k=job;
				best_j=upper_index;
				cost_best_provisional=cost_improve;
				seguir=1;
			}
			InsertAt( fsp->genes_aux,upper_index,job);
		}

		if (seguir==1)
		{
			//modificar la permutacion con aquel insert que mejore más.
			InsertAt( fsp->genes_aux,best_k,best_j);
			cost_opt=-fsp->EvaluateFSPTotalFlowtime(fsp->genes_aux);
		}
	}
	
	//CloneArray(best, fsp->genes_aux, IND_SIZE);
	Invert(fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);
	
	delete [] perm_aux;
	//delete [] best;
	////exit(1);
	if (best_j==0 && best_k==0)//si estas variables siguen si utilizar quiere decir que no se ha mejorado.
		return false;
	else
		return true;
}


/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 */
CIndividual * VNS(PFSP * fsp, CIndividual *  individual, int upper_iteraciones, int shake_power)
{	
	//cout<<"in: "<<individual<<endl;
	//cout<<"in: "<<individual<<endl;
	bool seguir1,seguir2;
	int iteracion=0;
	
	//save best individual
	CIndividual * best = individual->Clone();
	CIndividual * current = individual->Clone();
	do
	{
		do
		{
			//seguir1=  LocalSearch_Greedy_Swap(fsp, current,0);
			seguir1=  LocalSearch_Greedy_Swap2(fsp, current,0);
			//cout<<"after swap: "<<current<<endl;			
			//seguir2=  LocalSearch_Greedy_Insert(fsp, current,1);
			seguir2=  LocalSearch_Greedy_Insert3(fsp, current,1);
			//cout<<"in cycle: "<<current<<endl			
		}
		while (seguir2 && EVALUATIONS<MAX_EVALUATIONS);
		
		if (current->Value()>best->Value())
		{
			//cout<<"hobetzen: "<<endl;
			best=current->Clone();
			iteracion=0;
		}
		else if (current->Value()!=best->Value())
		{
			current=best->Clone();
		}
		
		//shake.
		Shake_Swap(current,shake_power);

		iteracion++;
		//cout<<"iteracion: "<<iteracion<<" fitness: "<<-best->Value()<<endl;
	}
	while (iteracion<upper_iteraciones && EVALUATIONS<MAX_EVALUATIONS);
	individual->SetGenes(best->Genes());
	
	delete current;
	delete best;
	//cout<<"out: "<<individual<<endl;
	return individual;
}

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 */
CIndividual * VNS(PFSP * fsp, CIndividual *  individual, int shake_power)
{	
	
	bool seguir1=true,seguir2=true;
	int iteracion=0;
	/*int ** m_influence_matrix= new int*[IND_SIZE];
	for (int i=0;i<IND_SIZE;i++)
	{
		m_influence_matrix[i]= new int[IND_SIZE];
	}
	*/
	//save best individual
	CIndividual * best = individual->Clone();
	CIndividual * current = individual->Clone();
	do
	{
		do
		{
			seguir1=  LocalSearch_Greedy_Swap2(fsp, current,0);
			seguir2=  LocalSearch_Greedy_Insert3(fsp, current,1);
		}
		while (seguir2 && EVALUATIONS<MAX_EVALUATIONS);

		if (current->Value()>best->Value())
		{
			//cout<<"hobetzen: "<<endl;
			best=current->Clone();
		}
		else if (current->Value()!=best->Value())
		{
			current=best->Clone();
		}
		
		//shake.
		#ifndef ORBIT_SHAKE
			Shake_Swap(current,shake_power);
			//Shake_Insert(current,shake_power);	
		#else
			//INSERT SHAKE WITH ORBITS!!!!
			Shake_Insert(current,shake_power,(rand()%ORBIT_SHAKE)+2);	
		#endif
		cout<<"iteracion: "<<iteracion<<" fitness: "<<-best->Value()<<endl;
		iteracion++;
	}
	while (EVALUATIONS<MAX_EVALUATIONS);
	individual->SetGenes(best->Genes());
	//	cout<<"out: "<<individual<<endl;
	delete current;
	delete best;
	return individual;
}

/*
 * Executes a variable neighborhood search over the insert and swap neighborhoods for the given PFSP instance.
 */
CIndividual * VNS_Inverted(PFSP * fsp, CIndividual *  individual, int shake_power)
{	
	
	bool seguir1=true,seguir2=true;
	int iteracion=0;
	/*int ** m_influence_matrix= new int*[IND_SIZE];
	 for (int i=0;i<IND_SIZE;i++)
	 {
	 m_influence_matrix[i]= new int[IND_SIZE];
	 }
	 */
	//save best individual
	CIndividual * best = individual->Clone();
	CIndividual * current = individual->Clone();
	do
	{
		do
		{
			seguir2=  LocalSearch_Greedy_Insert3(fsp, current,0);
			seguir1=  LocalSearch_Greedy_Swap2(fsp, current,1);
		}
		while (seguir2 && EVALUATIONS<MAX_EVALUATIONS);
		
		if (current->Value()>best->Value())
		{
			//cout<<"hobetzen: "<<endl;
			best=current->Clone();
		}
		else if (current->Value()!=best->Value())
		{
			current=best->Clone();
		}
		
		//shake.
#ifndef ORBIT_SHAKE
		Shake_Swap(current,shake_power);
		//Shake_Insert(current,shake_power);	
#else
		//INSERT SHAKE WITH ORBITS!!!!
		Shake_Insert(current,shake_power,(rand()%ORBIT_SHAKE)+2);	
#endif
		cout<<"iteracion: "<<iteracion<<" fitness: "<<-best->Value()<<endl;
		iteracion++;
	}
	while (EVALUATIONS<MAX_EVALUATIONS);
	individual->SetGenes(best->Genes());
	//	cout<<"out: "<<individual<<endl;
	delete current;
	delete best;
	return individual;
}

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 * Includes a guided shake swap that changes dynamically according to the improvement.
 */
CIndividual * VNS_dynamicOrbits(PFSP * fsp, CIndividual *  individual, int shake_power)
{	
	int orbit=ORBIT_SHAKE;
	bool seguir1=true,seguir2=true;
	int iteracion=0;
	int ** m_influence_matrix= new int*[IND_SIZE];
	for (int i=0;i<IND_SIZE;i++)
	{
		m_influence_matrix[i]= new int[IND_SIZE];
	}
	
	int no_improvement_iterations=0;
	//save best individual
	CIndividual * best = individual->Clone();
	CIndividual * current = individual->Clone();
	do
	{
		do
		{
			seguir1=  LocalSearch_Greedy_Swap2(fsp, current,0);
			seguir2=  LocalSearch_Greedy_Insert3(fsp, current,1);
		}
		while (seguir2 && EVALUATIONS<MAX_EVALUATIONS);
		
		if (current->Value()>best->Value())
		{
			//cout<<"hobetzen: "<<endl;
			best=current->Clone();
			no_improvement_iterations=0;
		}
		else if (current->Value()<=best->Value())
		{
			current=best->Clone();
			no_improvement_iterations++;
		}
		
		if (no_improvement_iterations!=0) 
		{
			if(orbit < IND_SIZE/2 && (no_improvement_iterations%10)==0)
			   orbit++;
		}
		else 
			orbit=ORBIT_SHAKE;
	
		//shake.
		Shake_Swap(current,shake_power,(rand()%orbit)+2);	

		cout<<"iteracion: "<<iteracion<<" fitness: "<<-best->Value()<<" orbit size: "<<orbit<<" no improvement: "<<no_improvement_iterations<<endl;
		iteracion++;
	}
	while (EVALUATIONS<MAX_EVALUATIONS);
	individual->SetGenes(best->Genes());
	
	delete current;
	delete best;
	return individual;
}

/*
 * Executes a variable neighborhood search over the insert incremental neighborhoods and swap neighborhood for scaping
 * from the local optima.
 */
CIndividual * IncrementalVNS(PFSP * fsp, CIndividual *  individual)
{
	//save best individual
	CIndividual * best = individual->Clone();
	CIndividual * current = individual->Clone();	
	int orbit_size=0;
	int iteracion=0;
	bool improve=false;
	do
	{
		do
		{
			orbit_size=5;
			while (orbit_size<=IND_SIZE/2 && EVALUATIONS<MAX_EVALUATIONS)
			{
				if (LocalSearch_Greedy_Insert_Incremental(fsp, current,orbit_size))
					orbit_size=5;
				else
					orbit_size++;
				//	cout<<"current: "<<current->Value()<<" orbit size: "<<orbit_size<<endl;				
			}
			improve=LocalSearch_Greedy_Swap2(fsp,current,1);
			//cout<<"inner: fitness: "<<-current->Value()<<endl;	
		}
		while (improve && EVALUATIONS<MAX_EVALUATIONS);
		//exit(1);
		if (current->Value()>best->Value())
		{
			//cout<<"hobetzen: "<<endl;
			best=current->Clone();
		}
		else if (current->Value()<=best->Value())
		{
			current=best->Clone();
		}
		cout<<"iteracion: "<<iteracion<<" fitness: "<<-best->Value()<<"   EVALUATIONS: "<<EVALUATIONS<<" REMAINING EVAL: "<<MAX_EVALUATIONS-EVALUATIONS<<endl;
		Shake_Insert(current, 10);
		iteracion++;
	}
	while (EVALUATIONS<MAX_EVALUATIONS);
	
	individual->SetGenes(best->Genes());
		
	delete current;
	delete best;
	return individual;
}


bool LocalSearch_BestFirst_Swap(PFSP * fsp, CIndividual * individual)
{
	//cout<<"in: "<<individual<<endl;
	int cost_opt, cost_improve;
	int seguir,j,k;
	bool Improvement=false;
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	cost_opt=individual->Value();
	
	seguir=1;
	while (seguir && EVALUATIONS<MAX_EVALUATIONS)
	{
		seguir=0;
		for (k=0; k<IND_SIZE-1; k++)
		{
			for (j=k+1; j<IND_SIZE;j++)
			{
				//swap k and j positions.
				Swap(fsp->genes_aux,k,j);
				cost_improve=-fsp->EvaluateFSPTotalFlowtime(fsp->genes_aux);		
				
				if (cost_improve>cost_opt)
				{
					cost_opt=cost_improve;
					seguir=1;
					Improvement=true;
				}
				else
				{
					//restore the positions swapped previously. Because this change does not produce good results.
					Swap(fsp->genes_aux,k,j);
				}
			}
		}
	}
	
	Invert(fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);
	//cout<<"out: "<<individual<<endl;
	
	return Improvement;
}


bool LocalSearch_BestFirst_Insert(PFSP * fsp, CIndividual *  individual)
{

	//cout<<"in: "<<individual<<endl;
	int cost_opt, cost_improve;
	int seguir,k;
	bool Improvement=false;
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	int * best= new int[IND_SIZE];
	cost_opt=individual->Value();
	CloneArray(fsp->genes_aux,best, IND_SIZE);
	for (k=0; k<IND_SIZE && EVALUATIONS<MAX_EVALUATIONS; k++)
	{
//		PrintArray(fsp->genes_aux,IND_SIZE,"genes: ");
		fsp->genes_aux=Shift(fsp,k);
		cost_improve=-fsp->EvaluateFSPTotalFlowtime(fsp->genes_aux);		
//		PrintArray(fsp->genes_aux,IND_SIZE,"genes2: ");
		if (cost_improve>cost_opt)
		{
			//cout<<"cost_opt: "<<cost_opt<<" cost_improve: "<<cost_improve<<endl;
			CloneArray(fsp->genes_aux,best, IND_SIZE);
			cost_opt=cost_improve;
			seguir=1;
			Improvement=true;
		}
	}
	
	Invert(best,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);
	//cout<<"out: "<<individual<<endl;
	delete [] best;
	return Improvement;
}

int * Shift(PFSP * fsp, int job_index)
{
	int * genes= new int [IND_SIZE];
	CloneArray(fsp->genes_aux,genes,IND_SIZE);
	int cost_opt=-fsp->EvaluateFSPTotalFlowtime(fsp->genes_aux);
	int cost_improve;
	if (job_index!=0)
	{
		InsertAt(genes, job_index, 0);
		cost_improve=-fsp->EvaluateFSPTotalFlowtime(genes);
		if (cost_improve>cost_opt)
		{
			//cout<<"first cost_opt: "<<cost_opt<<" cost_improve: "<<cost_improve<<endl;
			cost_opt=cost_improve;
			CloneArray(genes, fsp->genes_aux,IND_SIZE);
			return genes;
		}
	}
	for (int j=1;j<IND_SIZE;j++)
	{
		if (job_index==j)
		{
			if (j==IND_SIZE-1)
			{
				return fsp->genes_aux;
			}
			Swap(genes,j-1,j);
			j++;
		}
		Swap(genes,j-1,j);
		cost_improve=-fsp->EvaluateFSPTotalFlowtime(genes);
		if (cost_improve>cost_opt)
		{
			//cout<<"second cost_opt: "<<cost_opt<<" cost_improve: "<<cost_improve<<endl;
			cost_opt=cost_improve;
			CloneArray(genes, fsp->genes_aux,IND_SIZE);
			return genes;
		}
	}
	return fsp->genes_aux;
}

/*
 * It applies random shake_power times a perturbation over the given individual.
 */
void Shake_Swap(CIndividual *  individual, int shake_power)
{
	//shake_power= rand() % shake_power;
	int * genes= individual->Genes();
	int i,j,aux;
	for (int iter=0;iter<shake_power;iter++)
	{
		//permute randomly genes in position i and j to scape the stackeness in both neighborhood.
		i = rand() % IND_SIZE;
		j = rand() % IND_SIZE;
		aux=genes[j];
		genes[j]=genes[i];
		genes[i]=aux;
		//cout<<individual<<endl;
	}
	individual->SetGenes(genes);
}

/*
 * It applies random shake_power times a perturbation over the given individual. However the swaps
 * are limited to certain orbits.
 */
void Shake_Swap(CIndividual *  individual, int shake_power, int orbit_size)
{
	//cout<<"in: "<<individual<<endl;
	//shake_power= rand() % shake_power;
	int * genes= individual->Genes();
	//int * inverted= new int[IND_SIZE];
	//Invert(genes, IND_SIZE, inverted);
	int i,j,aux,min_range,max_range,val;
	int half_orbit=orbit_size/2;
	for (int iter=0;iter<shake_power;iter++)
	{
		//permute randomly genes in position i and j to scape the stackeness in both neighborhood.
		i = rand() % IND_SIZE;
		
		//j index is selected from a certain orbit of the i value.
		min_range=MAX(i-half_orbit,0);
		max_range=MIN(i+half_orbit,IND_SIZE-1);
		val = rand() % (max_range-min_range);
		j= min_range+val;
		//cout<<"i: "<<i<<" min: "<<min_range<<" max: "<<max_range<<" j: "<<j<<endl;
		
		//swap values
		aux=genes[j];
		genes[j]=genes[i];
		genes[i]=aux;
		
		//cout<<individual<<endl;
	}
	//Invert(inverted, IND_SIZE, genes);	
	//delete[] inverted;
	individual->SetGenes(genes);
	//cout<<"ou: "<<individual<<endl;
}

/*
 * It applies random shake_power times a perturbation over the given individual.
 */
void Shake_Insert(CIndividual *  individual, int shake_power)
{
	int * genes= individual->Genes();
	int * inverted= new int[IND_SIZE];
	Invert(genes, IND_SIZE, inverted);
	int i,j;
	for (int iter=0;iter<shake_power;iter++)
	{
		//permute randomly genes in position i and j to scape the stackeness in both neighborhood.
		i = rand() % IND_SIZE;
		j = rand() % IND_SIZE;
		inverted= InsertAt(inverted,i,j);
	}
	Invert(inverted, IND_SIZE, genes);	
	delete[] inverted;
	individual->SetGenes(genes);
}

/*
 * It applies random shake_power times a perturbation over the given individual.
 */
void Shake_Insert(CIndividual *  individual, int shake_power, int orbit_size)
{
	//cout<<"in: "<<individual<<endl;
	int * genes= individual->Genes();
	int * inverted= new int[IND_SIZE];
	Invert(genes, IND_SIZE, inverted);
	int i,j,min_range,max_range,val;
	int half_orbit=orbit_size/2;
	for (int iter=0;iter<shake_power;iter++)
	{
		//permute randomly genes in position i and j to scape the stackeness in both neighborhood.
		i = rand() % IND_SIZE;
		
		//j index is selected from a certain orbit of the i value.
		min_range=MAX(i-half_orbit,0);
		max_range=MIN(i+half_orbit,IND_SIZE-1);
		val = rand() % (max_range-min_range);
		j= min_range+val;
		//cout<<"i: "<<i<<" min: "<<min_range<<" max: "<<max_range<<" j: "<<j<<endl;
		inverted= InsertAt(inverted,i,j);
	}
		Invert(inverted, IND_SIZE, genes);	
		delete[] inverted;
	individual->SetGenes(genes);
		//cout<<"out: "<<individual<<endl;
}

/*
 * This method applies shake_power times a pertubation (swap) following the highest influence swaps.
 */
void Shake_Swap_GeneLinkage(CIndividual *  individual, int shake_power, int ** influenceMatrix)
{
	//cout<<"in: "<<individual<<endl;
	int * genes= individual->Genes();
	int i,j,aux,min_range,max_range,val;

	for (int iter=0;iter<1;iter++)
	{
		//permute randomly genes in position i and j to scape the stackeness in both neighborhood.
		i = rand() % IND_SIZE;
		
		//select the job with the highest influence in the swapping.
		j= MaxPosition(influenceMatrix[i],i);
	
		//cout<<"job: "<<i<<" job: "<<j<<endl;
		//swap values
		aux=genes[j];
		genes[j]=genes[i];
		genes[i]=aux;
		
	}
//	int * inverted= new int[IND_SIZE];
//	Invert(genes, IND_SIZE, inverted);	

	individual->SetGenes(genes);
	//cout<<"out: "<<individual<<endl;
	//exit(1);
//	delete[] inverted;
}

/*
 * Prints in the standard output genes.
 */
void Print(int * array, int size, string text)
{
	cout<<text<<" ";
	for (int i=0;i<size;i++){
		cout<<array[i]<<" ";
	}
	cout<<" "<<endl;
}

/*
 * This method implements the enhanced VNS purposed in the paper of the algorithm AGA of Xiao Xu.
 */
CIndividual * eVNS(CIndividual *  individual, int POWER, int k, PFSP * fsp)
{
	//cout<<"individual in: "<<individual<<endl;
	//cout<<"POWER: "<<POWER<<endl;
	//cout<<"repetitions: "<<k<<endl;
	//initialization of parameters
	int loop=1;
	int flag=0;
	int x1,x2=0;
	int i,j;
	
	//start vns execution.
	while(loop<=k  && EVALUATIONS<MAX_EVALUATIONS)// && timer.Time()<MAX_SECONDS)
	{
		flag=1;
		while(flag==1 && EVALUATIONS<MAX_EVALUATIONS)// && timer.Time()<MAX_SECONDS)
		{
			//cout<<individual<<endl;
			flag=0;
			for (i=0;i<POWER && EVALUATIONS<MAX_EVALUATIONS/* && timer.Time()<MAX_SECONDS*/;i++)
			{
				x1 = int(rand()%IND_SIZE);
				x2 = int(rand()%IND_SIZE);
				//cout<<"x1: "<<x1<<" x2: "<<x2<<endl;
				CIndividual * temp=individual->Clone();
				//cout<<"temp antes: "<<temp<<endl;
				//cout<<"x1: "<<x1<<" x2: "<<x2<<endl;
				temp->SetGenes(InsertAt(temp->Genes(),x1,x2));
				//cout<<"temp despues: "<<temp<<endl;
				
				if (temp->Value()>individual->Value())
				{
					individual->SetGenes(temp->Genes());
					flag=1;
					break;
				}
				delete temp;
			}
			
			if (flag!=1)
			{
				for(j=0;j<POWER  && EVALUATIONS<MAX_EVALUATIONS/* && timer.Time()<MAX_SECONDS*/;j++)
				{
					x1 = int(rand()%IND_SIZE);
					x2 = int(rand()%IND_SIZE);
					CIndividual * temp=individual->Clone();
					//	cout<<"temp antes: "<<temp<<endl;
					//	cout<<"x1: "<<x1<<" x2: "<<x2<<endl;
					temp->SetGenes(Swap(temp->Genes(),x1,x2));
					//	cout<<"temp despues: "<<temp<<endl;
					
					if (temp->Value()>individual->Value())
					{
						individual->SetGenes(temp->Genes());
						flag=1;
						break;
					}
					delete temp;
				}
			}
		}
		//	cout<<"loop: "<<loop<<endl;
		loop++;
	}
	//	cout<<"individual out: "<<individual<<endl;
	//	exit(1);
	return individual;
}

