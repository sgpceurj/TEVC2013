/*
 *  LR.cpp
 *  AGA
 *
 *  Created by Josu Ceberio Uribe on 1/9/12.
 *  Copyright 2012 University of the Basque Country. All rights reserved.
 *
 */

#include "LR.h"
#include "Tools.h"
#include "PermutationTools.h"
#include "PFSP.h"

CIndividual * LRnm(int size, PFSP * fsp)
{
	
	//0. Parameter initializations.
	int * S= new int[size];
	int * U= new int[size];
	int * U_Index= new int[size];
	
	//1. Initialize the non-ranked variables.
	for (int i=0;i<size;i++) U[i]=i;
	
	//2. For each position k in S, choose the job that fits the best according to the index function.
	for (int k=0;k<size;k++)
	{
		//cout<<"=========================::: K="<<k<<" :::=========================="<<endl;
		for (int i=0;i<size-k;i++)
		{
			//	cout<<"i: "<<i<<endl;
			U_Index[i]=IndexFunction(S, k, size, U[i], U, fsp);
		}
	//			PrintArray(U_Index,size-k, "U_Index: ");
		int * aux= new int[size-k];
		CloneArray(U, aux, size-k);
		AscendingSequence(U_Index, aux, U, size-k);
		delete [] aux;
		
		//choose that job with the lowest index function.
		S[k]=U[0];
		
		//Remove from U.
		RemoveAt(U,0,size);
	}
	int * inverted= new int[IND_SIZE];
	Invert(S,IND_SIZE,inverted);
	//3. Return the best solution.
	CIndividual * individual= new CIndividual(size);

	individual->SetGenes(inverted);
	
	delete [] U;
	delete [] U_Index;
	delete [] S;
	return individual;
}
CIndividual * Mixed_NonDeterministic_LRnm(int size, PFSP * fsp)
{
	//0. Parameter initializations.
	int * S= new int[size];
	int * U= new int[size];
	int * U_Index= new int[size];
	
	//1. Initialize the non-ranked variables.
	for (int i=0;i<size;i++) U[i]=i;
	
	//2. For each position k in S, choose the job that fits the best according to the index function.
	for (int k=0;k<size;k++)
	{
		//cout<<"=========================::: K="<<k<<" :::=========================="<<endl;
		for (int i=0;i<size-k;i++)
		{
			//	cout<<"i: "<<i<<endl;
			U_Index[i]=IndexFunction(S, k, size, U[i], U, fsp);
		}
		//PrintArray(U_Index,size-k, "U_Index: ");
		int * aux= new int[size-k];
		CloneArray(U, aux, size-k);
		AscendingSequence(U_Index, aux, U, size-k);
		delete [] aux;
		
		//choose that job with the lowest index function.
		int position=SamplePosition(U_Index, MIN(5,size-k));
		S[k]=U[position];
		
		//Remove from U.
		RemoveAt(U,position,size);
	}
	int * inverted= new int[IND_SIZE];
	Invert(S,IND_SIZE,inverted);
	//3. Return the best solution.
	CIndividual * individual= new CIndividual(size);
	
	individual->SetGenes(inverted);
	
	delete [] U;
	delete [] U_Index;
	delete [] S;	
	return individual;
}

CIndividual * NonDeterministic_LRnm(int size, PFSP * fsp)
{
	//0. Parameter initializations.
	int * S= new int[size];
	int * U= new int[size];
	int * U_Index= new int[size];
	
	//1. Initialize the non-ranked variables.
	for (int i=0;i<size;i++) U[i]=i;
	
	//2. For each position k in S, choose the job that fits the best according to the index function.
	for (int k=0;k<size;k++)
	{
		//cout<<"=========================::: K="<<k<<" :::=========================="<<endl;
		for (int i=0;i<size-k;i++)
		{
			//	cout<<"i: "<<i<<endl;
			U_Index[i]=IndexFunction(S, k, size, U[i], U, fsp);
		}
		//PrintArray(U_Index,size-k, "U_Index: ");
		int * aux= new int[size-k];
		CloneArray(U, aux, size-k);
		AscendingSequence(U_Index, aux, U, size-k);
		delete [] aux;
		
		//choose that job with the lowest index function.
		int position=SamplePosition(U_Index, size-k);
		//cout<<position<<endl;
		S[k]=U[position];
		
		//Remove from U.
		RemoveAt(U,position,size);
	}
	int * inverted= new int[IND_SIZE];
	Invert(S,IND_SIZE,inverted);
	//3. Return the best solution.
	CIndividual * individual= new CIndividual(size);
	
	individual->SetGenes(inverted);
	
	delete [] U;
	delete [] U_Index;
	delete [] S;
	return individual;
}

int SamplePosition(int * indexValues, int size)
{
	double sum=0;
	for (int i=0;i<size;i++)
		sum+=indexValues[i];
	
	//PrintArray(indexValues,size, "index values: ");
	//cout<<"sum: "<<sum<<endl;
	double * roulette= new double[size];
	
	for (int i=0;i<size;i++)
		roulette[i]=(sum-indexValues[i])/sum;
	
	
	//PrintArrayDouble(roulette, size, "probs: ");
	double randVal=(double)rand()/((double)RAND_MAX+1);
	double acumul=roulette[0];
	int index=0;
	for(index=0;(index<size-1 && acumul<randVal);index++)
		acumul += roulette[index+1];
	delete [] roulette;
	return index;
}


int IndexFunction(int * partialSequence, int k, int n, int i,int *U, PFSP * fsp)
{
	int index;
	int ITik=0;
	if (k!=0)
		ITik = IdleTime(partialSequence,i,k,n,fsp);
	int ATik = ArtificialTime(partialSequence,i,k,n, U, fsp);
	index = (n-k-2)*ITik+ATik;
	return index;
}

int IdleTime(int * partialSequence, int job_i, int position_k, int n, PFSP * fsp)  
{
	//cout<<"Idle time..."<<endl;
	//PrintArray(partialSequence, position_k, "Partial sequence: ");
	//cout<<"job_i: "<<job_i<<endl;
	//cout<<"position_k:"<<position_k<<endl;
	
	int IdleTime=0;
	double wjk;
	double aux1=n-2;
	double aux2=0;
	int m=fsp->MACHINE_NUM;
	int * idleTimes= new int[m-1];
	for (int i=0;i<m-1;i++)idleTimes[i]=0;
	
	fsp->IdleTimesAtPosition(partialSequence, position_k,job_i, idleTimes);
	
	for (int j=2;j<=m;j++)
	{
		aux2=position_k*(m-j);
		wjk= (double)m / (j+(aux2/aux1));
		//cout<<"wjk: "<<wjk<<" aux1: "<<aux1<<" aux2: "<<aux2<<endl;
		IdleTime+= wjk*max(idleTimes[j-2],0);
		//cout<<IdleTime<<endl;
	}
	delete [] idleTimes;
	//cout<<"IdleTime: "<<IdleTime<<" for job "<<job_i<<endl;
	
	return IdleTime;
}

int ArtificialTime(int * partialSequence, int job_i, int position_k, int n,int * U, PFSP * fsp) 
{
	//cout<<"Artificial time..."<<endl;
	// calculate the completion time of the job i.
	int Cim=fsp->PartialEvaluation(partialSequence, position_k, job_i);
	//cout<<"Cim: "<<Cim<<endl;
	
	// calculate the completion time of the  artificial job p.
	// calculate articial job times.
	int m=fsp->MACHINE_NUM;
	int * artificial_job_times= new int[m];
	for (int i=0;i<m;i++) artificial_job_times[i]=0;
	for (int i=1;i<n-position_k;i++)
	{
		for (int machine=0;machine<m;machine++)
		{
			artificial_job_times[machine]+=fsp->JOBPROCESSINGMATRIX[machine][U[i]];
		}
	}
	
	for (int machine=0;machine<m;machine++)
		artificial_job_times[machine]=(artificial_job_times[machine]/m);
	//PrintArray(artificial_job_times,m, "new times: ");
	int Cpm=fsp->PartialEvaluation(partialSequence, position_k, artificial_job_times);
	
	delete [] artificial_job_times;
	//cout<<"Cim: "<<Cim<<" Cpm: "<<Cpm<<" position k: "<<position_k<<" job: "<<job_i<<endl;
	return Cim + Cpm;
}
