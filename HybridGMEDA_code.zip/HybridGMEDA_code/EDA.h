#ifndef _EDA_
#define _EDA_
#include "Individual.h"
#include "Variables.h"
#include <fstream>
#include <iostream>
using std::ifstream;
using std::ofstream;

// Number of generations carried out at the moment.
extern int GEN_NUM;

// The value of the optimal soluction when it's known.
extern double OPTIMAL;

// The size of the population.
extern int POP_SIZE;

// The number of selected individuals.
extern int SEL_SIZE;

//The Theta upper value for the kendall distance.
extern double UPPER_THETA_KENDALL;

//The Theta upper value for the kendall distance.
extern double LOWER_THETA_KENDALL;

// The offspring size.
extern int OFFSPRING_SIZE;

// Whether elitism is used or not.
extern int ELITISM;

// The seed asigned to the process
extern int SEED;

// The individual size.
extern int IND_SIZE;

// The number of states the genes can take.
extern int * STATES;

// Number of evaluations performed.
extern unsigned long long int EVALUATIONS;

// Convergence evaluation of the best fitness.
extern unsigned long long int CONVERGENCE_EVALUATIONS;

// Maximum number of evaluations allowed performed.
extern unsigned long long int MAX_EVALUATIONS;

//Percentage of the evaluations assigned for the heuristic processes below.
extern float PERCENTAGE;

//Probability assigned to the consensus ranking.
extern double CR_PROBABILITY;

extern int MUL;

// Number of restarts carried out during the evolutionary process.
extern int RESTARTS;

// Maximum number of generations (used by the stopping criterium).
// When MAX_GENERATIONS=0 -> no limit
extern int MAX_GENERATIONS;

// Maximum number of generations without improvement.
extern int MAX_GENERATIONS_NO_IMPROVEMENT;

//Maximum number of restarts without improvement.
extern int MAX_RESTARTS_NO_IMPROVEMENT;

// Number of iterations without improvement.
extern int NO_IMPROVEMENT_GENERATIONS;

// Average fitness value of the sampled solutions.
extern double AVERAGE_SAMPLED_FITNESS;

// Theta spread parameter for the mallows model.
extern double THETAS_AVERAGE;

// Name of the file where the result will be stored.
extern char OUTPUTFILE[50];

// Name of the file where the log results will be stored (optional).
extern char LOGFILE[50];

// Output file stream of the result.
extern ofstream foutput;

// Output file stream of the log.
extern ofstream flog;

// Output file stream of the best log.
extern ofstream flog2;

// Best result convergente iteration.
extern int CONVERGENCE_ITERATION;

// Best fitness value found in the execution.
extern int BEST_FITNESS;

//the solution calculated by the EDA.
extern CIndividual * EDA_SOLUTION;

//Improvement rate of the EDA.
extern double EDA_IMPROVEMENT_RATE;

extern CIndividual * BEST;
#endif
