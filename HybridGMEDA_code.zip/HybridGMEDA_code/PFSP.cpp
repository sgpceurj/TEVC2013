/*
 *  PFSP.cpp
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "PFSP.h"
#include "Tools.h"
#include "EDA.h"
#include <fstream>
#include <iostream>
using std::ifstream;
using std::ofstream;
/*
 *Class constructor.
 */
PFSP::PFSP()
{
	
}

/*
 * Class destructor.
 */
PFSP::~PFSP()
{
	for	(int i=0;i<JOB_NUM;i++)
		delete [] JOBPROCESSINGMATRIX[i];
	delete [] JOBPROCESSINGMATRIX;
	
	//delete auxiliary data tables for evaluation.
	delete [] inverted_aux;
	delete [] genes_aux;
	for	(int i=0;i<MACHINE_NUM;i++)
		delete [] jobsTimeTable_aux[i];
	delete [] jobsTimeTable_aux; 
	
}

void PFSP::GenerateRandomInstance(int jobs_num, int machine_num, string filename)
{
	//generate processing time matrix.
	int ** processing_times= new int*[machine_num];
	for (int m=0;m<machine_num;m++)
	{
		processing_times[m]=new int[jobs_num];
		for (int j=0;j<jobs_num;j++)
		{
			processing_times[m][j]=1+rand()%99;
		}
	}
	
	//write instance
	ofstream instance;
	instance.open(filename.c_str());
	
	instance<<"number of jobs, number of machines, initial seed, upper bound and lower bound :"<<endl;
	instance<<jobs_num<<"           "<<machine_num<<"   0000        0000        0000"<<endl;
	instance<<"processing times :"<<endl;
	for (int m=0;m<machine_num;m++)
	{
		for (int j=0;j<jobs_num;j++)
		{
			instance<<" "<<processing_times[m][j];
		}
		instance<<""<<endl;
	}
	
	
	
	//delete matrix
	for (int m=0;m<machine_num;m++)
	{
		delete [] processing_times[m];
	}
	delete [] processing_times;
	
	//close file
	instance.close();
}
						 
int PFSP::ReadInstance(string filename)
{
	bool readMatrix=false;
	bool readDimension=false;
	//double **coordinates;
	char line[2048]; // variable for input value
	string data="";
	ifstream indata;
	indata.open(filename.c_str(),ios::in);
	//int num=0;
	while (!indata.eof())
	{
		//LEER LA LINEA DEL FICHERO
		indata.getline(line, 2048);
		stringstream ss;
		string sline;
		ss << line;
		ss >> sline;
		if (strContains(line,"number of jobs")==true && readMatrix==true)
		{
			break;
		}
		else if (strContains(line,"number of jobs")==true)
		{
			readDimension=true;
		}
		else if (readDimension==true)
		{
			//char * pch;
			JOB_NUM = atoi(strtok (line," "));
			//cout<<"JOB NUM: "<<JOB_NUM<<endl;
			MACHINE_NUM = atoi(strtok (NULL, " "));
			//cout<<"MACHINE NUM: "<<MACHINE_NUM<<endl;
			readDimension=false;
			
		}
		else if (readMatrix)
		{;
			if (data=="")
				data = line;
			else
				data = data+' '+line;
		}
		else if (strContains(line,"processing times :"))
		{
			readMatrix=true;
		}
	}
	indata.close();
	
	//BUILD JOB PROCESSING MATRIX
	//cout << "--> BUILDING JOB PROCESSING MATRIX" << endl;
	JOBPROCESSINGMATRIX = new int*[MACHINE_NUM];
	for (int i=0;i<MACHINE_NUM;i++)
	{
		JOBPROCESSINGMATRIX[i]= new int[JOB_NUM];
	}
	
	//FILL JOB PROCESSING MATRIX
	//cout << "--> FILLING JOB PROCESSING MATRIX: "<<data << endl;
	istringstream iss(data);
	int i=0;
	int j=0;
	do
	{
		string sub;
	    iss >> sub;
	    if (sub!="")
	    {
			//save distance in distances matrix. Save negative distance in order to minimize fitness instead of
			//maximize.
	    	JOBPROCESSINGMATRIX[i][j]= atoi(sub.c_str());
	    	if (j==JOB_NUM-1)
	    	{
	    		i++;
	    		j=0;
	    	}
	    	else
	    	{
	    		j++;
	    	}
	    }
	    else
	    {
	    	break;
	    }
	} while (iss);
	
	//initialize data structures for fast evaluations.
	jobsTimeTable_aux=(int**)malloc(sizeof(int*)*MACHINE_NUM);
	for (int i=0;i<MACHINE_NUM;i++)
		jobsTimeTable_aux[i]=(int*)malloc(sizeof(int)*JOB_NUM);
	genes_aux=new int[JOB_NUM];
	inverted_aux=new int[JOB_NUM];
	
	
	//BUILD JOB PROCESSING MATRIX
	//cout << "--> BUILDING JOB PROCESSING MATRIX" << endl;
	JOBPROCESSINGMATRIX2 = new int*[JOB_NUM];
	for (int i=0;i<JOB_NUM;i++)
	{
		JOBPROCESSINGMATRIX2[i]= new int[MACHINE_NUM];
	}
	
	for(int i=0;i<JOB_NUM;i++)
		for (int j=0;j<MACHINE_NUM;j++)
			JOBPROCESSINGMATRIX2[i][j]=JOBPROCESSINGMATRIX[j][i];
		
	return (JOB_NUM);
}

double PFSP::EvaluateFSPMakespan(int * genes)
{
    EVALUATIONS++;
	double fitness=0;
	double timeTable[MACHINE_NUM];
	
	for (int j=0;j<MACHINE_NUM;j++)
	{
		timeTable[j]=0;
	}
	for (int z=0;z<JOB_NUM;z++)
	{
		int job=genes[z];
		//cout<<"Job "<<job<<endl;
		for (int machine=0;machine<MACHINE_NUM;machine++)
		{
			double processingTime=JOBPROCESSINGMATRIX[machine][job];
			if (machine==0)
			{
				timeTable[machine]+=processingTime;
			}
			else
			{
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			//cout<<"M "<<machine<<" Time "<<timeTable[machine]<<endl;
		}
	}
	
	fitness=timeTable[MACHINE_NUM-1];
	return fitness;
}

int PFSP::EvaluateFSPTotalFlowtime(int * genes)
{
		EVALUATIONS++;
	int timeTable[MACHINE_NUM];
	int j,z, job;
	int machine;
		int prev_machine=0;
	//int genes[20]={2,16,8,14,13,7,18,12,15,5,6,0,1,3,4,17,19,11,10,9};
	int first_gene=genes[0];
	timeTable[0]=JOBPROCESSINGMATRIX[0][first_gene];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][first_gene];
	}
	
	int fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<JOB_NUM;z++)
	{
		job=genes[z];
		
		//machine 0 is always incremental, so:
		timeTable[0]+=JOBPROCESSINGMATRIX[0][job];
		prev_machine=timeTable[0];
		for (machine=1;machine<MACHINE_NUM;machine++)
		{			
			timeTable[machine]= MAX(prev_machine,timeTable[machine])+ JOBPROCESSINGMATRIX[machine][job];
			prev_machine=timeTable[machine];
		}
		
		fitness+=timeTable[MACHINE_NUM-1];
	}
	
	return fitness;
}

int PFSP::EvaluateFSPTotalFlowtime_Overwrite(int * genes, int from, int ** jobsTimeTable)
{
		EVALUATIONS++;
	int timeTable[MACHINE_NUM];
	int m, x, job, last_job,position,machine;
	int fitness=0;
	int prev_machine=0;
	if (from!=0)
	{
		//inicializamos el fitness
		for (x=0;x<from;x++)
			fitness+=jobsTimeTable[MACHINE_NUM-1][genes[x]];
		
		//cargamos el timetable desde el jobs
		last_job=genes[from-1];
		for (m=0;m<MACHINE_NUM;m++)
			timeTable[m]=jobsTimeTable[m][last_job];
	}
	else 
	{
		//sino, calculamos la primera posicion.
		timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
		jobsTimeTable[0][genes[0]]=timeTable[0];
		for (m=1;m<MACHINE_NUM;m++)
		{
			timeTable[m]=timeTable[m-1]+JOBPROCESSINGMATRIX[m][genes[0]];
			jobsTimeTable[m][genes[0]]=timeTable[m];
		}
		from=1;
		fitness=timeTable[MACHINE_NUM-1];
	}
	

	for (position=from;position<JOB_NUM;position++)
	{
		job=genes[position];
		
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		prev_machine=timeTable[0];
		jobsTimeTable[0][job]=timeTable[0];//guardar el timeTable en el jobsTimeTable.
		for (machine=1;machine<MACHINE_NUM;machine++)
		{			
			/*
			 if (prev_machine<timeTable[machine])
			 timeTable[machine] += JOBPROCESSINGMATRIX[machine][job];
			 else
			 timeTable[machine] = prev_machine + JOBPROCESSINGMATRIX[machine][job];
			 */
			timeTable[machine]= MAX(prev_machine,timeTable[machine])+ JOBPROCESSINGMATRIX[machine][job];
			prev_machine=timeTable[machine];
			jobsTimeTable[machine][job]=timeTable[machine];//guardar el timeTable en el jobsTimeTable.
		}
		fitness+=timeTable[MACHINE_NUM-1];
	}
	return fitness;
}

int PFSP::EvaluateFSPTotalFlowtime_Overwrite2(int * genes, int from, int ** jobsTimeTable)
{
		EVALUATIONS++;
	int timeTable[MACHINE_NUM];
	int prev_machine=0;
	int m, x, job, last_job,position,machine;
	int fitness=0;
	if (from!=0)
	{
		//inicializamos el fitness
		for (x=0;x<from;x++)
			fitness+=jobsTimeTable[MACHINE_NUM-1][genes[x]];
		
		//cargamos el timetable desde el jobs
		last_job=genes[from-1];
		for (m=0;m<MACHINE_NUM;m++)
			timeTable[m]=jobsTimeTable[m][last_job];
	}
	else 
	{
		//sino, calculamos la primera posicion.
		timeTable[0]=JOBPROCESSINGMATRIX2[genes[0]][0];
		jobsTimeTable[0][genes[0]]=timeTable[0];
		for (m=1;m<MACHINE_NUM;m++)
		{
			timeTable[m]=timeTable[m-1]+JOBPROCESSINGMATRIX2[genes[0]][m];
			jobsTimeTable[m][genes[0]]=timeTable[m];
		}
		from=1;
		fitness=timeTable[MACHINE_NUM-1];
	}
	
	for (position=from;position<JOB_NUM;position++)
	{
		job=genes[position];
		
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX2[job][0];
		prev_machine=timeTable[0];
		jobsTimeTable[0][job]=timeTable[0];//guardar el timeTable en el jobsTimeTable.
		for (machine=1;machine<MACHINE_NUM;machine++)
		{			
			/*if (prev_machine<timeTable[machine])
				timeTable[machine] += JOBPROCESSINGMATRIX2[job][machine];
			 else
				timeTable[machine] = prev_machine + JOBPROCESSINGMATRIX2[job][machine];*/
			timeTable[machine]= MAX(prev_machine,timeTable[machine])+ JOBPROCESSINGMATRIX2[job][machine];
			prev_machine=timeTable[machine];
			jobsTimeTable[machine][job]=timeTable[machine];//guardar el timeTable en el jobsTimeTable.
		}
		fitness+=timeTable[MACHINE_NUM-1];
	}
	
	return fitness;
}

int PFSP::EvaluateFSPTotalFlowtime_NonOverwrite(int * genes, int from, int ** jobsTimeTable)
{
	EVALUATIONS++;	
	int timeTable[MACHINE_NUM];
	int m, x ,job,last_job, position, machine;
	int fitness=0;
	int prev_machine=0;
	if (from!=0)
	{
		//inicializamos el fitness
		for (x=0;x<from;x++)
			fitness+=jobsTimeTable[MACHINE_NUM-1][genes[x]];
		
		//cargamos el timetable desde el jobs
		last_job=genes[from-1];
		for (m=0;m<MACHINE_NUM;m++)
			timeTable[m]=jobsTimeTable[m][last_job];
	}
	else 
	{
		//sino, calculamos la primera posicion.
		timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
		for (m=1;m<MACHINE_NUM;m++)
			timeTable[m]=timeTable[m-1]+JOBPROCESSINGMATRIX[m][genes[0]];
		from=1;
		fitness=timeTable[MACHINE_NUM-1];
	}
	
	
	for (position=from;position<JOB_NUM;position++)
	{
		job=genes[position];
		
		//machine 0 is always incremental, so:
		timeTable[0]+=JOBPROCESSINGMATRIX[0][job];
		prev_machine=timeTable[0];
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			/*
			if (prev_machine<timeTable[machine])
				timeTable[machine] += JOBPROCESSINGMATRIX[machine][job];
			else
				timeTable[machine] = prev_machine + JOBPROCESSINGMATRIX[machine][job];
			*/
			timeTable[machine]= MAX(prev_machine,timeTable[machine])+ JOBPROCESSINGMATRIX[machine][job];
			prev_machine=timeTable[machine];
		}
		fitness+=timeTable[MACHINE_NUM-1];
	}
	
	return fitness;
}

int PFSP::EvaluateFSPTotalFlowtime_NonOverwrite2(int * genes, int from, int ** jobsTimeTable)
{
	EVALUATIONS++;
	int timeTable[MACHINE_NUM];
	int m, x ,job,last_job, position, machine;
	int fitness=0;
	int prev_machine=0;
	if (from!=0)
	{
		//inicializamos el fitness
		for (x=0;x<from;x++)
			fitness+=jobsTimeTable[MACHINE_NUM-1][genes[x]];
		
		//cargamos el timetable desde el jobs
		last_job=genes[from-1];
		for (m=0;m<MACHINE_NUM;m++)
			timeTable[m]=jobsTimeTable[m][last_job];
	}
	else 
	{
		//sino, calculamos la primera posicion.
		timeTable[0]=JOBPROCESSINGMATRIX2[genes[0]][0];
		for (m=1;m<MACHINE_NUM;m++)
			timeTable[m]=timeTable[m-1]+JOBPROCESSINGMATRIX2[genes[0]][m];
		from=1;
		fitness=timeTable[MACHINE_NUM-1];
	}
	
	
	for (position=from;position<JOB_NUM;position++)
	{
		job=genes[position];
		
		//machine 0 is always incremental, so:
		timeTable[0]+=JOBPROCESSINGMATRIX2[job][0];
		prev_machine=timeTable[0];
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			/*if (prev_machine<timeTable[machine])
				timeTable[machine] += JOBPROCESSINGMATRIX2[job][machine];
			else
				timeTable[machine] = prev_machine + JOBPROCESSINGMATRIX2[job][machine];*/
			timeTable[machine]= MAX(prev_machine,timeTable[machine])+ JOBPROCESSINGMATRIX2[job][machine];
			prev_machine=timeTable[machine];
		}
		fitness+=timeTable[MACHINE_NUM-1];
	}
	
	return fitness;
}

/*
 * This function calculates the profiles between each job, and the calculates the sum of all of them
 */
double PFSP::EvaluateFSPResidualProfileSum(int * genes)
{
	double residualProfile=0;
	
	double timeTable[MACHINE_NUM];
	int j,z, job,machine,processingTime;

	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
		residualProfile+=timeTable[j]-timeTable[j-1];
	}
	
	for (z=1;z<JOB_NUM;z++)
	{
		job=genes[z];
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{
				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		residualProfile+=timeTable[machine]-timeTable[machine-1];
	}
	return residualProfile;
}

int* PFSP::GetJobSumTimesVector(int * permutation, int size)
{
	int * realVector= new int[size];
	int sum=0;
	for (int j=0;j<JOB_NUM;j++){
		sum=0;
		for (int z=0;z<MACHINE_NUM;z++)
			sum=sum+JOBPROCESSINGMATRIX[z][permutation[j]];
		realVector[j]=sum;
	}
	return realVector;
}

void PFSP::ProcessingTimeAverages(double * ptAvg)
{
	double sum;
	for (int i=0;i<JOB_NUM;i++)
	{
		sum=0;
		for (int z=0;z<MACHINE_NUM;z++)
			sum=sum+JOBPROCESSINGMATRIX[z][i];
		ptAvg[i]=sum;
	}
}

void PFSP::JobSlopeAnalysis(double * slopes)
{
	int times[MACHINE_NUM];
	int x[MACHINE_NUM];
	
	for (int i=0;i<MACHINE_NUM;i++) x[i]=i;
	
	for (int j=0;j<JOB_NUM;j++)
	{
		for (int z=0;z<MACHINE_NUM;z++)
			times[z]=JOBPROCESSINGMATRIX[z][j];
		slopes[j]=RegressionLineSlope(x, times, MACHINE_NUM);
	}
}

/*
 * Calculates the partial TFT of each job pair, in start condition.
 */
void PFSP::JobsPartialTFTAnalysis(int ** partialTFTs, int * residualProfile)
{
	int i,j,m;
	int partialTFTij,partialTFTji,processingTime;
	int timeTable[MACHINE_NUM];
	for (i=0;i<JOB_NUM;i++)
	{
		for (j=i+1;j<JOB_NUM;j++)
		{
			
			//partial TFT of jobs i->j	
			
			//add the residual delay at the begining.
			for (m=0;m<MACHINE_NUM;m++) timeTable[m]=residualProfile[m];
			
			//machine 0 is always incremental, so: increment job i
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][i];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][i];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			partialTFTij=timeTable[MACHINE_NUM-1];
			
			
			//machine 0 is always incremental, so: increment job j
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][j];
			
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][j];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			partialTFTij+=timeTable[MACHINE_NUM-1];
			partialTFTs[i][j]=partialTFTij;
			
			//delay of jobs j->i
			
			//add the residual delay at the begining.
			for (m=0;m<MACHINE_NUM;m++) timeTable[m]=residualProfile[m];
			
			//machine 0 is always incremental, so: increment job i
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][j];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][j];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			partialTFTji=timeTable[MACHINE_NUM-1];
			
			//machine 0 is always incremental, so:
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][i];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][i];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			
			partialTFTji+=timeTable[MACHINE_NUM-1];
			partialTFTs[j][i]=partialTFTji;
			
		}
	}
}

/*
 * Calculates the delay produces by each job pair, or if there is not delay, the margin until a delay can be produced.
 */
void PFSP::JobsDelayMarginAnalysis(int ** delays, int * residualProfile)
{
	int i,j,m;
	int delayij,delayji,processingTime;
	int timeTable[MACHINE_NUM];
	int margins[MACHINE_NUM-1];
	for (i=0;i<JOB_NUM;i++)
	{
		for (j=i+1;j<JOB_NUM;j++)
		{
			
			///////////////// delay/maring of jobs i->j	/////////////////////////
			delayij=0;
			
			//add the residual delay at the begining.
			timeTable[0]=residualProfile[0];
			for (m=1;m<MACHINE_NUM;m++) timeTable[m]=timeTable[m-1]+residualProfile[m];
			
			//add first job i processing time
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][i];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][i];
				
				if (timeTable[machine-1]<timeTable[machine])
					//update timeTable.
					timeTable[machine]=timeTable[machine]+processingTime;
				else
					//update timeTable.
					timeTable[machine]= timeTable[machine-1]+processingTime;
			}		
			
			//add first job j processing time
			//machine 0 is always incremental, so:
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][j];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][j];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					//delay status
					//acumulate delay
					delayij=delayij+timeTable[machine]-timeTable[machine-1];
					margins[machine-1]=0;//there is no margin.
					
					//update timeTable.
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					//margin status
					//save margin
					margins[machine-1]=timeTable[machine-1]-timeTable[machine];
					
					//update timeTable.
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}		
			
			//fill i->j delay or margin in the resulting matrix.
			if (delayij==0)
				delays[i][j]=-Min(margins, MACHINE_NUM-1);//if there is no delay, save the margin.
			else
				delays[i][j]=delayij;
			
			
			///////////////// delay/maring of jobs j->i	/////////////////////////	
			delayji=0;
			
			//add the residual delay at the begining.
			timeTable[0]=residualProfile[0];
			for (m=1;m<MACHINE_NUM;m++) timeTable[m]=timeTable[m-1]+residualProfile[m];
			
			//add first job i processing time
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][j];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][j];
				
				if (timeTable[machine-1]<timeTable[machine])
					//update timeTable.
					timeTable[machine]=timeTable[machine]+processingTime;
				else
					//update timeTable.
					timeTable[machine]= timeTable[machine-1]+processingTime;
			}	
			
			//machine 0 is always incremental, so:
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][i];
			
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][i];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					//delay status
					//acumulate delsh ay
					delayji=delayji+timeTable[machine]-timeTable[machine-1];
					margins[machine-1]=0;//there is no margin.
					
					//update timeTable.
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					//margin status
					//save margin
					margins[machine-1]=timeTable[machine-1]-timeTable[machine];
					
					//update timeTable.
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}		
			
			//fill j->i delay or margin in the resulting matrix.
			if (delayji==0)
				delays[j][i]=-Min(margins, MACHINE_NUM-1);//if there is no delay, save the margin.
			else
				delays[j][i]=delayji;
			
		}
	}
}

/*
 * Calculates the machine idle time that produces each job pair.
 */
void PFSP::MachineIdleTimeAnalysis(int ** idleTimes)
{
	int i,j;
	int machineITij,machineITji,processingTime;
	int timeTable[MACHINE_NUM];
	for (i=0;i<JOB_NUM;i++)
	{
		for (j=i+1;j<JOB_NUM;j++)
		{
			//partial TFT of jobs i->j	

			//machine 0 is always incremental, so: increment job i
			timeTable[0]=JOBPROCESSINGMATRIX[0][i];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][i];
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
			
			//machine 0 is always incremental, so: increment job j
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][j];
			machineITij=0;
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][j];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					//machine idle time occurs
					machineITij += timeTable[machine-1] - timeTable[machine];
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			
		//	cout<<"ij: "<<machineITij<<endl;
			idleTimes[i][j]=machineITij;
			
			//delay of jobs j->i
						
			//machine 0 is always incremental, so: increment job i
			timeTable[0]=JOBPROCESSINGMATRIX[0][j];
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][j];
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		
			//machine 0 is always incremental, so:
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][i];
			machineITji=0;
			for (int machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][i];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
				
					machineITji += timeTable[machine-1] - timeTable[machine];
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
				
			}

		//	cout<<"ji: "<<machineITji<<endl;
			idleTimes[j][i]=machineITji;
		}
	}
}

void PFSP::SolutionIncrementalDelay(int * genes, int size, double * incrementalSolution)
{
	//double* jobsCompletionTimes= new double[JOB_NUM];
	double timeTable[MACHINE_NUM];
	int j,z, job,machine,processingTime;
	double delayij=0;
	
	
	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
	}
	incrementalSolution[0]=0;
	
	double fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<size;z++)
	{
		job=genes[z];
		
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{
				delayij=delayij+timeTable[machine]-timeTable[machine-1];
				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		
		//jobsCompletionTimes[z]=timeTable[MACHINE_NUM-1];
		fitness=fitness+timeTable[MACHINE_NUM-1];
		incrementalSolution[z]= delayij;
	}

}

int PFSP::IncrementalDelay(int * genes, int size)
{
	//double* jobsCompletionTimes= new double[JOB_NUM];
	int timeTable[MACHINE_NUM];
	int incrementalSolution[size];
	int j,z, job,machine,processingTime;
	int delayij=0;

	
	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
	}
	incrementalSolution[0]=0;
	int incrementalDelay=0;
	int fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<size;z++)
	{
		job=genes[z];
		
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{
				delayij=delayij+timeTable[machine]-timeTable[machine-1];
				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		
		//jobsCompletionTimes[z]=timeTable[MACHINE_NUM-1];
		fitness=fitness+timeTable[MACHINE_NUM-1];
		incrementalSolution[z]= delayij;
		incrementalDelay+=delayij;
	}
	return incrementalDelay;
}

int PFSP::IncrementalIdle(int * genes, int size)
{
	int timeTable[MACHINE_NUM];
	int j,z, job,machine,processingTime;
	
	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
	}
	int incrementalIdle=0;

	for (z=1;z<size;z++)
	{
		job=genes[z];
		
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{				
				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				incrementalIdle += timeTable[machine-1] - timeTable[machine];
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
	}
	return incrementalIdle;
}

void PFSP::PartialDelay(int * genes, int size, int * delays)
{
	//double* jobsCompletionTimes= new double[JOB_NUM];
	int timeTable[MACHINE_NUM];

	int j,z, job,machine,processingTime;
	int delayij=0;
	
	
	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
	}
	delays[0]=0;
	
	int fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<size;z++)
	{
		job=genes[z];
		delayij=0;
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{
				delayij=delayij+timeTable[machine]-timeTable[machine-1];
				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		fitness=fitness+timeTable[MACHINE_NUM-1];
		delays[z]= delayij;
	}
	
}

void PFSP::PartialIdle(int * genes, int size, int * idles)
{
	//double* jobsCompletionTimes= new double[JOB_NUM];
	int timeTable[MACHINE_NUM];
	
	int j,z, job,machine,processingTime;
	int incrementalIdle=0;
	
	
	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
	}
	idles[0]=0;
	
	int fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<size;z++)
	{
		job=genes[z];
		incrementalIdle=0;
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{

				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				incrementalIdle += timeTable[machine-1] - timeTable[machine];
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		fitness=fitness+timeTable[MACHINE_NUM-1];
		idles[z]= incrementalIdle;
	}
	
}

void PFSP::ResidualProfile(int * genes, int size, int position, int * residualProfile)
{
	int timeTable[MACHINE_NUM];
	int j,z, job,machine,processingTime;
	for (int i=0;i<MACHINE_NUM;i++) residualProfile[i]=0;
	
	if (position!=0)
	{
		timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
		for (j=1;j<MACHINE_NUM;j++)
		{
			timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
		}
		
		for (z=1;z<position;z++)
		{
			job=genes[z];
			//machine 0 is always incremental, so:
			timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
			
			for (machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][job];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]=timeTable[machine]+processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
		}
		for (machine=1;machine<MACHINE_NUM;machine++)
			residualProfile[machine]=timeTable[machine]-timeTable[machine-1];
	}
}

void PFSP::SolutionIncrementalTFT(int * genes, int size, double * incrementalSolution)
{
	//double* jobsCompletionTimes= new double[JOB_NUM];
	double timeTable[MACHINE_NUM];
	int j,z, job,machine,processingTime;
	
	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
	}
	incrementalSolution[0]=timeTable[MACHINE_NUM-1];
	
	double fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<size;z++)
	{
		job=genes[z];
		
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{
				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		fitness=fitness+timeTable[MACHINE_NUM-1];
		incrementalSolution[z]= fitness;
	}
}

void PFSP::SolutionPartialTFT(int * genes, int size, double * partialSolution)
{
	double timeTable[MACHINE_NUM];
	int j,z, job,machine,processingTime;
	
	timeTable[0]=JOBPROCESSINGMATRIX[0][genes[0]];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][genes[0]];
	}
	partialSolution[0]=timeTable[MACHINE_NUM-1];
	
	double fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<size;z++)
	{
		job=genes[z];
		
		//machine 0 is always incremental, so:
		timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{
				timeTable[machine]=timeTable[machine]+processingTime;
			}
			else
			{
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		fitness=fitness+timeTable[MACHINE_NUM-1];
		partialSolution[z]= timeTable[MACHINE_NUM-1];
	}
}

double PFSP::RegressionLineSlope (int * x, int * y, int N)
{
	double s0 = 0;
	double s1 = 0;
	double s2 = 0;
	double t0 = 0;
	double t1 = 0;
	for (int i=0;i<N;i++)
	{		
		s0++;
		s1 = s1 + x[ i ];
		s2 = s2 + x[ i ]*x[ i ];
		t0 = t0 + y[ i ];
		t1 = t1 + x[ i ]*y[i ];
	}				
	
	double M = ( s0*t1 - s1*t0 ) / (s0*s2 - s1*s1) ; // slope
	
	double B = ( s2*t0 - s1*t1 ) / (s0*s2 - s1*s1) ; // y-intercept
	
	//the regression line is given by y = Mx + B
	
	//calculate slope
	double y1= M*x[0]+B;
	double y2= M*x[N-1]+B;
	double slope= (y2-y1)/(x[N-1]-x[0]);
	//cout<<"y1: "<<y1<<" y2: "<<y2<<" slope: "<<slope<<endl;
	
	return slope;
}

void  PFSP:: IdleTimesAtPosition(int * sequence, int size, int job_i, int * idleTimes)
{
	//cout<<"In Idle times at position, pfsp.o"<<endl;
	int timeTable[MACHINE_NUM];
	int job,j,z,machine,processingTime;
	
	int first_gene=sequence[0];
	timeTable[0]=JOBPROCESSINGMATRIX[0][first_gene];
	for (j=1;j<MACHINE_NUM;j++)
	{
		timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][first_gene];
	}
	//PrintArray(sequence,size,"sequence: ");
	
	int fitness=timeTable[MACHINE_NUM-1];
	for (z=1;z<size;z++)
	{
		job=sequence[z];
		
		//machine 0 is always incremental, so:
		timeTable[0]+=JOBPROCESSINGMATRIX[0][job];
		
		for (machine=1;machine<MACHINE_NUM;machine++)
		{
			processingTime=JOBPROCESSINGMATRIX[machine][job];
			
			if (timeTable[machine-1]<timeTable[machine])
			{
				timeTable[machine]+=processingTime;
			}
			else
			{
				timeTable[machine]= timeTable[machine-1]+processingTime;
			}
		}
		
		fitness+=timeTable[MACHINE_NUM-1];
	}
	
	//machine 0 is always incremental, so: increment job j
	timeTable[0]=timeTable[0]+JOBPROCESSINGMATRIX[0][job_i];
	
	for (machine=1;machine<MACHINE_NUM;machine++)
	{
		processingTime=JOBPROCESSINGMATRIX[machine][job_i];
		
		if (timeTable[machine-1]<timeTable[machine])
		{
			timeTable[machine]=timeTable[machine]+processingTime;
		}
		else
		{
			//machine idle time occurs
			idleTimes[machine-1]=timeTable[machine-1] - timeTable[machine];
			//cout<<"idle time: "<<idleTimes[machine-1]<<" machine-1: "<<timeTable[machine-1]<<" machine: "<<timeTable[machine]<<endl;
			timeTable[machine]= timeTable[machine-1]+processingTime;
			
		}
	}
	fitness+=timeTable[MACHINE_NUM-1];
}

/*
 * Partial evaluation method for LR constructive heuristic method. The call to this method is expected in the index function.
 */
int PFSP::PartialEvaluation(int * genes, int size, int * new_job_times)
{
	int timeTable[MACHINE_NUM];
	int j,z, job,processingTime;
	int machine;
	int fitness=0;
	for (int i=0;i<MACHINE_NUM;i++)	timeTable[i]=0;
	
	if (size!=0)
	{
		
		int first_gene=genes[0];
		timeTable[0]=JOBPROCESSINGMATRIX[0][first_gene];
		for (j=1;j<MACHINE_NUM;j++)
		{
			timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][first_gene];
		}
		
		fitness=timeTable[MACHINE_NUM-1];
		
		for (z=1;z<size;z++)
		{
			
			job=genes[z];
			
			//machine 0 is always incremental, so:
			timeTable[0]+=JOBPROCESSINGMATRIX[0][job];
			
			for (machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][job];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]+=processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			
			fitness+=timeTable[MACHINE_NUM-1];
		}
		
	}
	//Append the final job of the partial evaluation.
	//machine 0 is always incremental, so:
	timeTable[0]+=new_job_times[0];
	
	for (machine=1;machine<MACHINE_NUM;machine++)
	{
		processingTime=new_job_times[machine];
		
		if (timeTable[machine-1]<timeTable[machine])
		{
			timeTable[machine]+=processingTime;
		}
		else
		{
			timeTable[machine]= timeTable[machine-1]+processingTime;
		}
	}
	
	fitness+=timeTable[MACHINE_NUM-1];
	
	return fitness;
}

int PFSP::PartialEvaluation(int * genes, int size, int new_job)
{
	int timeTable[MACHINE_NUM];
	int j,z, job,processingTime;
	int machine;
	int fitness=0;
	for (int i=0;i<MACHINE_NUM;i++)	timeTable[i]=0;
	
	if (size!=0)
	{
		
		
		//int genes[20]={2,16,8,14,13,7,18,12,15,5,6,0,1,3,4,17,19,11,10,9};
		int first_gene=genes[0];
		timeTable[0]=JOBPROCESSINGMATRIX[0][first_gene];
		for (j=1;j<MACHINE_NUM;j++)
		{
			timeTable[j]=timeTable[j-1]+JOBPROCESSINGMATRIX[j][first_gene];
		}
		
		fitness=timeTable[MACHINE_NUM-1];
		
		for (z=1;z<size;z++)
		{
			job=genes[z];
			
			//machine 0 is always incremental, so:
			timeTable[0]+=JOBPROCESSINGMATRIX[0][job];
			
			for (machine=1;machine<MACHINE_NUM;machine++)
			{
				processingTime=JOBPROCESSINGMATRIX[machine][job];
				
				if (timeTable[machine-1]<timeTable[machine])
				{
					timeTable[machine]+=processingTime;
				}
				else
				{
					timeTable[machine]= timeTable[machine-1]+processingTime;
				}
			}
			
			fitness+=timeTable[MACHINE_NUM-1];
		}
		
	}
	
	//Append the final job of the partial evaluation.
	//machine 0 is always incremental, so:
	timeTable[0]+=JOBPROCESSINGMATRIX[0][new_job];
	
	for (machine=1;machine<MACHINE_NUM;machine++)
	{
		processingTime=JOBPROCESSINGMATRIX[machine][new_job];
		
		if (timeTable[machine-1]<timeTable[machine])
		{
			timeTable[machine]+=processingTime;
		}
		else
		{
			timeTable[machine]= timeTable[machine-1]+processingTime;
		}
	}
	
	fitness+=timeTable[MACHINE_NUM-1];
	return fitness;
}

