#ifndef _NEWVNS_
#define _NEWVNS_
#include "Individual.h"
#include "Timer.h"
#include <fstream>
#include <iostream>
using std::ifstream;
using std::ofstream;

// The seed asigned to the process
extern int SEED;

// The individual size.
extern int IND_SIZE;
// Number of evaluations performed.
extern double EVALUATIONS;

// Convergence evaluation of the best fitness.
extern double CONVERGENCE_EVALUATIONS;

// Maximum number of evaluations allowed performed.
extern double MAX_EVALUATIONS;

// Name of the file where the result will be stored.
extern char OUTPUTFILE[50];

// Name of the file where the log results will be stored (optional).
extern char LOGFILE[50];

// Output file stream of the result.
extern ofstream foutput;

// Best fitness value found in the execution.
extern int BEST_FITNESS;

extern CIndividual * BEST;

extern CTimer timer;
#endif
