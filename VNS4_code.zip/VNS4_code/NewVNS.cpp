
#include "NewVNS.h"
#include "Problem.h"
//#include "PermutationTools.h"
#include "Tools.h"
#include "Seed.h"
#include "VNS_4.h"
#include "LR.h"
#include <stdlib.h>
#include <sys/time.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
using std::istream;
using std::ostream;
using namespace std;
#define itoa(a,b,c) sprintf(b, "%d",a)
#include "string.h"

// time calculation variables.
timeval start,stop;

// Best fitness value found in the execution.
int BEST_FITNESS=INT_MIN;

// The individual size.
int IND_SIZE;

// The number of states the genes can take.
int * STATES;

// Number of evaluations performed.
double EVALUATIONS = 0;

// Convergence evaluation of the best fitness.
double CONVERGENCE_EVALUATIONS = 0;

// Maximum number of evaluations allowed performed.
double MAX_EVALUATIONS = 0;

// Name of the file where the result will be stored.
char OUTPUTFILE[50];

// Name of the file where the log results will be stored (optional).
char LOGFILE[50];

char DATA_FILE_NAME[50];

// The seed asigned to the process
int SEED;

// Input file stream of the instance.
ifstream fdatafile;

// Output file stream of the result.
ofstream foutput;

CIndividual * BEST;

CTimer timer;

/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
	
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
	
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
		
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
			
            if (isalnum(chOpt) || ispunct(chOpt))
            {	
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
				
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
							
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
	
    iArg++;
	
    *ppszParam = pszParam;
    return (chOpt);
}

/*
 * Usage guide
 */
void usage(char *progname)
{
	cerr
	<< "Usage: " << progname << " -N pop_size -S sel_size  -a caching -i simulation_type" << endl
	<< "        -l learning_type -c score -f offspring_size -e elitism -g save_structures -o output_file -w data_filename" << endl
	<< endl
	<< "-N pop_size: number of individuals in the population. (def:2000)" << endl
	<< "-S sel_size: number of selected individuals. (def:1000)" << endl
	<< "-c score: type of score (only for EBNA): " << endl
	<< "       BIC (0) or K2 (1). (def:0)" << endl
	<< "-l learning: how the Bayesian network is learned:" << endl
	<< "       UMDA (0), EBNA with B algorithm (1), " << endl
	<< "       EBNA with local search (2), PBIL with alpha = 0.5 (3)," << endl
	<< " 	 BSC (4), TREE(5), MIMIC(6), EBNA K2 + penalization (7)," << endl
	<< "   EBNA PC (8) or EBNA with global search (9)," << endl
	<< "   Permutations Marginal Modelling (11), Mallows (12)." << endl
	<< "-b bias correction: (only for K-order marginals based EDA): [0-1]  (def:1)"<<endl
	<< "-f offspring_size: how many individuals are created in" << endl
	<< "       each generation. (def:1999)" << endl
	<< "-e elitism: how the next population is created: " << endl
	<< "       elitism (1) or no-elitism (0). (def:1)" << endl
	<< "-a caching: whether the values of the evaluated individuals.  (def:1)" << endl	      
	<< "-i simulation: type of simulation: PLS (0), " << endl
	<< "       PLS forcing all values LTM (1) and ATM (2)," << endl
	<< "       correction after generation (3) and penalization (4).(def:0)" << endl	
	<< "-g save_structure: whether the structures of each generation " << endl	      
	<< "       have to be saved or not.  (def:0)" << endl
	<< "-P part_time: work in parts, execute only until generation 'part_time'  " << endl	      
	<< "       and store partial population in file 'pop.out'. (def:0,no output)" << endl
	<< "-o output_file: name of output_file to store the results" << endl
	<< "       (optional parameter). (def:-)" << endl
	<< "-d log_file: name of log_file to store the log results" << endl
	<< "-t problem type: 'tsp','tsf','qap','fsp' or 'lop'"<< endl;
}

/*
 * Obtaint the execution parameters from the command line.
 */
bool GetParameters(int argc,char * argv[])
{
	char c;
    if(argc==1)
    {
    	usage(argv[0]);
        return false;
    }
    //#ifdef WIN32
	
	char** optarg;
	optarg = new char*[argc];
    while ((c = GetOption (argc, argv, "F:hN:S:f:e:o:P:x:d:t:w:",optarg)) != '\0')
    {
    	switch (c)
    	{
				
				
			case 'e': MAX_EVALUATIONS=atof(*optarg);
				break;
				
            case 'h' :  usage(argv[0]);
				return false;
				break;
								
            case 'x' :  SEED = atoi(*optarg);
				break;
				
            case 'o' :  strcpy(OUTPUTFILE, *optarg);
				//OUTPUTFILE=optarg;
				// open the output file
				if (OUTPUTFILE)
				{
					foutput.open(OUTPUTFILE);
					if (!foutput) {
						cerr << "Could not open file " << OUTPUTFILE << ". Ignoring this file." << endl;
						OUTPUTFILE[0]='\0';
					}
					foutput.close();
				}
				break;
			
			case 'w':  strcpy(DATA_FILE_NAME, *optarg);
				if (DATA_FILE_NAME){
					fdatafile.open(DATA_FILE_NAME);
					if (!fdatafile){
						cerr << "Could not open file " << DATA_FILE_NAME << ". Ignoring this file." << endl;
						DATA_FILE_NAME[0]='\0';
					}
					fdatafile.close();
				}
				break;
				
		}
	}
	
	delete [] optarg;

	return true;
}

/*
 * This method returns the corresponding evaluations number to the parameters n (jobs) and m (machines).
 * The evaluations are calculated from one execution of the AGA algorithm for each type of instance with the
 * stopping criteria of n*m*0.4 seconds.
 */
int GetEvaluationsNumber(int n, int m, int random_instance)
{
	switch (n) 
	{
		case 20:
			if(m==5)
				return 182224100;
			else if (m==10)
				return 224784800;
			else 
				return 256896400;
			break;
			
		case 50:
			if(m==5)
				return 220712150;
			else if (m==10)
				return 256208100;
			else
				return 275954150;
			break;
			
		case 100:
			if(m==5) 
				return 235879800;
			else if(m==10)
				return 266211000;
			else
				return 283040000;
			break;
			
		case 200:
			if (m==10)	
				return 272515500;
			else
				return 287728850;
			break;
			/** RANDOM INSTANCES EVALUATIONS **/
			
		case 250:
			if (m==10)
				return 267779100;
			else
				return 284574350;
			break;
			
		case 300:
			if (m==10)
				return 273847500;
			else
				return 284672900;
			break;
			
		case 350:
			if (m==10)
				return 278369000;
			else
				return 286225300;
			break;	
			
		case 400:
			if (m==10)
				return 275491800;
			else
				return 283913500;
			break;
			
		case 450:
			if (m==10)
				return 277455350;
			else
				return 269271450;
			break;
			/** END RANDOM INSTANCES EVALUATIONS **/
		case 500:
			return 260316750;
			break;
			
		default:
			return n*1000000;
			break;
	}
}
/*
 int GetEvaluationsNumber(int n, int m)
 {
 switch (n) 
 {
 case 20:
 if(m==5)
 return 53848817;
 else if (m==10)
 return 74116198;
 else 
 return 93686260;
 break;
 
 case 50:
 if(m==5)
 return 77099239;
 else if (m==10)
 return 93024141;
 else
 return 125070896;
 break;
 
 case 100:
 if(m==5) 
 return 85437521;
 else if(m==10)
 return 107822214;
 else
 return 157863726;
 break;
 
 case 200:
 if (m==10)
 return 165873259;
 else
 return 200442479;
 break;
 
 case 500:
 return 189896281;//divide the value with 10.
 break;
 
 default:
 return n*1000000;
 break;
 }
 }*/

/*
 * Prints in a given file 'length' integer elements of a given array.
 */
void PrintInFile(int* array, int length, string text, ofstream& file)
{
	file<<text;
	for (int i=0;i<length;i++){
		file<<array[i]<<" ";
	}
	file<<" "<<endl;
}

void WriteSolution()
{
	foutput.open(OUTPUTFILE);
    foutput
	<< "Evaluations: " << EVALUATIONS << endl
	<< "Convergence evaluation: "<<CONVERGENCE_EVALUATIONS<<endl
	<< "Total time: " << timer.TimeString() << endl
	<< "Best individual: " << BEST<<endl;
	foutput.close();
}

/*
 * Main function.
 */
int main(int argc, char* argv[])
{

	seed();
	gettimeofday(&start,NULL);
	
	if(!GetParameters(argc,argv)) return -1;
	
	if (GetProblemInfo(DATA_FILE_NAME) < 0) return -2;

	timer.Reset();
	cout<<"Instance to optimize: "<<DATA_FILE_NAME<<endl;

	PFSP * fsp=GetFlowshopProblem();
	cout<<"Building initial solution with LR(n/m) method..."<<endl;
	BEST=LRnm(IND_SIZE, GetFlowshopProblem());
	
	BEST_FITNESS=BEST->Value();
	cout<<"LR(n/m) solution: "<<BEST<<endl;	

	int max_seconds=fsp->JOB_NUM*fsp->MACHINE_NUM*0.4;
	MAX_EVALUATIONS=GetEvaluationsNumber(fsp->JOB_NUM,fsp->MACHINE_NUM,0);
	cout<<"Max evaluations: "<<MAX_EVALUATIONS<<endl;
	cout<<"Max execution seconds: "<<max_seconds<<endl;
	cout<<"Execution seed: "<<SEED<<endl;	
	cout<<"Starting VNS algorithm..."<<endl;
	BEST=VNS_4(GetFlowshopProblem(),BEST);	
	
	cout<<"New VNS solution: "<<BEST<<endl;
	
	timer.End();
	
	//Write solution in the output file.
	WriteSolution();
	
	RemoveProblemInfo();
	gettimeofday(&stop,NULL);
	return -BEST->Value();
}

