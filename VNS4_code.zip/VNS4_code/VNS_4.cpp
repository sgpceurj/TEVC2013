/*
 *  VNS_4.cpp
 *  MallowsEDA
 *
 *  Created by Josu Ceberio Uribe on 2/28/12.
 *  Copyright 2012 University of the Basque Country. All rights reserved.
 *
 */

#include "VNS_4.h"

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 * This algorithm is proposed in the paper "New VNS heuristic for total flowtime flowshop scheduling problem" Costa et al. 2011 Tech Report.
 */
CIndividual * VNS_4(PFSP * fsp, CIndividual *  individual)
{	
	//cout<<"in: "<<individual<<endl;
	int * current = new int[IND_SIZE];
	int * best = new int[IND_SIZE];
	memcpy(current, individual->Genes(), sizeof(int)*IND_SIZE);
	memcpy(best, current, sizeof(int)*IND_SIZE);
	int cost_opt= individual->Value();
	int cost_improve=cost_opt;
	int iter=0;
	do
	{
		bool condition=true;
		while (condition && EVALUATIONS<MAX_EVALUATIONS)
		{
			current=Job_Interchange_LS(fsp, current);
			condition = Reduced_JI(fsp, current); 
		}
		
		cost_improve=fsp->EvaluateFSPTotalFlowtime(current);

		//update best solution
		if (cost_improve<cost_opt)
		{
			//cout<<"cost: "<<cost_opt<<" current_flow "<<cost_improve<<endl;
			memcpy(best, current, sizeof(int)*IND_SIZE);
			cost_opt=cost_improve;
		}
		else 
		{
			memcpy(current, best, sizeof(int)*IND_SIZE);
		}
		cout<<"Iteration: "<<iter<<" fitness: "<<cost_opt<<endl;
		//exit(1);
		//shake
		Shake_Insert(current, 14);
		iter++;
	}
	while (EVALUATIONS<MAX_EVALUATIONS);

	individual->SetGenes(best);
	//cout<<"out: "<<individual<<endl;
	delete [] current;
	delete [] best;
	return individual;
}

int * Job_Interchange_LS (PFSP * fsp, int * current)
{
	bool condition=true;
	while (condition && EVALUATIONS<MAX_EVALUATIONS)
	{
		condition=Reduced_Interchange(fsp, current);
	}
	return current;
}

bool Reduced_Interchange(PFSP * fsp, int * individual)
{
	bool improve=false;
	int * current = new int[IND_SIZE];
	memcpy(current, individual,IND_SIZE*sizeof(int));
	int cost_opt = fsp->EvaluateFSPTotalFlowtime(current);
	
	for (int i=0;i<(IND_SIZE-1 && EVALUATIONS<MAX_EVALUATIONS);i++)
	{
		int cost_improve=Interchange(fsp, current, i);
		if (cost_improve<cost_opt)
		{
			//cout<<"cost: "<<cost_opt<<" current_flow "<<cost_improve<<endl;
			memcpy(individual, current, sizeof(int)*IND_SIZE);
			cost_opt=cost_improve;
			improve=true;//Update!!!! current vs individual!!!
		}
		else 
		{
			memcpy(current, individual, sizeof(int)*IND_SIZE);
		}
	}
	return improve;
}

int Interchange (PFSP * fsp, int * individual, int i)
{
	int * current = new int[IND_SIZE];
	memcpy(current, individual,IND_SIZE*sizeof(int));

	int cost_opt=fsp->EvaluateFSPTotalFlowtime(current);
	for (int j=i+1;(j<IND_SIZE && EVALUATIONS<MAX_EVALUATIONS);j++)
	{
		Swap(current,i,j);
		int cost_improve=fsp->EvaluateFSPTotalFlowtime(current);
		if (cost_improve<cost_opt)
		{
			cost_opt=cost_improve;
			memcpy(individual, current,IND_SIZE*sizeof(int));
			return cost_opt;
		}
		Swap(current,i,j);
	}
	delete [] current;
	return cost_opt;
}

bool Reduced_JI(PFSP * fsp, int * individual)
{
	bool improve=false;
	int * current = new int[IND_SIZE];
	memcpy(current, individual,IND_SIZE*sizeof(int));
	
	int cost_opt=fsp->EvaluateFSPTotalFlowtime(current);
	for (int i=0;(i<IND_SIZE && EVALUATIONS<MAX_EVALUATIONS);i++)
	{
		int cost_improve=Shift(fsp, current,i);
		if (cost_improve<cost_opt)
		{
		//	cout<<"cost: "<<cost_opt<<" current_flow "<<cost_improve<<endl;
			memcpy(individual, current, sizeof(int)*IND_SIZE);
			cost_opt=cost_improve;
			improve=true;//Update!!!! current vs individual!!!
		}
		else 
		{
			memcpy(current, individual, sizeof(int)*IND_SIZE);
		}
	}
	
	delete [] current;
	return improve;
	
}

int Shift (PFSP * fsp, int * individual, int i)
{
	int * current = new int[IND_SIZE];
	memcpy(current, individual,IND_SIZE*sizeof(int));
	int cost_opt=fsp->EvaluateFSPTotalFlowtime(current);
	int cost_improve=cost_opt;
	if (i!=0)
	{
		InsertAt(current, i, 0);
		cost_improve=fsp->EvaluateFSPTotalFlowtime(current);
		if (cost_improve<cost_opt)
		{
			memcpy(individual, current,IND_SIZE*sizeof(int));
			return cost_improve;
		}
	}
	
	for (int j=1;j<IND_SIZE;j++) 
	{
		if (j==i)
		{
			if (j==IND_SIZE)
			{
				return cost_opt;
			}
			Swap(current,j-1,j);
			//j++;
		}
		Swap(current, j-1, j);
		cost_improve=fsp->EvaluateFSPTotalFlowtime(current);
		if (cost_improve<cost_opt)
		{
			memcpy(individual, current,IND_SIZE*sizeof(int));
			return cost_improve;
		}
	}
	delete [] current;
	return cost_opt;
}

/*
 * It applies random shake_power times a perturbation over the given individual.
 */
void Shake_Insert(int *  individual, int shake_power)
{
	int i,j;
	for (int iter=0;iter<shake_power;iter++)
	{
		//permute randomly genes in position i and j to scape the stackeness in both neighborhood.
		i = rand() % IND_SIZE;
		j = rand() % IND_SIZE;
		individual= InsertAt(individual,i,j);
	}
}

/*
 * This method applies a swap of the given i,j positions in the array.
 */
int * Swap(int * array, int i, int j)
{
	int aux=array[i];
	array[i]=array[j];
	array[j]=aux;
	return array;
}


/*
 * This method moves the value in position i to the position j.
 */
int * InsertAt (int * array, int i, int j)
{	
	int res[IND_SIZE];
	int val=array[i];
	if (i!=j)
	{
		if (i<j)
		{
			memcpy(res,array,sizeof(int)*i);
			
			for (int k=i+1;k<=j;k++)
				res[k-1]=array[k];
			
			res[j]=val;
			
			for (int k=j+1;k<IND_SIZE;k++)
				res[k]=array[k];
		}
		else if (i>j)
		{
			memcpy(res,array,sizeof(int)*j);
			
			res[j]=array[i];
			
			for (int k=j;k<i;k++)
				res[k+1]=array[k];
			
			for (int k=i+1;k<IND_SIZE;k++)
				res[k]=array[k];
		}
		memcpy(array,res,sizeof(int)*IND_SIZE);
	}
	return array;
}



