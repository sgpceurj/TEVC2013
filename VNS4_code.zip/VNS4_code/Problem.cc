// Problem.cpp: implementation of the methods specific to the problem.
//


#include "Problem.h"
#include "NewVNS.h"


PFSP * m_flowshop_problem;

int GetFSPProblemInfo(string filename)
{
	int problemsize= m_flowshop_problem->ReadInstance(filename);
	
	//INITIALIZE INDIVIDUAL SIZE AND GENE VALUE RANGES
	IND_SIZE = problemsize;
		
	return (0);
}

int GetProblemInfo(string filename)
{
	m_flowshop_problem= new PFSP();
	int	result = GetFSPProblemInfo(filename);
	
	return result;
}

void RemoveProblemInfo()
{
	// The memory allocated in GetProblemInfo() is returned.

}

int Metric(int * genes, int size)
{
	int	value = m_flowshop_problem->EvaluateFSPTotalFlowtime(genes);
    return value;
}


PFSP * GetFlowshopProblem()
{
	return m_flowshop_problem;
}




