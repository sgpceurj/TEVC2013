/*
 *  VNS_4.h
 *  MallowsEDA
 *
 *  Created by Josu Ceberio Uribe on 2/28/12.
 *  Copyright 2012 University of the Basque Country. All rights reserved.
 *
 */
#include "Individual.h"
#include "PFSP.h"
//#include "PermutationTools.h"
#include "Tools.h"
#include "NewVNS.h"

CIndividual * VNS_4(PFSP * fsp, CIndividual *  individual);

int * Job_Interchange_LS (PFSP * fsp, int * current);

bool Reduced_Interchange(PFSP * fsp, int * current);

int Interchange (PFSP * fsp, int * individual, int i);

void Shake_Insert (int * individual, int shake_power);

bool Reduced_JI(PFSP * fsp, int * current);

int Shift (PFSP * fsp, int * individual, int i);

void Shake_Insert(int *  individual, int shake_power);

/*
 * This method applies a swap of the given i,j positions in the array.
 */
int * Swap(int * array, int i, int j);

/*
 * This method moves the value in position i to the position j.
 */
int * InsertAt (int * array, int i, int j);
