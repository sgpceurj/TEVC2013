/*
 *  Tools.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 9/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */
#include <string.h>
#include <sstream>
#include <fstream>
#include <iostream>
#include "Population.h"
#include <stdlib.h>
#include <stdio.h>

using std::stringstream;
using std::string;


/*
 * It determines if the given int sequecen if it is indeed a permutation or not.
 */
bool isPermutation(int * permutation, int size);

void vVector(int*v, int*permutation, int n);

/*
 * Inverts a permutation.
 */
void Invert(int*permu, int n, int* inverted);

/*
 * Inverts a permutation.
 */
int* Invert(int*permu, int n);

void Compose(int*s1, int*s2, int*res, int n);

void GeneratePermuFromV(int*v,int*permu,int n);

void GenerateRandomPermutation(int size, int * permutation);

int Evaluate(int * array, int size);

void GenerateRandomPopulation(CPopulation * population, int samplesNum, int size);

//Calculates the mean fitness of those individuals that the job 'job' is located in the position 'pos' in the processing sequence
double AverageJobPositionIndividuals(int job, int position, CPopulation * cases, int ProblemSize, int samplesNum);

//Calculates the mean fitness of those individuals that the job 'job' is located in the position 'pos' in the processing sequence
double AverageJobJobIndividuals(int job_j, int job_l, CPopulation * cases, int ProblemSize, int samplesNum);

void CalculateInstanceVarianceMatrix_JobPosition(double** indexVariance, double** positionVariance, int size, int samplesNum);

void CalculateFrecuencyMatrix(int** FrecuencyMatrix, CPopulation * cases, int ProblemSize, int samplesNum);

void AnalyzeInstance_JobPosition(int * jobs, int * positions, int samples);

void AnalyzeInstance_JobPosition(double * jobsDistribution, int samples, bool invert);
