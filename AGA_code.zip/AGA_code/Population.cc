// Population.cpp: implementation of the CPopulation class.
//
#include "Population.h"
#include "SortingTools.h"
#include "PermutationTools.h"
using std::istream;
using std::ostream;

using std::cerr;
using std::cout;
using std::endl;


CPopulation::CPopulation(): m_individual(NULL), m_next(NULL), m_prev(NULL)
{
	// m_next will be the head of the list and
	// m_prev the tail.
	m_num_individuals=0;
		
}

CPopulation::~CPopulation()
{
//	if(m_next!=NULL) 
//		delete m_next;
}


POSITION CPopulation::GetHeadPosition()
{
	return m_next;
}

void CPopulation::RemoveTail()
{
	// If the list is empty the function will fail.
	if(m_next==m_prev)
	{
		// There is only one individual in the list.
		delete m_prev->m_individual;
		delete m_prev;
		m_next = NULL;
		m_prev = NULL;
	}
	else
	{
		// Delete the node at the tail and update the links.
		
		CPopulation * last_but_one = m_prev->m_prev;
		delete last_but_one->m_next->m_individual;
		delete last_but_one->m_next;
		last_but_one->m_next = NULL;
		m_prev = last_but_one;
	}
	m_num_individuals--;
}


void CPopulation::RemoveHead()
{
	
	// If the list is empty the function will fail.
	if(m_next==m_prev)
	{
		// There is only one individual in the list.
		delete m_prev->m_individual;
		delete m_prev;
		m_next = NULL;
		m_prev = NULL;

	}
	else
	{
		//m_next->Print();
		//cout<<"removing first position: "<<endl;
		// Delete the node at the tail and update the links.
		CPopulation * all_but_first= m_next->m_next;
		m_next=all_but_first;
		delete all_but_first->m_prev->m_individual;
		delete all_but_first->m_prev;
		all_but_first->m_prev=NULL;

		//m_next->Print();
		
		
		/*
		m_next=all_but_first;
		delete m_next->m_prev->m_individual;
		delete m_next->m_prev;
*/

	}
	m_num_individuals--;
}

void CPopulation::RemoveAt(POSITION pos)
{
	//cout<<"Removing.."<<endl;
	// If the list is empty the function will fail.
	if(m_next==m_prev)
	{
		// There is only one individual in the list.
		delete m_prev->m_individual;
		delete m_prev;
		m_next = NULL;
		m_prev = NULL;
		m_num_individuals--;
	}
	else
	{
		if (pos->m_prev==NULL)
		{
		//cout<<"Remove head"<<endl;
			//remove head.
			RemoveHead();
		//	cout<<"after remove head"<<endl;
		}
		else if (pos->m_next==NULL)
		{
//			cout<<"Remove tail"<<endl;
			//remove tail.
			RemoveTail();
		}
		else
		{	
			
			pos->m_prev->m_next=pos->m_next;
			pos->m_next->m_prev=pos->m_prev;
			pos->m_next=NULL;
			pos->m_prev=NULL;
			delete pos->m_individual;
			delete pos;
			m_num_individuals--;
		}
	}
//	cout<<"After Removing.."<<endl;
}
	
void CPopulation::RemoveAll()
{
	while (m_num_individuals!=0) 
	{
		//cout<<m_num_individuals<<endl;
		RemoveTail();
	}
}
POSITION CPopulation::GetNext(POSITION pos)
{
	if(pos==NULL) return NULL;
	else return pos->m_next;
}

CIndividual * & CPopulation::GetAt(POSITION pos)
{
	// If pos is NULL the function will fail.

	return pos->m_individual;
}

CIndividual * & CPopulation::GetHead()
{
	// If the list is empty  the function will fail.

	return m_next->m_individual;
}

CIndividual * & CPopulation::GetTail()
{
	// If the list is empty the function will fail.

	return m_prev->m_individual;
}

void CPopulation::AddTail(CIndividual *individual)
{
	if(m_next==NULL)
	{
		// The list is empty.
		m_prev = new CPopulation;
		m_prev->m_individual = individual;
		
		m_next = m_prev;
	}
	else
	{
		m_prev->m_next = new CPopulation;
		m_prev->m_next->m_prev = m_prev;
		m_prev = m_prev->m_next;
		m_prev->m_individual = individual;
	}
}

void CPopulation::InsertBefore(POSITION pos, CIndividual *individual)
{
	if(pos==NULL) return; // No position to insert.
	else if(m_next==pos)
	{
		// Insert at the head of the list.
		
		m_next->m_prev = new CPopulation;
		m_next = m_next->m_prev;////OJOOOORRRR!!!
		m_next->m_next = pos;
		m_next->m_individual = individual;
		
	}
	else
	{
		POSITION aux = pos->m_prev;
		
		aux->m_next = new CPopulation;
		aux->m_next->m_individual = individual;
		aux->m_next->m_prev = aux;
		aux->m_next->m_next = pos;
		
		pos->m_prev = aux->m_next;
	}
}

void CPopulation::AddToPopulation(CIndividual * individual)
{
	POSITION pos;
	for(pos=GetHeadPosition(); pos!=NULL && individual->Value() < GetAt(pos)->Value(); pos = GetNext(pos));
	if(pos==NULL)
	{
		AddTail(individual);
	}
	else
	{
		InsertBefore(pos,individual);
	}
	m_num_individuals++;
}

ostream & operator<<(ostream & os,CPopulation & population)
{
  POSITION pos;
  os  << " pop.size: " << POP_SIZE << " indiv.length: " << IND_SIZE <<  std::endl;
  for(pos = population.GetHeadPosition(); pos!=NULL; pos = population.GetNext(pos))
		os << population.GetAt(pos) << std::endl;
  return os;
}

istream & operator>>(istream & is,CPopulation & population)
{
  char TEXT[50]; //To avoid unwanted characters  , str2[15];
  is >> TEXT >> POP_SIZE >> TEXT >> IND_SIZE;      
  for(int i=0; i<POP_SIZE; i++)
  {
    CIndividual * individual = new CIndividual(IND_SIZE);
    is >> individual;
    population.AddToPopulation(individual);
  }
  return is;
}


/*
 * Prints in standard output 'length' integer elements of a given array.
 */
void CPopulation::PrintArray(int* array, int length, string text)
{
	cout<<text;
	for (int i=0;i<length;i++){
		cout<<array[i]<<" ";
	}
	cout<<" "<<endl;
}


bool CPopulation::isEmpty()
{
	if (m_num_individuals==0)return true;
	else return false;
}

void CPopulation::Print()
{
	POSITION pos;
	for(pos = GetHeadPosition(); pos!=NULL; pos = GetNext(pos))
		cout << GetAt(pos) << std::endl;
}

bool CPopulation::Same()
{
	int best=GetHead()->Value();
	POSITION pos;	
	for(pos = GetHeadPosition(); pos!=NULL; pos = GetNext(pos))
	{
		if (GetAt(pos)->Value()!=best)
			return false;
	}
	return true;
}

CIndividual * CPopulation::RandomExtract()
{
	/* generate secret number: */
	int num = rand() % m_num_individuals;
	//cout<<"random position: "<<num<<" from "<<m_num_individuals<<endl;
	//if (num==0)
	//	Print();
	//cout<<"despues: "<<endl;
	POSITION pos=GetHeadPosition();
	for (int i = 0; i < num; i++)
	{
		pos= GetNext(pos);
	}
	CIndividual * ind=GetAt(pos)->Clone();
	//if (num==0)
	//	cout<<ind<<endl;
	//cout<<"position : "<<num<<endl;

	RemoveAt(pos);
	
	return ind;
}



