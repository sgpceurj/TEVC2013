/*
 *  Variables.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

//Integer maximum value
#define MAX_INTEGER 100000000
#define MIN_INTEGER -100000000
#define INT_MAX 100000000
#define INT_MIN -100000000
//Long integer maximum value
#define MAX_LONG_INTEGER 4294967295

//Every how many generations do we have to print the information
#define GENERATIONSPRINTRESULT 1


//determines whether stopping criteria is determined by the n*m*0.4 seconds.
//#define TIME_CRITERIA 0