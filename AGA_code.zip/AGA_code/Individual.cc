// Individual.cpp: implementation of the CIndividual class.
//

#include "Individual.h"
#include "Problem.h"
#include "AGA.h"
#include "Variables.h"
#include <limits.h>

// The object storing the values of all the individuals
// that have been created during the execution of the
// program. 

CIndividual::CIndividual(int length): m_value(INT_MIN)
{
	m_size = length;
	m_genes = new int[m_size];
}

CIndividual::~CIndividual()
{
	delete [] m_genes;
	m_genes=NULL;
}


int CIndividual::Value()
{
	// The INT_MIN value indicates that the value of
	// the individual has not been calculated yet. In
	// that case it is calculated and stored before
	// it is returned.
	if(m_value==INT_MIN)
	{
		m_value=Metric(m_genes, m_size);
		
		//if ((-m_value)<BEST_FITNESS)
		//{
		//	BEST_FITNESS=-m_value;
		//	CONVERGENCE_ITERATION=GENERATIONS;
		//	CONVERGENCE_EVALUATIONS=EVALUATIONS;
		//}
		
	}


	return m_value;
}


int * CIndividual::Genes()
{
	return m_genes;
}

ostream & operator<<(ostream & os,CIndividual * & individual)
{
	os << individual->Value() << ",";

        os << individual->m_genes[0];
	for(int i=1;i<individual->m_size;i++)
		os << "," << individual->m_genes[i];
        os << ".";

	return os;
}

istream & operator>>(istream & is,CIndividual * & individual)
{
  char k; //to avoid intermediate characters such as ,.

  is >> individual->m_value;
  is >> individual->m_genes[0];
  for(int i=1;i<individual->m_size;i++)
    is >> k >> individual->m_genes[i];
  is >> k;

  return is;
}

void CIndividual::SetValue(int metrica)
{
	m_value=metrica;
}

void CIndividual::SetGenes(int * genes)
{
	memcpy(m_genes, genes, sizeof(int)*m_size);
	m_value=INT_MIN;
}

/*
 * Prints in the standard output genes.
 */
void CIndividual::PrintGenes()
{
	for (int i=0;i<m_size;i++){
		cout<<m_genes[i]<<" ";
	}
	cout<<" "<<endl;
}

CIndividual * CIndividual::Clone()
{
	CIndividual * ind = new CIndividual(m_size);
	ind->SetGenes(m_genes);
	ind->SetValue(m_value);
	return ind;
}



