/*
 *  Tools.cpp
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 9/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */
#include "PermutationTools.h"
#include "Tools.h"
#include "SortingTools.h"
#include "Problem.h"
#include <string.h>
#include <sstream>
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>

using std::stringstream;
using std::string;
using std::cerr;
using std::cout;
using std::endl;

bool isPermutation(int * permutation, int size)
{
	int * flags=new int[size];
	for (int i=0;i<size;i++) flags[i]=1;
	
	for (int i=0;i<size;i++)
	{
		int value=permutation[i];
		flags[value]=0;
	}
	
	int result,sum=0;
	for(int i=0;i<size;i++)
		sum+=flags[i];
	if (sum==0) result=true;
	else result=false;
	delete [] flags;
	return result;
}

/*
 * Generates a permutation from a v vector.
 */
void GeneratePermuFromV(int*v,int*permu,int n)
{
	int at;
	permu[0]=n-1;
	for (int j=n-2;j>=0;j--)
	{
		at=v[j];
		InsertAt(permu,j,at,n);
	}
}

/*
 *	Calculates V_j-s vector.
 */
void vVector(int*v, int*permutation, int n)
{
	for(int i=0;i<n-1;i++)
		v[i]=0;
	
	for (int i = n-2; i >= 0; i--)
		for (int j = i+1; j < n; j++)
			if(permutation[i] > permutation[j])
				v[i]++;
}

/*
 * Inverts a permutation.
 */
void Invert(int*permu, int n, int* inverted)
{
	for(int i=0; i<n; i++) inverted[permu[i]]=i;
}

/*
 * Inverts a permutation.
 */
int* Invert(int*permu, int n)
{
	int*pinv=new int[n];
	for(int i=0; i<n; i++) 
		pinv[permu[i]]=i;
	return pinv;
}


/*
 * Implements the compose of 2 permutations of size n.
 */
void Compose(int*s1, int*s2, int*res, int n)
{
	for(int i=0;i<n;i++)
		res[i]=s1[s2[i]];
}

void GenerateRandomPermutation(int n, int * permutation) 
{
	for (int i = 0; i < n; ++i) 
	{
		int j = rand() % (i + 1);
		permutation[i] = permutation[j];
		permutation[j] = i;
	}
}

int Evaluate(int * array, int size)
{
	int* g= new int[size];
	Invert(array,size,g);
	int objective_value=Metric(g, IND_SIZE);
	delete[] g;
	
	return objective_value;
}

void GenerateRandomPopulation(CPopulation * population, int samplesNum, int size)
{
	for (int i=0;i<samplesNum;i++)
	{
		cout<<i<<endl;
		int* permutation= new int[size];
		GenerateRandomPermutation(size,permutation);
		
		CIndividual * individual= new CIndividual(IND_SIZE);
		individual->SetGenes(permutation);
		population->AddToPopulation(individual);
	}
}


double** CalculateInstanceFitnessAverage_JobPosition(int size, int samplesNum)
{	
	CPopulation * sample= new CPopulation();
	GenerateRandomPopulation(sample, samplesNum, size);
	
	//calculate fitness average matrix.
	double **AverageMatrix= new double *[size];
	for (int i=0;i<size;i++){
		AverageMatrix[i]=new double[size];
		for (int j=0;j<size;j++)
			AverageMatrix[i][j]=0;
	}
	
	for (int job=0;job<size;job++)
	{
		for (int position=0;position<size;position++)
		{
			AverageMatrix[job][position]=AverageJobPositionIndividuals(job,position, sample, size, samplesNum);
		}
	}
	return AverageMatrix;
}

double** CalculateInstanceFitnessAverage_JobJob(int size, int samplesNum)
{	
	CPopulation * sample= new CPopulation();
	GenerateRandomPopulation(sample, samplesNum, size);
	
	//calculate fitness average matrix.
	double **AverageMatrix= new double *[size];
	for (int i=0;i<size;i++){
		AverageMatrix[i]=new double[size];
		for (int j=0;j<size;j++)
			AverageMatrix[i][j]=0;
	}
	
	for (int job_j=0;job_j<size;job_j++)
	{
		for (int job_l=0;job_l<size;job_l++)
		{
			AverageMatrix[job_j][job_l]=AverageJobJobIndividuals(job_j,job_l, sample, size, samplesNum);
		}
	}
	return AverageMatrix;
}


void CalculateFrecuencyMatrix(int** FrecuencyMatrix, CPopulation * cases, int ProblemSize, int samplesNum)
{
	//Initialize matrix to zeros.
	for (int i=0;i<ProblemSize;i++){
		FrecuencyMatrix[i]=new int[ProblemSize];
		for (int j=0;j<ProblemSize;j++)
			FrecuencyMatrix[i][j]=0;
	}
	
	//cout<<"Filling frecuency matrix"<<endl;
	//Fill frecuency matrix reviewing individuals in the population.
	//para cada permutación muestreada:
	POSITION pos=cases->GetHeadPosition();
	for (int i = 0; i < samplesNum; i++)
	{
		CIndividual * ind= cases->GetAt(pos);
		pos= cases->GetNext(pos);
		int* individua = ind->Genes();
		for (int j=0;j<ProblemSize;j++)
		{
			int geneValue=j;
			int genePosition=individua[j];
			FrecuencyMatrix[genePosition][geneValue]++;
		}
	}
}

void CalculateInstanceVarianceMatrix(double** indexVariance, double** positionVariance, int size, int samplesNum)
{	
	CPopulation * sample= new CPopulation();
	for (int i=0;i<samplesNum;i++)
	{
		cout<<i<<endl;
		//generate 100 000 random individuals population
		int* permutation= new int[size];
		GenerateRandomPermutation(size,permutation);
		
		CIndividual * individual= new CIndividual(IND_SIZE);
		individual->SetGenes(permutation);
		sample->AddToPopulation(individual);
	}
	
	int **FrecuencyMatrix= new int*[size];
	CalculateFrecuencyMatrix(FrecuencyMatrix, sample, size, (int)(samplesNum*0.01));
	
	double * positionVariances= new double[size];
	for (int i=0;i<size;i++)
		positionVariances[i]=Variance(FrecuencyMatrix[i],size);
	
}


double AverageJobPositionIndividuals(int job, int position, CPopulation * cases, int ProblemSize, int samplesNum)
{
	POSITION pos=cases->GetHeadPosition();
	double sum=0;
	double num=0;
	for (int i = 0; i < samplesNum; i++)
	{
		CIndividual * ind= cases->GetAt(pos);
		pos= cases->GetNext(pos);
		int* individua = ind->Genes();
		if (individua[job]==position) 
		{
			//cout<<ind<<endl;
			sum=sum + (-ind->Value());
			num++;
		}
	}
	return sum/num;
}

double AverageJobJobIndividuals(int job_j, int job_l, CPopulation * cases, int ProblemSize, int samplesNum)
{
	POSITION pos=cases->GetHeadPosition();
	double sum=0;
	double num=0;
	for (int i = 0; i < samplesNum; i++)
	{
		CIndividual * ind= cases->GetAt(pos);
		pos= cases->GetNext(pos);
		int* individua = ind->Genes();
		int position=individua[job_j];
		if (individua[job_l]==(position+1)) 
		{
			//cout<<ind<<endl;
			sum=sum + (-ind->Value());
			num++;
		}
	}
	return sum/num;
}

void AnalyzeInstance_JobPosition(int * jobs, int * positions, int samples)
{
	int i;
	
	//1.- Calculate averages matrix
	double ** averageMatrix=CalculateInstanceFitnessAverage_JobPosition(IND_SIZE,samples);
	
	//2.- Calculate variances	
	double * jobVariances= new double[IND_SIZE];
	double * positionVariances= new double[IND_SIZE];
	double ** transposed=TransposeMatrix(averageMatrix,IND_SIZE);
	
	for (i=0;i<IND_SIZE;i++)
	{
		//2.1.- Calculate jobs variance
		jobVariances[i]=Variance(averageMatrix[i],IND_SIZE);
		jobs[i]=i;
		
		//2.2.- Calculate positions variance		
		positionVariances[i]=Variance(transposed[i],IND_SIZE);
		positions[i]=i;
	}
	
	//3.- Sort jobs and positions regarding the variance
	PrintArrayDouble(jobVariances,IND_SIZE,"Job variances: ");
	QuickSort(jobs, jobVariances, 0, IND_SIZE-1, DESCENDING);
	QuickSort(positions, positionVariances, 0, IND_SIZE-1, DESCENDING);
	
	//5.-delete structures
	for (i=0;i<IND_SIZE;i++){
		delete [] transposed[i];
		delete [] averageMatrix[i];
	}
	delete[] jobVariances;
	delete[] positionVariances;
	delete[] averageMatrix;
	delete[] transposed;
}

void AnalyzeInstance_JobPosition(double * jobsDistribution, int samples, bool invert)
{
	int i;
	
	//1.- Calculate averages matrix
	double** averageMatrix=CalculateInstanceFitnessAverage_JobPosition(IND_SIZE,samples);
	
	//2.- Calculate variances	
	double * jobVariances= new double[IND_SIZE];
	double * positionVariances= new double[IND_SIZE];
	double** transposed=TransposeMatrix(averageMatrix,IND_SIZE);
	double totalJobsVariance=0;
	for (i=0;i<IND_SIZE;i++)
	{
		//2.1.- Calculate jobs variance
		jobVariances[i]=Variance(averageMatrix[i],IND_SIZE);
		totalJobsVariance+=jobVariances[i];
		
		//2.2.- Calculate positions variance		
		positionVariances[i]=Variance(transposed[i],IND_SIZE);
		
	}
	
	//4.- Normalize job variances to generate a probability distribution. Higher variance jobs, higher probability are assigned
	for (i=0;i<IND_SIZE;i++) jobsDistribution[i] = jobVariances[i] / totalJobsVariance;
	PrintArrayDouble(jobsDistribution,IND_SIZE,"Jobs PD: ");
	if (invert)
	{
		//4.1- Invert the probability distribution to assign higher probability to those jobs with lower variance
		double total=0;
		for (i=0;i<IND_SIZE;i++) 
		{
			jobsDistribution[i] = 1 /jobsDistribution[i];
			total+=jobsDistribution[i];
		}
		//Normalize
		for (i=0;i<IND_SIZE;i++) jobsDistribution[i] = jobsDistribution[i] / total;
	}
	PrintArrayDouble(jobsDistribution,IND_SIZE,"Jobs inverted PD: ");	
	
	
	//5.-delete structures
	for (i=0;i<IND_SIZE;i++){
		delete [] transposed[i];
		delete [] averageMatrix[i];
	}
	delete[] jobVariances;
	delete[] positionVariances;
	delete[] averageMatrix;
	delete[] transposed;
}


