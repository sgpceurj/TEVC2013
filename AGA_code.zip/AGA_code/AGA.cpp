
#include <stdlib.h>
#include <sys/time.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
using std::istream;
using std::ostream;
using namespace std;
#define itoa(a,b,c) sprintf(b, "%d",a)
#include "string.h"
#include "Variables.h"
#include "Timer.h"
#include "Problem.h"
#include "Population.h"
#include "LocalSearch.h"
#include "PermutationTools.h"
#include "Tools.h"
#include "LR.h"

timeval start,stop;

//Mis variables
int POP_SIZE=40;
int MIN_LOCAL=10;
int MAX_LOCAL=60;
int POWER=50;
int IND_SIZE;
double EVALUATIONS = 0;
double CONVERGENCE_EVALUATIONS = 0;
double MAX_EVALUATIONS = 0;
int MAX_SECONDS=100;
static CPopulation * population= new CPopulation();
int BEST_FITNESS=INT_MAX;
CTimer timer;
int MAX_GENERATIONS=30;
int GENERATIONS=0;
int CONVERGENCE_ITERATION=0;
char OUTPUTFILE[50];
char LOGFILE[50];
ofstream foutput;
ofstream flog;
ifstream fdatafile;

char DATA_FILE_NAME[50];
int SEED;


/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
	
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
	
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
		
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
			
            if (isalnum(chOpt) || ispunct(chOpt))
            {	
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
				
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
							
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
	
    iArg++;
	
    *ppszParam = pszParam;
    return (chOpt);
}

bool GetParameters(int argc,char * argv[])
{
	char c;

	char** optarg;
	optarg = new char*[argc];
    while ((c = GetOption (argc, argv, ":o:x:d:w:e:",optarg)) != '\0')
    {
    	switch (c)
    	{
				
			case 'e': MAX_EVALUATIONS=atof(*optarg);
				break;
				
            case 'x' :  SEED = atoi(*optarg);
				break;
				
            case 'o' :  strcpy(OUTPUTFILE, *optarg);
				//OUTPUTFILE=optarg;
				// open the output file
				if (OUTPUTFILE)
				{
					foutput.open(OUTPUTFILE);
					if (!foutput)
					{
						cerr << "Could not open file " << OUTPUTFILE << ". Ignoring this file." << endl;
						OUTPUTFILE[0]='\0';
					}
					foutput.close();
				}
				break;
				
			case 'd' :  strcpy(LOGFILE, *optarg);
				//LOGFILE=optarg;
				// open the log file
				/*if (LOGFILE)
				{
					flog.open(LOGFILE);
					if (!flog) {
						cerr << "Could not open file " << LOGFILE << ". Ignoring this file." << endl;
						LOGFILE[0]='\0';
					}
					flog.close();
				}*/
				break;
				
			case 'w':  strcpy(DATA_FILE_NAME, *optarg);
				if (DATA_FILE_NAME)
				{
					fdatafile.open(DATA_FILE_NAME);
					if (!fdatafile){
						cerr << "Could not open file " << DATA_FILE_NAME << ". Ignoring this file." << endl;
						DATA_FILE_NAME[0]='\0';
					}
					fdatafile.close();
				}
				break;
		}
	}
	
	delete [] optarg;
		
	return true;
}

/*
 * This method implements a twice two point crossover proposed in the paper of the AGA algorithm.
 */
void TTP_Crossover(int * father, int * mother, int * son, int * daughter)
{
	int aux;
	//PrintArray(father,IND_SIZE,"in father TTP: ");
	//PrintArray(mother,IND_SIZE,"in mother TTP: ");

	//Auxiliary structures.
	int mother_aux[IND_SIZE];
	int father_aux[IND_SIZE];
	for (int i=0;i<IND_SIZE;i++)
	{
		mother_aux[i]=1;
		father_aux[i]=1;
	}
			   
	//first crossover
	int p1 = rand() % (IND_SIZE);
    int p2 = rand() % (IND_SIZE);
	if (p1>p2)
	{
		aux=p1;
		p1=p2;
		p2=aux;
	}
	
	//cout<<"Crossover points: "<<p1<<" "<<p2<<endl;
	//block from father
	for (int i=p1;i<=p2;i++){
		son[i]=father[i];
		mother_aux[father[i]]=0;
	}
	//PrintArray(mother_aux , IND_SIZE, "Aux data: ");
	//remaining from mother
	//first section
	//cout<<"first section"<<endl;
	int z=0;
	for (int j=0;j<p1;j++)
	{
		if (mother_aux[mother[z]]==1)
		{
			son[j]=mother[z];
			mother_aux[mother[z]]=0;
		}
		else
			j--;
		z++;
	}
	//PrintArray(son,IND_SIZE,"middle: ");
	//PrintArray(mother_aux , IND_SIZE, "Aux data in the middle: ");
	//cout<<"second section"<<endl;
	//second section
	for (int j=p2+1;j<IND_SIZE;j++)
	{
	//	cout<<"next mother value "<<mother[z];
		if (mother_aux[mother[z]]==1)
		{
	//		cout<<" is free"<<endl;
			son[j]=mother[z];
			mother_aux[mother[z]]=0;
	//		PrintArray(son,IND_SIZE,"ins middle: ");
	//		PrintArray(mother_aux , IND_SIZE, "ins Aux data in the middle: ");
		}
		else{
	//		cout<<" is NOT free"<<endl;
			j--;}
		z++;
	}
	//PrintArray(son,IND_SIZE,"out son TTP: ");
	//exit(1);

	//second crossover
	int p3 = rand() % (IND_SIZE);
    int p4 = rand() % (IND_SIZE);
	if (p3>p4)
	{
		aux=p3;
		p3=p4;
		p4=aux;
	}
	//cout<<"Crossover points: "<<p3<<" "<<p4<<endl;
	//block from mother
	for (int i=p3;i<=p4;i++){
		daughter[i]=mother[i];
		father_aux[mother[i]]=0;
	}
	//remaining from father
	//first section
	z=0;
	for (int j=0;j<p3;j++)
	{
		if (father_aux[father[z]]==1)
		{
			daughter[j]=father[z];
			father_aux[father[z]]=0;
		}
		else
			j--;
		z++;
	}
	//second section
	for (int j=p4+1;j<IND_SIZE;j++)
	{
		if (father_aux[father[z]]==1)
		{
			daughter[j]=father[z];
			father_aux[father[z]]=0;
		}
		else
			j--;
		z++;
	}
	
	//PrintArray(daughter,IND_SIZE,"out daughter TTP: ");
	
}

void WriteSolution(CIndividual * best, CTimer timer)
{
	cout<<OUTPUTFILE<<endl;
	foutput.open(OUTPUTFILE);
	
	foutput
	<< "Population size: " << POP_SIZE << endl
	<< "Generation: " << MAX_GENERATIONS << endl
	<< "Convergence generation: "<<CONVERGENCE_ITERATION<<endl
	<< "Evaluations: " << EVALUATIONS << endl
	<< "Convergence evaluation: "<<CONVERGENCE_EVALUATIONS<<endl
	<< "Total time: " << timer.Time() << endl
	<< "Best individual: " << best<<endl;
	
	foutput.close();
	
	
	cout << "Population size: " << POP_SIZE << endl
	<< "Generation: " << MAX_GENERATIONS << endl
	<< "Convergence generation: "<<CONVERGENCE_ITERATION<<endl
	<< "Evaluations: " << EVALUATIONS << endl
	<< "Convergence evaluation: "<<CONVERGENCE_EVALUATIONS<<endl
	<< "Total time: " << timer.Time() << endl
	<< "Best individual: " << best <<endl;
}

/*
 * This method returns the corresponding evaluations number to the parameters n (jobs) and m (machines).
 * The evaluations are calculated from one execution of the AGA algorithm for each type of instance with the
 * stopping criteria of n*m*0.4 seconds.
 */
int GetEvaluationsNumber(int n, int m, int random_instance)
{
	switch (n) 
	{
		case 20:
			if(m==5)
				return 182224100;
			else if (m==10)
				return 224784800;
			else 
				return 256896400;
			break;
			
		case 50:
			if(m==5)
				return 220712150;
			else if (m==10)
				return 256208100;
			else
				return 275954150;
			break;
			
		case 100:
			if(m==5) 
				return 235879800;
			else if(m==10)
				return 266211000;
			else
				return 283040000;
			break;
			
		case 200:
			if (m==10)	
				return 272515500;
			else
				return 287728850;
			break;
			/** RANDOM INSTANCES EVALUATIONS **/
			
		case 250:
			if (m==10)
				return 267779100;
			else
				return 284574350;
			break;
			
		case 300:
			if (m==10)
				return 273847500;
			else
				return 284672900;
			break;
			
		case 350:
			if (m==10)
				return 278369000;
			else
				return 286225300;
			break;	
			
		case 400:
			if (m==10)
				return 275491800;
			else
				return 283913500;
			break;
			
		case 450:
			if (m==10)
				return 277455350;
			else
				return 269271450;
			break;
			/** END RANDOM INSTANCES EVALUATIONS **/
		case 500:
			return 260316750;
			break;
			
		default:
			return n*1000000;
			break;
	}
}
/*
 int GetEvaluationsNumber(int n, int m)
 {
 switch (n) 
 {
 case 20:
 if(m==5)
 return 53848817;
 else if (m==10)
 return 74116198;
			else 
				return 93686260;
			break;
			
		case 50:
			if(m==5)
				return 77099239;
			else if (m==10)
				return 93024141;
			else
				return 125070896;
			break;
			
		case 100:
			if(m==5) 
				return 85437521;
			else if(m==10)
				return 107822214;
			else
				return 157863726;
			break;
			
		case 200:
			if (m==10)
				return 165873259;
			else
				return 200442479;
			break;
			
		case 500:
			return 189896281;//divide the value with 10.
			break;
			
		default:
			return n*1000000;
			break;
	}
}*/

int main (int argc, char * argv[])
{
    cout<<"Asynchronus Genetic Algorithm running...."<<endl;
	
	// Initialize random seed.
	srand ( time(NULL)+SEED );
	//srand(SEED);
	// Get parameters of the execution
	if(!GetParameters(argc,argv)) return -1;
	
	// Read problem instance.
	if (GetProblemInfo(DATA_FILE_NAME) < 0) return -2;
	
	// Open flogfile
	//flog.open(LOGFILE);
	
	timer.Reset();
	
	//Initialize Population
	cout<<"Initializing population...."<<endl;

	CPopulation * offspring= new CPopulation();
	
	for(int i=0;i<POP_SIZE-1;i++)
	{
		//Create random individual
		int* permutation= new int[IND_SIZE];
		GenerateRandomPermutation(IND_SIZE,permutation);
		CIndividual * individual= new CIndividual(IND_SIZE);
		individual->SetGenes(permutation);
		population->AddToPopulation(individual);
		delete [] permutation;
	}	
	
	cout<<"Constructing individual with LR(n/m)...."<<endl;
	//Create an individual with the constructive method of Liu and Reeves.
	CIndividual * individualConstructive = LRnm(IND_SIZE,GetFlowshopProblem());
	population->AddToPopulation(individualConstructive);
	cout<<"built: "<<individualConstructive<<endl;
	
	PFSP * fsp=GetFlowshopProblem();
	MAX_SECONDS=fsp->JOB_NUM*fsp->MACHINE_NUM*0.4;
	int x1,x2;
	CIndividual * best_individual=population->GetHead()->Clone();
	BEST_FITNESS=-best_individual->Value();

	MAX_EVALUATIONS= GetEvaluationsNumber(fsp->JOB_NUM,fsp->MACHINE_NUM,0);

	//Start AGA optimization

	cout<<"Starting evolutionary process..."<<endl;
	cout<<"MAX GENERATIONS: "<<MAX_GENERATIONS<<endl;
	cout<<"MAX SECONDS: "<<MAX_SECONDS<<endl;
	cout<<"MAX EVALUATIONS: "<<MAX_EVALUATIONS<<endl;
	
	CIndividual * father;
	CIndividual * mother;
	CIndividual * son;
	CIndividual * daughter;
	#ifdef TIME_CRITERIA
	for (; timer.Time()<MAX_SECONDS; GENERATIONS++)
	#else
	for (;EVALUATIONS<MAX_EVALUATIONS; GENERATIONS++)
	#endif
		{
		cout<<"GENERATIONS: "<<GENERATIONS<<" EVALUATIONS: "<<EVALUATIONS<<" TIME: "<<timer.Time()<<" "<<BEST_FITNESS<<endl;
		offspring= new CPopulation();
		
		#ifdef TIME_CRITERIA
		while(!population->isEmpty() && timer.Time()<MAX_SECONDS)
		#else
		while(!population->isEmpty() && EVALUATIONS<MAX_EVALUATIONS)
		#endif
		{
			//cout<<"barruan: "<<population->m_num_individuals<<endl;
			father= population->RandomExtract();
			mother= population->RandomExtract();
			
			x1 = rand() % (MAX_LOCAL-MIN_LOCAL) + MIN_LOCAL;
			x2 = rand() % (MAX_LOCAL-MIN_LOCAL) + MIN_LOCAL;
			
			father=eVNS(father,POWER,x1,fsp);
			mother=eVNS(mother,POWER,x2,fsp);
			
			//cout<<"VNS father: "<<father<<endl;
			//cout<<"VNS mother: "<<mother<<endl;
			
			son= new CIndividual(IND_SIZE);
			daughter= new CIndividual(IND_SIZE);
			
			TTP_Crossover(father->Genes(),mother->Genes(),son->Genes(),daughter->Genes());
			
//			cout<<"son: "<<son<<endl;
//			cout<<"daughter: "<<daughter<<endl;
			
			eVNS(son,POWER,MAX_LOCAL,fsp);
			eVNS(daughter,POWER,MAX_LOCAL,fsp);
			
//			cout<<"VNS son: "<<son<<endl;
//			cout<<"VNS daughter: "<<daughter<<endl;
			//cout<<"here"<<endl;
			//Get the best 2 of the familiy.
			CPopulation * aux= new CPopulation();
			aux->AddToPopulation(father);
			aux->AddToPopulation(mother);
			aux->AddToPopulation(son);
			aux->AddToPopulation(daughter);
			
			POSITION pos=aux->GetHeadPosition();
			offspring->AddToPopulation(aux->GetAt(pos)->Clone());
			pos=aux->GetNext(pos);
			offspring->AddToPopulation(aux->GetAt(pos)->Clone());
		//	cout<<"removing population"<<endl;
			aux->RemoveAll();
			delete aux;
			
			if (-offspring->GetHead()->Value()<-best_individual->Value())
			{
				CONVERGENCE_ITERATION=GENERATIONS;
				CONVERGENCE_EVALUATIONS=EVALUATIONS;
				delete best_individual;
				best_individual=offspring->GetHead()->Clone();
				BEST_FITNESS=-best_individual->Value();
			}	
			 

			//cout<<"first iteration finish"<<endl;
		}
		delete population;
		population=offspring;

		//all individuals have identical fitness.
		if (population->Same()==true)
		{
			cout<<"restart population"<<endl;
			population->RemoveAll();
			population->AddToPopulation(best_individual->Clone());
			
			//generar aleatoriamente POP_SIZE-1 elementos.
			for(int i=0;i<POP_SIZE-1;i++)
			{
				//Create random individual
				int* permutation= new int[IND_SIZE];
				GenerateRandomPermutation(IND_SIZE,permutation);
				CIndividual * individual= new CIndividual(IND_SIZE);
				individual->SetGenes(permutation);
				population->AddToPopulation(individual);
				delete [] permutation;

			}	
		}
		

	}
	//delete offspring;	
	//delete population;


	timer.End();
	
	// Write solution in the output file.
	//solution.WriteSolution();
	BEST_FITNESS=-best_individual->Value();
	
	WriteSolution(best_individual,timer);
		
	RemoveProblemInfo();
	gettimeofday(&stop,NULL);
	return -BEST_FITNESS;
}


