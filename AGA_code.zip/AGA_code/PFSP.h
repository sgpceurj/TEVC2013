/*
 *  PFSP.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#ifndef _PFSP_H__
#define _PFSP_H__

#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string.h>
#include <stdio.h>

using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::ifstream;
using std::stringstream;
using std::string;

class PFSP
{
	
public:
	
	/*
	 * The number of jobs of the problem.
	 */
	int JOB_NUM;
	
	/*
	 * The number of machines of the problem.
	 */
	int MACHINE_NUM;
	
	/*
	 * The processing times matrix.
	 */
	int **JOBPROCESSINGMATRIX;
	
	/*
	 * Auxiliary data tables to achieve a higher speed-up when evaluating.
	 */
	int ** jobsTimeTable_aux;
	int * genes_aux;
	int * inverted_aux;

	// The constructor. It initializes a flowshop scheduling problem from a file.
	PFSP();
	
    // The destructor.
    virtual ~PFSP();
	
	/*
	 * Reads and PFSP file of Taillard Data set with the given filename.
	 */
	int ReadInstance(string filename);
	
	/*
	 * This function evaluates the individuals for the makespan of FSP problem.
	 */
	double EvaluateFSPMakespan(int * genes);

	/*
	 * This function evaluates the individuals for the total flowtime of FSP problem.
	 */
	int EvaluateFSPTotalFlowtime(int * genes);

	/*
	 * Partial evaluation method for LR constructive heuristic method. The call to this method is expected in the index function.
	 */
	int PartialEvaluation(int * genes, int size, int * new_job_times);
	int PartialEvaluation(int * genes, int size, int new_job);
	void IdleTimesAtPosition(int * sequence, int size, int job_i, int * idleTimes);
	
	/*
	 * This function is an specialized version of the previous method to evaluate the individuals for the total flowtime of FSP problem.
	 * Includes the posibility to evaluate the functions partially to improve the speed up the local search techniques. This method
	 * particularly overwrites the jobstimetables values.
	 */
	int EvaluateFSPTotalFlowtime_Overwrite(int * genes, int from, int ** jobsTimeTable);

	/*
	 * This function is an specialized version of the previous method to evaluate the individuals for the total flowtime of FSP problem.
	 * Includes the posibility to evaluate the functions partially to improve the speed up the local search techniques. This method
	 * particularly it does not overwrite the jobstimetables values.
	 */
	int EvaluateFSPTotalFlowtime_NonOverwrite(int * genes, int from, int ** jobsTimeTable);

	/*
	 * This function calculates the profiles between each job, and the calculates the sum of all of them
	 */
	double EvaluateFSPResidualProfileSum(int * genes);
	
	int* GetJobSumTimesVector(int * permutation, int size);

	/*
	 * This function returns in ptAvg the average processing time for each job.
	 */
	void ProcessingTimeAverages(double * ptAvg);

	/*
	 * Calculates the partial TFT of each job pair, in start condition.
	 */
	void JobsPartialTFTAnalysis(int ** partialTFTs, int * residualDelay);

	/*
	 * Calculates the delay produces by each job pair, or if there is not delay, the margin until a delay can be produced.
	 */
	void JobsDelayMarginAnalysis(int ** delays, int * residualDelay);

	/*
	 * Calculates the machine idle time that produces each job pair.
	 */
	void MachineIdleTimeAnalysis(int ** idleTimes);
	
	/*
	 * Returns the incremental TFT value of the individual in the array incrementalSolution.
	 */
	void SolutionIncrementalTFT(int * genes, int size, double * incrementalSolution);

	/*
	 * Returns the partial TFT values of the individual in the array partialSolution.
	 */
	void SolutionPartialTFT(int * genes, int size, double * partialSolution);

	/*
	 * Returns the incremental delay value of the individual in the array incrementalSolution.
	 */
	void SolutionIncrementalDelay(int * genes, int size, double * incrementalSolution);

	/*
	 * Returns the partial delay values of the individual in the array partialSolution.
	 */
	void SolutionPartialDelay(int * genes, int size, double * partialSolution);

	/*
	 * Calculates the residual delay for each machine that generate the jobs sequenced in the position 'position'.
	 */
	void ResidualProfile(int * genes, int size, int position, int * residualDelay);

	/*
	 * Generates a sample of individuals after applying a local search to each individual, and then the method wrotes
	 * them in a file. This samples are used to calculate the number of local optima of the instance.
	 */
	void LocalOptimumAnalysis(int samplesNum, int size);

	/*
	 * Calculates the slope of the regression line estimated for each job according to the processing times of each.
	 */
	void JobSlopeAnalysis(double * slopes);

	/*
	 * Estimates the regression line for the x,y coordinates and returns the slope of the first order polynomial equation.
	 */
	double RegressionLineSlope (int * x, int * y, int N);
	
	
	double** CalculateInstanceFitnessAverage_JobPosition(int size, int samplesNum);
	
	double** CalculateInstanceFitnessAverage_JobJob(int size, int samplesNum);
	
	void CalculateInstanceVarianceMatrix(double** indexVariance, double** positionVariance, int size, int samplesNum);
	
private: 
	
	
	
};
#endif





