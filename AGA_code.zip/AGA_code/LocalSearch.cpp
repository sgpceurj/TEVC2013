/*
 *  LocalSearch.cpp
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 9/15/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "LocalSearch.h"
#include "AGA.h"
#include "Problem.h"
#include "PFSP.h"
#include "PermutationTools.h"

/*
 * This method moves the value in position i to the position j.
 */
int * InsertAt (int * array, int i, int j)
{	
	int res[IND_SIZE];
	int val=array[i];
	if (i!=j)
	{
		if (i<j)
		{
			memcpy(res,array,sizeof(int)*i);
			
			for (int k=i+1;k<=j;k++)
				res[k-1]=array[k];
			
			res[j]=val;
			
			for (int k=j+1;k<IND_SIZE;k++)
				res[k]=array[k];
		}
		else if (i>j)
		{
			memcpy(res,array,sizeof(int)*j);
			
			res[j]=array[i];
			
			for (int k=j;k<i;k++)
				res[k+1]=array[k];
			
			for (int k=i+1;k<IND_SIZE;k++)
				res[k]=array[k];
		}
		memcpy(array,res,sizeof(int)*IND_SIZE);
	}
	return array;
}

/*
 * This method applies a swap of the given i,j positions in the array.
 */
int * Swap(int * array, int i, int j)
{
	int aux=array[i];
	array[i]=array[j];
	array[j]=aux;
	return array;
}

/*
 * This method applies a greedy local search with the swap operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Swap(PFSP * fsp, CIndividual *  individual, int power)
{
	float cost_opt, cost_improve, cost_best_provisional;
	int seguir,j,k,aux;
	int best_k=0, best_j=0;
		
	//int * genes= new int[IND_SIZE];
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	
	//cost_opt=-fsp->EvaluateFSPResidualProfileSum(genes);
	cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite(fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
	cost_best_provisional=cost_opt;
	int iter=0;
	seguir=1;
	while ((seguir && power==0) || (seguir && iter<power))
	{
		seguir=0;
		for (k=0; k<IND_SIZE-1; k++)
		{
			for (j=k+1; j<IND_SIZE;j++)
			{
				//swap k and j positions.
				aux=fsp->genes_aux[k];
				fsp->genes_aux[k]=fsp->genes_aux[j];
				fsp->genes_aux[j]=aux;
								
				cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite(fsp->genes_aux, k, fsp->jobsTimeTable_aux);
				EVALUATIONS++;	
				if (cost_improve>cost_best_provisional)
				{
					//guardar que el mejor swap
					//cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
					best_k=k;
					best_j=j;
					cost_best_provisional=cost_improve;
					seguir=1;
				}

				//restore the positions swapped previously. Because this change does not produce good results.
				aux=fsp->genes_aux[j];
				fsp->genes_aux[j]=fsp->genes_aux[k];
				fsp->genes_aux[k]=aux;
			}
		}

		if (seguir==1)
		{
			//modificar la permutacion con aquel swap que mejore más.
			aux=fsp->genes_aux[best_k];
			fsp->genes_aux[best_k]=fsp->genes_aux[best_j];
			fsp->genes_aux[best_j]=aux;
			cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite(fsp->genes_aux, best_k, fsp->jobsTimeTable_aux);
		}
		iter++;
	}
	
	//int * inverted= new int[IND_SIZE];
	Invert(fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);

	if (best_j==0 && best_k==0)//si estas variables siguen si utilizar quiere decir que no se ha mejorado.
		return false;
	else
		return true;

}

/*
 * This method applies a greedy local search with the insert operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Insert(PFSP * fsp, CIndividual *  individual, int power)
{
	//cout<<"in insert: "<<individual<<endl;
	int cost_opt, cost_improve, cost_best_provisional;
	int seguir,j,k;
	int best_k=0, best_j=0;
	
	Invert(individual->Genes(),IND_SIZE, fsp->genes_aux);
	
	cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
	cost_best_provisional=cost_opt;
	
	seguir=1;
	int iter=0;
	while ((seguir && power==0) || (seguir && iter<power))
	{
		seguir=0;
		for (k=0; k<IND_SIZE; k++)
		{
			for (j=0; j<IND_SIZE;j++)
			{
					InsertAt(fsp->genes_aux,k,j);
					if(k<j)
						cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite( fsp->genes_aux, k, fsp->jobsTimeTable_aux);
					else
						cost_improve=-fsp->EvaluateFSPTotalFlowtime_NonOverwrite( fsp->genes_aux, j, fsp->jobsTimeTable_aux);
				
					EVALUATIONS++;	
					if (cost_improve>cost_best_provisional)
					{
						//cout<<"cost_improve: "<<cost_improve<<" cost_best: "<<cost_best_provisional<<endl;
						//guardar que el mejor swap
						//cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
						best_k=k;
						best_j=j;
						cost_best_provisional=cost_improve;
						seguir=1;
					}
					//restore the positions modified previously. Because this change does not produce good results.
					InsertAt( fsp->genes_aux,j,k);
			}
		}
		
		if (seguir==1)
		{
			//modificar la permutacion con aquel insert que mejore más.
			InsertAt( fsp->genes_aux,best_k,best_j);
			cost_opt=-fsp->EvaluateFSPTotalFlowtime_Overwrite( fsp->genes_aux, 0, fsp->jobsTimeTable_aux);
		}
		iter++;
	}
	
	Invert( fsp->genes_aux,IND_SIZE,fsp->inverted_aux);
	individual->SetGenes(fsp->inverted_aux);
	
	//cout<<"in insert after: "<<individual<<endl;
	if (best_j==0 && best_k==0)//si estas variables siguen si utilizar quiere decir que no se ha mejorado.
		return false;
	else
		return true;
}

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 */
CIndividual * VNS(PFSP * fsp, CIndividual *  individual, int upper_iteraciones, int shake_power)
{	
	//cout<<"in: "<<individual<<endl;
	bool seguir1,seguir2;
	int iteracion=0;
	
	//save best individual
	CIndividual * best = individual->Clone();
	CIndividual * current = individual->Clone();
	do
	{
		do
		{
			seguir1=  LocalSearch_Greedy_Swap(fsp, current,0);
			//cout<<"after swap: "<<current<<endl;,			
			seguir2=  LocalSearch_Greedy_Insert(fsp, current,1);
			//cout<<"in cycle: "<<individual<<endl;			
		}
		while (seguir1 || seguir2);
		
		if (current->Value()>best->Value())
		{
			//cout<<"hobetzen: "<<endl;
			best=current->Clone();
			iteracion=0;
		}
		else if (current->Value()!=best->Value())
		{
			current=best->Clone();
		}

		//shake.
		Shake(current,shake_power);
		
		iteracion++;
	}
	while (iteracion<upper_iteraciones);
	individual->SetGenes(best->Genes());
	
	delete current;
	delete best;
	//cout<<"out: "<<individual<<endl;
	return individual;
}

/*
 * It applies random shake_power times a perturbation over the given individual.
 */
void Shake(CIndividual *  individual, int shake_power)
{
	int * genes= individual->Genes();
	int i,j,aux;
	for (int iter=0;iter<shake_power;iter++)
	{
		//permute randomly genes in position i and j to scape the stackeness in both neighborhood.
		i = rand() % IND_SIZE;
		j = rand() % IND_SIZE;
		aux=genes[j];
		genes[j]=genes[i];
		genes[i]=aux;
		//cout<<individual<<endl;
	}
	individual->SetGenes(genes);
}

/*
 * Prints in the standard output genes.
 */
void Print(int * array, int size, string text)
{
	cout<<text<<" ";
	for (int i=0;i<size;i++){
		cout<<array[i]<<" ";
	}
	cout<<" "<<endl;
}

/*
 * This method implements the enhanced VNS purposed in the paper of the algorithm AGA of Xiao Xu.
 */
CIndividual * eVNS(CIndividual *  individual, int POWER, int k, PFSP * fsp)
{
	//cout<<"individual in: "<<individual<<endl;
	//cout<<"POWER: "<<POWER<<endl;
	//cout<<"repetitions: "<<k<<endl;
	//initialization of parameters
	int loop=1;
	int flag=0;
	int x1,x2=0;
	int i,j;
	CIndividual * temp = new CIndividual(IND_SIZE);
	//start vns execution.
	#ifdef TIME_CRITERIA
	while(loop<=k && timer.Time()<MAX_SECONDS)
	#else
	while(loop<=k && EVALUATIONS<MAX_EVALUATIONS)	
	#endif	
	{
		flag=1;
		#ifdef TIME_CRITERIA
		while(flag==1 && timer.Time()<MAX_SECONDS)
		#else	
		while(flag==1 && EVALUATIONS<MAX_EVALUATIONS)	
		#endif
		{
			//cout<<individual<<endl;
			flag=0;
			#ifdef TIME_CRITERIA
			for (i=0;i<POWER && timer.Time()<MAX_SECONDS;i++)
			#else	
			for (i=0;i<POWER && EVALUATIONS<MAX_EVALUATIONS;i++)
			#endif	
			{
				x1 = int(rand()%IND_SIZE);
				x2 = int(rand()%IND_SIZE);
				//cout<<"x1: "<<x1<<" x2: "<<x2<<endl;

				temp->SetGenes(individual->Genes());
				//cout<<"temp antes: "<<temp<<endl;
				//cout<<"x1: "<<x1<<" x2: "<<x2<<endl;
				temp->SetGenes(InsertAt(temp->Genes(),x1,x2));
				//cout<<"temp despues: "<<temp<<endl;
				
				if (temp->Value()>individual->Value())
				{
					individual->SetGenes(temp->Genes());
					flag=1;
					break;
				}
				
			}
			
			if (flag!=1)
			{
				#ifdef TIME_CRITERIA
				for (j=0;j<POWER && timer.Time()<MAX_SECONDS;j++)
				#else	
				for (j=0;j<POWER && EVALUATIONS<MAX_EVALUATIONS;j++)
				#endif	
				{
					x1 = int(rand()%IND_SIZE);
					x2 = int(rand()%IND_SIZE);
					temp->SetGenes(individual->Genes());
				//	cout<<"temp antes: "<<temp<<endl;
				//	cout<<"x1: "<<x1<<" x2: "<<x2<<endl;
					temp->SetGenes(Swap(temp->Genes(),x1,x2));
				//	cout<<"temp despues: "<<temp<<endl;

					if (temp->Value()>individual->Value())
					{
						individual->SetGenes(temp->Genes());
						flag=1;
						break;
					}
				}
			}
		}
	//	cout<<"loop: "<<loop<<endl;
		loop++;
	}
	delete temp;
//	cout<<"individual out: "<<individual<<endl;
//	exit(1);
	return individual;
}

