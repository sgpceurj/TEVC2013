#ifndef _AGA_
#define _AGA_

#include "Variables.h"
#include "Individual.h"
#include "Timer.h"
#include "Population.h"
#include <fstream>
#include <iostream>
using std::ifstream;
using std::ofstream;


// The size of the population.
extern int POP_SIZE;

extern int SEED;
 
// The individual size.
extern int IND_SIZE;

// Number of evaluations performed.
extern double EVALUATIONS;
extern double CONVERGENCE_EVALUATIONS;
extern double MAX_EVALUATIONS;

// Maximum number of generations (used by the stopping criterium).
// When MAX_GENERATIONS=0 -> no limit
extern int MAX_GENERATIONS;
extern int GENERATIONS;
extern int MAX_SECONDS;
// Name of the file where the output will be stored (optional).
extern char OUTPUTFILE[50];
extern ofstream foutput;

// Name of the file where the log results will be stored (optional).
extern char LOGFILE[50];
extern ofstream flog;

extern char OUTPOPFILE[];

// Best result convergente iteration
extern int CONVERGENCE_ITERATION;

extern int BEST_FITNESS;
extern CTimer timer;
#endif




