/*
 *  Tools.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>
#include <stdio.h>
#include "Variables.h"
using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::ifstream;
using std::stringstream;
using std::string;

bool strContains(const string inputStr, const string searchStr);

char* StringToChar(string value);

void PrintArray(int* array, int length, string text);

void PrintArray(int * array, int size);

void PrintMatrix(int** matrix, int length, int length2, string text);

// Prints in standard output 'length' double elements of a given array.
void PrintArrayDouble(double* array, int length, string text);

// Prints in standard output 'length' double elements of a given array.
void PrintArrayDouble(double* array, int length, string text, ofstream file);

// Prints in standard output 'lengthxlength' double elements of a given matrix.
void PrintMatrixDouble(double** matrix, int length, int length2, string text);

double Mean(int* array, int num);

double Variance(int* array, int num);

double Mean(double* array, int num);

double Variance(double* array, int num);

double** TransposeMatrix(double** matrix, int size);

void CloneArray(int * a, int * result, int size);

void InsertAt(int*array,int element, int at, int n);

void RemoveAt(double*array,int positionIndex, int n);

void RemoveAt(int*array,int positionIndex, int n);

int Max(int*array, int n);

int Min(int*array, int n);

int MaxPosition(double*array, int n);

void DescendingSequence(double * array, int* descendingSequence, int size);

void AscendingSequence(int * array, int* indexes,int* resultingSequence, int size);
