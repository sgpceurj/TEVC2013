/*
 *  LocalSearch.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 9/15/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include <fstream>
#include <iostream>
#include "Individual.h"
#include "PFSP.h"
using std::istream;
using std::ostream;
using std::string;

/*
 * This method applies a greedy local search with the swap operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Swap(PFSP * fsp, CIndividual *  individual, int power);

/*
 * This method applies a greedy local search with the insert operator neighborhood with the given power.
 */
bool LocalSearch_Greedy_Insert(PFSP * fsp, CIndividual * individual, int power);

/*
 * Executes a variable neighborhood search over the swap and insert neighborhoods for the given PFSP instance.
 */
CIndividual * VNS(PFSP * fsp, CIndividual *  individual, int upper_iteraciones, int shake_power);

/*
 * Applies a shake over an individual.
 */
void Shake(CIndividual *  individual, int shake_power);

/*
 * This method moves the value in position i to the position j.
 */
int * InsertAt (int * array, int i, int j);

/*
 * Prints in the standard output genes.
 */
void Print(int * array, int size, string text);

/*
 * This method applies a swap of the given i,j positions in the array.
 */
int * Swap(int * array, int i, int j);

/*
 * This method implements the enhanced VNS purposed in the paper of the algorithm AGA of Xiao Xu.
 */
CIndividual * eVNS(CIndividual *  individual, int k, int max_local, PFSP * fsp);
